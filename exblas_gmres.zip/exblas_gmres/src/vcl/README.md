# version1
C++ vector class library, version 1

Use this version for compilers that cannot handle version 2,
including Intel C++ compiler version 19, and older versions of Microsoft, Gnu, and Clang compilers.

[Download code for version 1](https://github.com/vectorclass/version1/archive/master.zip)

[Download code for version 2](https://github.com/vectorclass/version2/archive/master.zip)

[Download manual](https://github.com/vectorclass/manual/raw/master/vcl_manual.pdf)

