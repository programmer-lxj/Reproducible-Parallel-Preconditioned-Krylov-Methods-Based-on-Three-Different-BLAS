#include <sys/time.h>
#include <sys/types.h>
#include <sys/times.h>
#include <unistd.h>

extern void reloj (double *elapsed, double *ucpu);

