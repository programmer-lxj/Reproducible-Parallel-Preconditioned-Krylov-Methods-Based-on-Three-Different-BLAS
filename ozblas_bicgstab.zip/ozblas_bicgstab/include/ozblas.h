#ifndef OZBLAS_H
#define OZBLAS_H

typedef struct {
	char* devWork;
	char* devBatchAddr;
	uint64_t workSizeBytes;
	uint numSplitArraysMax;
	uint fastModeFlag;
	uint reproModeFlag;
	uint sumModeFlag;
	uint64_t memAddr;

	// exec info
	uint numSplitArraysA;
	uint numSplitArraysB;
	uint numSplitArraysC;
	uint lastFlagA;
	uint lastFlagB;

	// for SpMV in iterative solvers
	size_t memMaskSplitA;
	uint32_t numSplitArraysA_;
	int32_t splitShift;

	uint trueres;
	uint verbose;
	uint useGemmFlag;
	uint useMyGemmFlag;
	uint useBatchedGemmFlag;
	double t_SplitA;
	double t_SplitB;
	double t_comp;
	double t_sum;
	double t_total;

	// for CG breakdown
	double t_SplitMat_total;
	double t_SplitVec_total;
	double t_Sum_total;
	double t_AXPY_SCAL_total;
	double t_DOT_NRM2_total;
	double t_SpMV_SpMM_total;

} ozblasHandle_t;

// helper routines
extern void ozblasProfilingSetting (ozblasHandle_t*, uint, uint, uint);
extern void ozblasCreate (ozblasHandle_t*, uint64_t, uint, uint, uint, uint);
extern void ozblasSetNumSplitArraysMax (ozblasHandle_t*, uint);
extern void ozblasSetFastMode (ozblasHandle_t*, uint);
extern void ozblasSetReproMode (ozblasHandle_t*, uint);
extern void ozblasSetSumMode (ozblasHandle_t*, uint);
extern uint ozblasGetNumSplitArraysMax (ozblasHandle_t*);
extern uint ozblasGetFastMode (ozblasHandle_t*);
extern uint ozblasGetReproMode (ozblasHandle_t*);
extern uint ozblasGetSumMode (ozblasHandle_t*);
extern void ozblasDestroy (ozblasHandle_t*);

// BLAS routines (double)
extern int ozblasDgemm (ozblasHandle_t*, const char, const char, const int, const int, const int, const double, const double*, const int, const double*, const int, const double, double*, const int);
extern int ozblasDgemv (ozblasHandle_t*, const char, const int, const int, const double, const double*, const int, const double*, const int, const double, double*, const int);
extern double ozblasDdot (ozblasHandle_t*, const int, const double*, const int, const double*, const int);
extern double ozblasDnrm2 (ozblasHandle_t*, const int, const double*, const int);
extern int ozblasDaxpy (ozblasHandle_t*, const int, const double, const double*, const int, double*, const int);
extern int ozblasDcsrmv (ozblasHandle_t*, const char, const int, const int, const int, const double, const char*, const double*, const int*, const int*, const double*, const double, double*);
extern int ozblasDcsrmvSplitA (ozblasHandle_t*, const char, const int, const int, const int, const char *, const double*, const int*, const int*, double**);
extern int ozblasDcg (ozblasHandle_t *oh, const char tranA, const int dimN, const int dimNNZ, const char* descrA, const double *matA, const int *matArowptr, const int *matAcolind, const double *vecB, double *vecX, int maxiter, double tol);

// BLAS routines (float)
extern int ozblasSgemm (ozblasHandle_t*, const char, const char, const int, const int, const int, const float, const float*, const int, const float*, const int, const float, float*, const int);
extern int ozblasSgemv (ozblasHandle_t*, const char, const int, const int, const float, const float*, const int, const float*, const int, const float, float*, const int);
extern float ozblasSdot (ozblasHandle_t*, const int, const float*, const int, const float*, const int);
extern float ozblasSnrm2 (ozblasHandle_t*, const int, const float*, const int);
extern int ozblasSaxpy (ozblasHandle_t*, const int, const float, const float*, const int, float*, const int);
extern int ozblasScsrmv (ozblasHandle_t*, const char, const int, const int, const int, const float, const char*, const float*, const int*, const int*, const float*, const float, float*);
extern int ozblasScsrmvSplitA (ozblasHandle_t*, const char, const int, const int, const int, const char *, const float*, const int*, const int*, float**);
extern int ozblasScg (ozblasHandle_t *oh, const char tranA, const int dimN, const int dimNNZ, const char* descrA, const float *matA, const int *matArowptr, const int *matAcolind, const float *vecB, float *vecX, int maxiter, double tol);

// BLAS routines (float-double)
extern int ozblasSDgemm (ozblasHandle_t*, const char, const char, const int, const int, const int, const float, const float*, const int, const float*, const int, const float, float*, const int);
extern int ozblasSDgemv (ozblasHandle_t*, const char, const int, const int, const float, const float*, const int, const float*, const int, const float, float*, const int);
extern float ozblasSDdot (ozblasHandle_t*, const int, const float*, const int, const float*, const int);
extern float ozblasSDnrm2 (ozblasHandle_t*, const int, const float*, const int);
extern int ozblasSDaxpy (ozblasHandle_t*, const int, const float, const float*, const int, float*, const int);
extern int ozblasSDcsrmv (ozblasHandle_t*, const char, const int, const int, const int, const float, const char*, const float*, const int*, const int*, const float*, const float, float*);
extern int ozblasSDcsrmvSplitA (ozblasHandle_t*, const char, const int, const int, const int, const char *, const float*, const int*, const int*, float**);
extern int ozblasSDcg (ozblasHandle_t *oh, const char tranA, const int dimN, const int dimNNZ, const char* descrA, const float *matA, const int *matArowptr, const int *matAcolind, const float *vecB, float *vecX, int maxiter, double tol);

#endif
