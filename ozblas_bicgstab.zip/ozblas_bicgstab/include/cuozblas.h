#ifndef CUOZBLAS_H
#define CUOZBLAS_H

#include <cublas_v2.h>
#include <cusparse_v2.h>

typedef struct {
	cublasHandle_t ch;
	cusparseHandle_t csh;
	char* devWorkCommon; // for except split data, 128bytes
	char* devWork; // for split data
	char* hstBatchAddr;
	char* devBatchAddr;
	size_t workSizeBytes;
	size_t memAddr;
	uint32_t numSplitArraysMax;
	uint32_t fastModeFlag;
	uint32_t reproModeFlag;
	uint32_t sumModeFlag;

	// exec info
	uint32_t numSplitArraysA;
	uint32_t numSplitArraysB;
	uint32_t numSplitArraysC;
	uint32_t lastFlagA;
	uint32_t lastFlagB;

	// for SpMV in iterative solvers
	size_t memMaskSplitA;
	uint32_t numSplitArraysA_;
	int32_t splitShift;

	// tuning parameter (optional)
	float sparseThreshold;
	uint32_t useGemmFlag;
	uint32_t useMyGemmFlag;
	uint32_t useBatchedGemmFlag;

	uint32_t trueres;
	uint32_t verbose;
	double t_SplitA;
	double t_SplitB;
	double t_comp;
	double t_sum;
	double t_total;

	// for CG breakdown
	double t_SplitMat_total;
	double t_SplitVec_total;
	double t_Sum_total;
	double t_AXPY_SCAL_total;
	double t_DOT_NRM2_total;
	double t_SpMV_SpMM_total;

} cuozblasHandle_t;

// helper routines
extern void cuozblasProfilingSetting (cuozblasHandle_t*, uint32_t, uint32_t, uint32_t);
extern void cuozblasProfilingSetting2 (cuozblasHandle_t*, float);
extern void cuozblasCreate (cuozblasHandle_t*, size_t, uint32_t, uint32_t, uint32_t, uint32_t);
extern void cuozblasSetNumSplitArraysMax (cuozblasHandle_t*, uint32_t);
extern void cuozblasSetFastMode (cuozblasHandle_t*, uint32_t);
extern void cuozblasSetReproMode (cuozblasHandle_t*, uint32_t);
extern void cuozblasSetSumMode (cuozblasHandle_t*, uint32_t);
extern uint32_t cuozblasGetNumSplitArraysMax (cuozblasHandle_t*);
extern uint32_t cuozblasGetFastMode (cuozblasHandle_t*);
extern uint32_t cuozblasGetReproMode (cuozblasHandle_t*);
extern uint32_t cuozblasGetSumMode (cuozblasHandle_t*);
extern void cuozblasDestroy (cuozblasHandle_t*);

// BLAS routines (double)
extern int32_t cuozblasDgemm (cuozblasHandle_t*, const cublasOperation_t, const cublasOperation_t, const int32_t, const int32_t, const int32_t, const double*, const double*, const int32_t, const double*, const int32_t, const double*, double*, const int32_t);
extern int32_t cuozblasDgemv (cuozblasHandle_t*, const cublasOperation_t, const int32_t, const int32_t, const double*, const double*, const int32_t, const double*, const int32_t, const double*, double*, const int32_t);
extern int32_t cuozblasDdot (cuozblasHandle_t*, const int32_t, const double*, const int32_t, const double*, const int32_t, double*);
extern int32_t cuozblasDnrm2 (cuozblasHandle_t*, const int32_t, const double*, const int32_t, double*);
extern int32_t cuozblasDaxpy (cuozblasHandle_t*, const int32_t, const double*, const double*, const int32_t, double*, const int32_t);
extern int32_t cuozblasDcsrmv (cuozblasHandle_t*, const cusparseOperation_t, const int32_t, const int32_t, const int32_t, const double*, const cusparseMatDescr_t, const double*, const int32_t*, const int32_t*, const double*, const double*, double*);
extern int32_t cuozblasDcsrmvSplitA (cuozblasHandle_t*, const cusparseOperation_t, const int32_t, const int32_t, const int32_t, const cusparseMatDescr_t, const double*, const int32_t*, const int32_t*, double**);
extern int32_t cuozblasDcg (cuozblasHandle_t *oh, const cusparseOperation_t tranA, const int32_t dimN, const int32_t dimNNZ, const cusparseMatDescr_t descrA, const double *matA, const int32_t *matArowptr, const int32_t *matAcolind, const double *vecB, double *vecX, int32_t maxiter, double tol);

// BLAS routines (float)
extern int32_t cuozblasSgemm (cuozblasHandle_t*, const cublasOperation_t, const cublasOperation_t, const int32_t, const int32_t, const int32_t, const float*, const float*, const int32_t, const float*, const int32_t, const float*, float*, const int32_t);
extern int32_t cuozblasSgemv (cuozblasHandle_t*, const cublasOperation_t, const int32_t, const int32_t, const float*, const float*, const int32_t, const float*, const int32_t, const float*, float*, const int32_t);
extern int32_t cuozblasSdot (cuozblasHandle_t*, const int32_t, const float*, const int32_t, const float*, const int32_t, float*);
extern int32_t cuozblasSnrm2 (cuozblasHandle_t*, const int32_t, const float*, const int32_t, float*);
extern int32_t cuozblasSaxpy (cuozblasHandle_t*, const int32_t, const float*, const float*, const int32_t, float*, const int32_t);
extern int32_t cuozblasScsrmv (cuozblasHandle_t*, const cusparseOperation_t, const int32_t, const int32_t, const int32_t, const float*, const cusparseMatDescr_t, const float*, const int32_t*, const int32_t*, const float*, const float*, float*);
extern int32_t cuozblasScsrmvSplitA (cuozblasHandle_t*, const cusparseOperation_t, const int32_t, const int32_t, const int32_t, const cusparseMatDescr_t, const float*, const int32_t*, const int32_t*, float**);
extern int32_t cuozblasScg (cuozblasHandle_t *oh, const cusparseOperation_t tranA, const int32_t dimN, const int32_t dimNNZ, const cusparseMatDescr_t descrA, const float *matA, const int32_t *matArowptr, const int32_t *matAcolind, const float *vecB, float *vecX, int32_t maxiter, double tol);

// BLAS routines (float-double)
extern int32_t cuozblasSDgemm (cuozblasHandle_t*, const cublasOperation_t, const cublasOperation_t, const int32_t, const int32_t, const int32_t, const float*, const float*, const int32_t, const float*, const int32_t, const float*, float*, const int32_t);
extern int32_t cuozblasSDgemv (cuozblasHandle_t*, const cublasOperation_t, const int32_t, const int32_t, const float*, const float*, const int32_t, const float*, const int32_t, const float*, float*, const int32_t);
extern int32_t cuozblasSDdot (cuozblasHandle_t*, const int32_t, const float*, const int32_t, const float*, const int32_t, float*);
extern int32_t cuozblasSDnrm2 (cuozblasHandle_t*, const int32_t, const float*, const int32_t, float*);
extern int32_t cuozblasSDaxpy (cuozblasHandle_t*, const int32_t, const float*, const float*, const int32_t, float*, const int32_t);
extern int32_t cuozblasSDcsrmv (cuozblasHandle_t*, const cusparseOperation_t, const int32_t, const int32_t, const int32_t, const float*, const cusparseMatDescr_t, const float*, const int32_t*, const int32_t*, const float*, const float*, float*);
extern int32_t cuozblasSDcsrmvSplitA (cuozblasHandle_t*, const cusparseOperation_t, const int32_t, const int32_t, const int32_t, const cusparseMatDescr_t, const float*, const int32_t*, const int32_t*, double**);
extern int32_t cuozblasSDcg (cuozblasHandle_t *oh, const cusparseOperation_t tranA, const int32_t dimN, const int32_t dimNNZ, const cusparseMatDescr_t descrA, const float *matA, const int32_t *matArowptr, const int32_t *matAcolind, const float *vecB, float *vecX, int32_t maxiter, double tol);
#endif
