#include "cuozblas_common.h"

double timer () {
	struct timeval tv;
	cudaDeviceSynchronize ();
	gettimeofday (&tv, NULL);
	return tv.tv_sec + (double) tv.tv_usec * 1.0e-6;
}

size_t getPitchSize (size_t n) {
	return ceil((double)n / 128) * 128;
}

uint32_t memCheck (cuozblasHandle_t *oh) {
	if (oh->memAddr > oh->workSizeBytes) return 1;
	return 0;
}

void counterInit (cuozblasHandle_t *oh) {
	oh->t_SplitA = 0.;
	oh->t_SplitB = 0.;
	oh->t_comp = 0.;
	oh->t_sum = 0.;
	oh->t_total = 0.;
	oh->numSplitArraysA = 0;
	oh->numSplitArraysB = 0;
	oh->numSplitArraysC = 0;
	oh->lastFlagA = 0;
	oh->lastFlagB = 0;
	oh->memAddr = oh->memMaskSplitA;
}

void cuozblasCreate (cuozblasHandle_t *oh, size_t WorkSizeBytes, uint32_t NumSplitArraysMax, uint32_t FastMode, uint32_t ReproMode, uint32_t SumMode) {
	oh->workSizeBytes = (WorkSizeBytes) ? WorkSizeBytes : DefaultWorkSize; 
	oh->numSplitArraysMax = NumSplitArraysMax;
	oh->fastModeFlag = FastMode;
	oh->reproModeFlag = ReproMode;
	oh->sumModeFlag = SumMode;

	// for CG
	oh->memMaskSplitA = 0; // disable pre-split of matA 
	oh->splitShift = 1; // default (no-Splitshift)

	// experimental parameters (default)
	oh->useGemmFlag = 1;
	oh->useMyGemmFlag = 1;
	oh->useBatchedGemmFlag = 1;
	oh->sparseThreshold = 0.;

	// work memory allocation
	cudaMalloc ((void **) &oh->devWorkCommon, sizeof(double)*16);// for NRM2
	cudaMalloc ((void **) &oh->devWork, oh->workSizeBytes);

	// cuBLAS
	cublasCreate (&oh->ch);
	cublasSetPointerMode(oh->ch, CUBLAS_POINTER_MODE_HOST);
	cusparseCreate (&oh->csh);
	cusparseSetPointerMode(oh->csh, CUSPARSE_POINTER_MODE_HOST);

	// batched BLAS
	if (oh->useBatchedGemmFlag) {
		char *hstBatchAddr_;
		cudaMallocHost ((void **) &hstBatchAddr_, sizeof(double*) * NumSplitDefaultMax * NumSplitDefaultMax * 3);
		oh->hstBatchAddr = hstBatchAddr_;
		char *devBatchAddr_;
		cudaMalloc ((void **) &devBatchAddr_, sizeof(double*) * NumSplitDefaultMax * NumSplitDefaultMax * 3);
		oh->devBatchAddr = devBatchAddr_;
	}
}

void cuozblasProfilingSetting (cuozblasHandle_t *oh, uint32_t useGemmFlag, uint32_t useMyGemmFlag, uint32_t useBatchedGemmFlag) {
	oh->useGemmFlag = useGemmFlag;
	oh->useMyGemmFlag = useMyGemmFlag;
	oh->useBatchedGemmFlag = useBatchedGemmFlag;
}
void cuozblasProfilingSetting2 (cuozblasHandle_t *oh, float sparseThreshold) {
	oh->sparseThreshold = sparseThreshold;
}

void cuozblasSetNumSplitArraysMax (cuozblasHandle_t *oh, uint32_t NumSplitArraysMax) {
	oh->numSplitArraysMax = NumSplitArraysMax;
}

void cuozblasSetFastMode (cuozblasHandle_t *oh, uint32_t FastMode) {
	oh->fastModeFlag = (FastMode == 0) ? 0 : 1;
}

void cuozblasSetReproMode (cuozblasHandle_t *oh, uint32_t ReproMode) {
	oh->reproModeFlag = (ReproMode == 0) ? 0 : 1;
}

void cuozblasSetSumMode (cuozblasHandle_t *oh, uint32_t SumModeFlag) {
	oh->sumModeFlag = (SumModeFlag == 0) ? 0 : 1;
}

uint32_t cuozblasGetNumSplitArraysMax (cuozblasHandle_t *oh) {
	return oh->numSplitArraysMax;
}

uint32_t cuozblasGetFastMode (cuozblasHandle_t *oh) {
	return oh->fastModeFlag;
}

uint32_t cuozblasGetReproMode (cuozblasHandle_t *oh) {
	return oh->reproModeFlag;
}

uint32_t cuozblasGetSumMode (cuozblasHandle_t *oh) {
	return oh->sumModeFlag;
}

void cuozblasDestroy (cuozblasHandle_t *oh) {
	cudaFree (oh->devWork);
	cudaFree (oh->devWorkCommon);
	if (oh->useBatchedGemmFlag) {
		cudaFreeHost (oh->hstBatchAddr);
		cudaFree (oh->devBatchAddr);
	}
	cublasDestroy (oh->ch);
	cusparseDestroy (oh->csh);
}
