// setting
#define DefaultWorkSize 8e9 // 8GB
#define NumSplitDefaultMax 20
//#define SPARSITY_THRESHOLD 1 // [%]

#define SPLIT_N_NTX 32
#define SPLIT_N_NTY 16
#define SPLIT_T_NTX 512
#define SPLIT_T_NTY 1
#define SPLIT_VEC_NTX 512
#define SPLIT_VEC_NBX 512

#include <stdio.h>
#include <stdlib.h>
#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include <sys/time.h>
#include <float.h>

#include <cuda.h>
#include <cublas_v2.h>
#include <cusparse_v2.h>
#include <cuda_runtime_api.h>
#include <builtin_types.h>
#include "../../include/cuozblas.h"
#include "cuozblas_internal.h"

#if defined (PREC_S)
#define FP_DTYPE	float
#define FP_CTYPE	float
#define UNIT	24

#define OzCG	cuozblasScg
#define OzDOT	cuozblasSdot 
#define OzAXPY	cuozblasSaxpy 
#define OzGEMV	cuozblasSgemv
#define OzGEMM	cuozblasSgemm
#define OzNRM2	cuozblasSnrm2
#define OzCSRMV	cuozblasScsrmv
#define OzCSRMVSplitA cuozblasScsrmvSplitA

#define RCuAXPY	cublasSaxpy 
#define RCuDOT	cublasSdot 
#define RCuGEMV	cublasSgemv
#define RCuGEMM	cublasSgemm
#define RCuNRM2	cublasSnrm2
#define RCuCSRMV	cusparseScsrmv

#define CuAXPY	cublasSaxpy 
#define CuDOT	cublasSdot 
#define CuGEMV	cublasSgemv
#define CuGEMM	cublasSgemm
#define CuNRM2	cublasSnrm2
#define CuCSRMV	cusparseScsrmv

#define CuGEMMBatched cublasSgemmBatched
#define CuCSRMM	cusparseScsrmm
#define CuDENSE2CSR	cusparseSdense2csr
#define CuASUM	cublasSasum 
#define CuSCAL	cublasSscal 
#define CuIAMAX	cublasIsamax
#define CuNNZ	cusparseSnnz
#define MuMDOT	mublasSmdot

#define ADD __fadd_rn
#define SUB __fsub_rn
#define MUL __fmul_rn
#define FMA __fmaf_rn

#define PdevKernel cuozblasSaxpyPdevKernel 
#define PhstKernel cuozblasSaxpyPhstKernel 

#define cuozblasMallocSplitMat			cuozblasSMallocSplitMat
#define cuozblasMallocSplitMatSparse	cuozblasSMallocSplitMatSparse
#define cuozblasMallocResultMat			cuozblasSMallocResultMat
#define cuozblasMallocSplitVec			cuozblasSMallocSplitVec
#define cuozblasMallocResultVec			cuozblasSMallocResultVec
#define cuozblasSplitMat				cuzoblasSSplitMat
#define cuozblasSplitMatSparse			cuozblasSSplitMatSparse
#define cuozblasSplitShiftMat			cuzoblasSSplitShiftMat
#define cuozblasSplitShiftMatSparse		cuozblasSSplitShiftMatSparse
#define cuozblasSumMat					cuozblasSSumMat
#define cuozblasPrintVec				cuozblasSPrintVec

#elif defined (PREC_D)

#define FP_DTYPE	double
#define FP_CTYPE	double
#define UNIT	53

#define OzCG	cuozblasDcg
#define OzDOT	cuozblasDdot 
#define OzAXPY	cuozblasDaxpy 
#define OzGEMV	cuozblasDgemv
#define OzGEMM	cuozblasDgemm
#define OzNRM2	cuozblasDnrm2
#define OzCSRMV	cuozblasDcsrmv
#define OzCSRMVSplitA cuozblasDcsrmvSplitA

#define RCuAXPY	cublasDaxpy 
#define RCuDOT	cublasDdot 
#define RCuGEMV	cublasDgemv
#define RCuGEMM	cublasDgemm
#define RCuNRM2	cublasDnrm2
#define RCuCSRMV	cusparseDcsrmv

#define CuAXPY	cublasDaxpy 
#define CuDOT	cublasDdot 
#define CuGEMV	cublasDgemv
#define CuGEMM	cublasDgemm
#define CuNRM2	cublasDnrm2
#define CuCSRMV	cusparseDcsrmv

#define CuGEMMBatched cublasDgemmBatched
#define CuCSRMM	cusparseDcsrmm
#define CuDENSE2CSR	cusparseDdense2csr
#define CuASUM	cublasDasum 
#define CuSCAL	cublasDscal 
#define CuIAMAX	cublasIdamax
#define CuNNZ	cusparseDnnz
#define MuMDOT	mublasDmdot

#define ADD __dadd_rn
#define SUB __dsub_rn
#define MUL __dmul_rn
#define FMA __fma_rn

#define PdevKernel cuozblasDaxpyPdevKernel 
#define PhstKernel cuozblasDaxpyPhstKernel 

#define cuozblasMallocSplitMat			cuozblasDMallocSplitMat
#define cuozblasMallocSplitMatSparse	cuozblasDMallocSplitMatSparse
#define cuozblasMallocResultMat			cuozblasDMallocResultMat
#define cuozblasMallocSplitVec			cuozblasDMallocSplitVec
#define cuozblasMallocResultVec			cuozblasDMallocResultVec
#define cuozblasSplitMat				cuzoblasDSplitMat
#define cuozblasSplitMatSparse			cuozblasDSplitMatSparse
#define cuozblasSplitShiftMat			cuzoblasDSplitShiftMat
#define cuozblasSplitShiftMatSparse		cuozblasDSplitShiftMatSparse
#define cuozblasSumMat					cuozblasDSumMat
#define cuozblasPrintVec				cuozblasDPrintVec

#elif defined (PREC_SD)

#define FP_DTYPE	float
#define FP_CTYPE	double
#define UNIT	53

#define OzCG	cuozblasSDcg
#define OzDOT	cuozblasSDdot 
#define OzAXPY	cuozblasSDaxpy 
#define OzGEMV	cuozblasSDgemv
#define OzGEMM	cuozblasSDgemm
#define OzNRM2	cuozblasSDnrm2
#define OzCSRMV	cuozblasSDcsrmv
#define OzCSRMVSplitA cuozblasSDcsrmvSplitA

#define RCuAXPY	cublasSaxpy 
#define RCuDOT	cublasSdot 
#define RCuGEMV	cublasSgemv
#define RCuGEMM	cublasSgemm
#define RCuNRM2	cublasSnrm2
#define RCuCSRMV	cusparseScsrmv

#define CuAXPY	cublasDaxpy 
#define CuDOT	cublasDdot 
#define CuGEMV	cublasDgemv
#define CuGEMM	cublasDgemm
#define CuNRM2	cublasDnrm2
#define CuCSRMV	cusparseDcsrmv

#define CuGEMMBatched cublasDgemmBatched
#define CuCSRMM	cusparseDcsrmm
#define CuDENSE2CSR	cusparseDdense2csr
#define CuASUM	cublasDasum 
#define CuSCAL	cublasSscal // <- 's'
#define CuIAMAX	cublasIdamax 
#define CuNNZ	cusparseDnnz
#define MuMDOT	mublasDmdot

#define ADD __dadd_rn
#define SUB __dsub_rn
#define MUL __dmul_rn
#define FMA __fma_rn

#define PdevKernel cuozblasSDaxpyPdevKernel 
#define PhstKernel cuozblasSDaxpyPhstKernel 

#define cuozblasMallocSplitMat			cuozblasSDMallocSplitMat
#define cuozblasMallocSplitMatSparse	cuozblasSDMallocSplitMatSparse
#define cuozblasMallocResultMat			cuozblasSDMallocResultMat
#define cuozblasMallocSplitVec			cuozblasSDMallocSplitVec
#define cuozblasMallocResultVec			cuozblasSDMallocResultVec
#define cuozblasSplitMat				cuzoblasSDSplitMat
#define cuozblasSplitMatSparse			cuozblasSDSplitMatSparse
#define cuozblasSplitShiftMat			cuzoblasSDSplitShiftMat
#define cuozblasSplitShiftMatSparse		cuozblasSDSplitShiftMatSparse
#define cuozblasSumMat					cuozblasSDSumMat
#define cuozblasPrintVec				cuozblasSDPrintVec

#endif


