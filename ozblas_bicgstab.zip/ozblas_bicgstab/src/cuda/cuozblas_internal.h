#ifndef CUOZBLAS_INTERNAL_H
#define CUOZBLAS_INTERNAL_H

double timer ();
size_t getPitchSize (size_t n);
void counterInit (cuozblasHandle_t *oh);
uint32_t memCheck (cuozblasHandle_t *oh);

cublasOperation_t ToCublasOp (char tran);
char FromCublasOp (cublasOperation_t tran);

#if defined (PREC_D)
void cuozblasDMallocSplitMat  ( cuozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void cuozblasDMallocSplitMatSparse ( cuozblasHandle_t *oh, const int32_t m, const int32_t nnz, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void cuozblasDMallocResultMat ( cuozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, int32_t &lds);
void cuozblasDMallocSplitVec  ( cuozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void cuozblasDMallocResultVec ( cuozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, int32_t &lds);
void cuzoblasDSplitMat ( cuozblasHandle_t *oh, const char major, const int32_t m, const int32_t n, const double *devInput, const int32_t ld, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasDSplitMatSparse ( cuozblasHandle_t *oh, const char major, const int32_t m, const double *devInput, const int32_t *devRowptr, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuzoblasDSplitShiftMat ( cuozblasHandle_t *oh, const char major, const int32_t m, const int32_t n, const double *devInput, const int32_t ld, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasDSplitShiftMatSparse ( cuozblasHandle_t *oh, const char major, const int32_t m, const double *devInput, const int32_t *devRowptr, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasDSumMat ( const int32_t m, const int32_t n, double *devCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, double *devC, const int32_t ldc, const double *alpha, const double *beta, const cublasPointerMode_t pmode, const uint32_t sumMode);
void cuozblasDPrintVec ( const int32_t n, const double *devC);
#elif defined (PREC_S)
void cuozblasSMallocSplitMat  ( cuozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, float **devSplit, float **devMax, int32_t &lds);
void cuozblasSMallocSplitMatSparse ( cuozblasHandle_t *oh, const int32_t m, const int32_t nnz, const uint32_t numSplitArraysMax, float **devSplit, float **devMax, int32_t &lds);
void cuozblasSMallocResultMat ( cuozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, float **devSplit, int32_t &lds);
void cuozblasSMallocSplitVec  ( cuozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, float **devSplit, float **devMax, int32_t &lds);
void cuozblasSMallocResultVec ( cuozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, float **devSplit, int32_t &lds);
void cuzoblasSSplitMat ( cuozblasHandle_t *oh, const char major, const int32_t m, const int32_t n, const float *devInput, const int32_t ld, float *devSplit, float *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasSSplitMatSparse ( cuozblasHandle_t *oh, const char major, const int32_t m, const float *devInput, const int32_t *devRowptr, float *devSplit, float *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuzoblasSSplitShiftMat ( cuozblasHandle_t *oh, const char major, const int32_t m, const int32_t n, const float *devInput, const int32_t ld, float *devSplit, float *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasSSplitShiftMatSparse ( cuozblasHandle_t *oh, const char major, const int32_t m, const float *devInput, const int32_t *devRowptr, float *devSplit, float *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasSSumMat ( const int32_t m, const int32_t n, float *devCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, float *devC, const int32_t ldc, const float *alpha, const float *beta, const cublasPointerMode_t pmode, const uint32_t sumMode);
void cuozblasSPrintVec ( const int32_t n, const float *devC);
#elif defined (PREC_SD)
void cuozblasSDMallocSplitMat  ( cuozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void cuozblasSDMallocSplitMatSparse ( cuozblasHandle_t *oh, const int32_t m, const int32_t nnz, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void cuozblasSDMallocTmpMat ( cuozblasHandle_t *oh, const int32_t m, const int32_t n, double **devSplit, int32_t &lds);
void cuozblasSDMallocTmpVec  ( cuozblasHandle_t *oh, const int32_t n, double **devSplit, int32_t &lds);
void cuozblasSDCopyMat ( const int32_t m, const int32_t n, const float *devA, const int32_t lda, double *devB, const int32_t ldb);
void cuozblasSDMallocResultMat ( cuozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, int32_t &lds);
void cuozblasSDMallocSplitVec  ( cuozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void cuozblasSDMallocResultVec ( cuozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **devSplit, int32_t &lds);
void cuzoblasSDSplitMat ( cuozblasHandle_t *oh, const char major, const int32_t m, const int32_t n, const double *devInput, const int32_t ld, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasSDSplitMatSparse ( cuozblasHandle_t *oh, const char major, const int32_t m, const double *devInput, const int32_t *devRowptr, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuzoblasSDSplitShiftMat ( cuozblasHandle_t *oh, const char major, const int32_t m, const int32_t n, const double *devInput, const int32_t ld, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasSDSplitShiftMatSparse ( cuozblasHandle_t *oh, const char major, const int32_t m, const double *devInput, const int32_t *devRowptr, double *devSplit, double *devMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void cuozblasSDSumMat ( const int32_t m, const int32_t n, double *devCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, float *devC, const int32_t ldc, const float *alpha, const float *beta, const cublasPointerMode_t pmode, const uint32_t sumMode);
void cuozblasSDPrintVec ( const int32_t n, const float *devC);
#endif

//void cuozblasInitVecDevice ( const size_t n, int64_t *devA);
void PrintMat ( const int32_t m, const int32_t n, const double *devC, const int32_t ldd);
void PrintMatInt ( const int32_t m, const int32_t n, const int32_t *devC, const int32_t ldd);

#endif
