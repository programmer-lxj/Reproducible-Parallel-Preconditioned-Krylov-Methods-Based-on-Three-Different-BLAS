#include "ozblas_common.h"

int
OzGEMV (
	ozblasHandle_t *oh,
	const char tranA, 
	const int m, const int n,
	const FP_DTYPE alpha,
	const FP_DTYPE *devA, const int lda,
	const FP_DTYPE *devB, const int incx,
	const FP_DTYPE beta,
	FP_DTYPE *devC, const int incy
) {
	counterInit (oh);
#if defined (PREC_SD)
		fprintf (stderr, "* PREC_SD is not implemented.\n");
		exit (1);
#else
	if (oh->reproModeFlag == 0 && oh->numSplitArraysMax == 1) {
		RCBLAS_GEMV (CblasColMajor, ToCblasOp(tranA), m, n, alpha, devA, lda, devB, incx, beta, devC, incy);
		return 0;
	}
	if (incx != 1 || incy != 1 ) {
		fprintf (stderr, "* incx and incy are not supported.\n");
		exit (1);
	}

	FP_CTYPE fone = 1., fzero = 0.;
	int ione = 1;
	double t1, t0 = timer();
	uint32_t numSplitArraysMax = (oh->numSplitArraysMax > 0) ? oh->numSplitArraysMax : NumSplitDefaultMax;
	int ldas, ldbs, ldcs;
	FP_CTYPE *devASplit;
	FP_CTYPE *devAmax, *devBmax;
	FP_CTYPE *devBSplit, *devCSplit;

	int mbk = m;
	int memAddrTmp = oh->memAddr;
#if defined (PREC_SD)
	int ldat, ldbt;
	FP_CTYPE *devATmp, *devBTmp;
#endif
	while (mbk > 0) {
		if (tranA == 'N' || tranA == 'n') {
			ozblasMallocSplitMat (oh, n, mbk, numSplitArraysMax, &devASplit, &devAmax, ldas); // !! TRANSPOSE !!
			ozblasMallocSplitVec (oh, n, numSplitArraysMax, &devBSplit, &devBmax, ldbs);
			ozblasMallocResultVec (oh, mbk, numSplitArraysMax, &devCSplit, ldcs);
		} else {
			ozblasMallocSplitMat (oh, mbk, n, numSplitArraysMax, &devASplit, &devAmax, ldas); 
			ozblasMallocSplitVec (oh, mbk, numSplitArraysMax, &devBSplit, &devBmax, ldbs);
			ozblasMallocResultVec (oh, n, numSplitArraysMax, &devCSplit, ldcs);
		}
#if defined (PREC_SD)
		if (tranA == 'N' || tranA == 'n') {
			ozblasSDMallocTmpMat (oh, n, mbk, &devATmp, ldat); // transposed
			ozblasSDMallocTmpMat (oh, n, 1, &devBTmp, ldbt);
			ozblasSDCopyMat (n, mbk, devA, lda, devATmp, ldat);
			ozblasSDCopyMat (n, 1, devB, n, devBTmp, ldbt);
		} else {
			ozblasSDMallocTmpMat (oh, mbk, n, &devATmp, ldat);
			ozblasSDMallocTmpMat (oh, mbk, 1, &devBTmp, ldbt);
			ozblasSDCopyMat (mbk, n, devA, lda, devATmp, ldat);
			ozblasSDCopyMat (mbk, 1, devB, mbk, devBTmp, ldbt);
		}
#endif
		if (!memCheck (oh)) break;
		oh->memAddr = memAddrTmp;
		mbk = ceil (mbk / 2.);
	}

	for (int im = 0; im < ceil((float)m/mbk); im++) {
		int mbk_ = (m-mbk*im >= mbk) ? mbk : m-mbk*im;

		// Split of A -----------------------------------
		t1 = timer();
		oh->numSplitArraysA = numSplitArraysMax;
		if (tranA == 'N' || tranA == 'n') {
			#ifdef MKL
			MKL_OMATCOPY ('c', 't', mbk_, n, fone, devA+im*mbk, lda, devASplit, ldas); // TRANSPOSE
			#else
			CBLAS_OMATCOPY (CblasColMajor, CblasTrans, mbk_, n, fone, devA+im*mbk, lda, devASplit, ldas); // TRANSPOSE
			#endif
			ozblasSplitMat (oh, 'c', n, mbk_, devASplit, ldas, devASplit, devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA); // TRANSPOSE
		} else {
			ozblasSplitMat (oh, 'c', mbk_, n, devA+im*mbk, lda, devASplit, devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA); 
		}
		oh->t_SplitA += timer() - t1;

		// Split of B -----------------------------------
		t1 = timer();
		oh->numSplitArraysB = numSplitArraysMax;
		if (tranA == 'N' || tranA == 'n')
			ozblasSplitMat (oh, 'r', n, 1, devB, n, devBSplit, devBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
		else
			ozblasSplitMat (oh, 'r', mbk, 1, devB, mbk, devBSplit, devBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
		oh->t_SplitB += timer() - t1;

		// Compute --------------------------------------
		t1 = timer();
		uint32_t numB, ia, ic = 0;
		uint32_t maxlevel = (oh->numSplitArraysA-1) + (oh->numSplitArraysB-1);
		if (oh->fastModeFlag) {
			if (oh->numSplitArraysMax == 0)	
				maxlevel = MIN (oh->numSplitArraysA-1, oh->numSplitArraysB-1);
			else
				maxlevel = oh->numSplitArraysMax-1;
		}

		FP_CTYPE *ptrA, *ptrB, *ptrC;
		ptrC = devCSplit;
		for (ia = 0; ia < MIN (maxlevel+1, oh->numSplitArraysA); ia++) {
			if (tranA == 'N' || tranA == 'n')
				ptrA = devASplit+ldas*mbk_*ia; // TRANSPOSE
			else
				ptrA = devASplit+ldas*n*ia;
			if (oh->useGemmFlag) {
				numB = MIN (oh->numSplitArraysB, maxlevel+1 - ia);
				ptrB = devBSplit;
				if (tranA == 'N' || tranA == 'n')
					CBLAS_GEMM (CblasColMajor, CblasTrans, CblasNoTrans, mbk_, numB, n, fone, ptrA, ldas, ptrB, ldbs, fzero, ptrC, ldcs);
				else
					CBLAS_GEMM (CblasColMajor, CblasTrans, CblasNoTrans, n, numB, mbk_, fone, ptrA, ldas, ptrB, ldbs, fzero, ptrC, ldcs);
				ptrC += ldcs*numB;
				ic += numB;
			} else {
				for (uint32_t ib = 0; ib < oh->numSplitArraysB; ib++) {
					if (ia + ib <= maxlevel) {
						ptrB = devBSplit+ldbs*ib;
						ptrC = devCSplit+ldcs*ic;
						CBLAS_GEMV (CblasColMajor, CblasTrans, mbk_, n, fone, ptrA, ldas, ptrB, ione, fzero, ptrC, ione);
						ic++;
					}
				}
			}
		}
		oh->numSplitArraysC = ic;
		oh->t_comp += timer() - t1;

		// Sum -----------------------------------------
		t1 = timer();
		if (tranA == 'N' || tranA == 'n')
			ozblasSumMat (mbk_, 1, devCSplit, ldcs, ldcs, oh->numSplitArraysC, &devC[im*mbk], ldcs, alpha, beta, oh->sumModeFlag);
		else
			ozblasSumMat (n, 1, devCSplit, ldcs, ldcs, oh->numSplitArraysC, &devC[im*mbk], ldcs, alpha, beta, oh->sumModeFlag);
		oh->t_sum += timer() - t1;
	}

	oh->t_total = timer() - t0;

#endif
	return 0;
}
