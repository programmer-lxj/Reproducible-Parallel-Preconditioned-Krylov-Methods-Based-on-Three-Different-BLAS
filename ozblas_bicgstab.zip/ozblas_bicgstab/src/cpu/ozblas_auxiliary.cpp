#include "ozblas_common.h"

// =========================================
// Print floating-point value with bit representation
// =========================================
typedef union{
	FP_CTYPE d;
	uint64_t i;
} d_and_i;

void printBits (FP_CTYPE val) {
	d_and_i di;
	di.d = val;
	// sign
	printf ("%zu", (di.i >> 63) & 1);
	printf ("|");
	// exponent
	for (int i = 62; i >= 62-10; i--) 
		printf ("%zu", (di.i >> i) & 1);
	printf ("|");
	// fraction
	for (int i = 62-11; i >= 0; i--) 
		printf ("%zu", (di.i >> i) & 1);
	printf (" : ");
	printf ("%+1.18e", val);
}

// =========================================
// PrintMat (for debugging)
// =========================================
void PrintMat (
	const int32_t m,
	const int32_t n,
	const FP_CTYPE *devC,
	const int32_t ldd
) {
	FP_CTYPE tmp;
	int32_t i, j, ldh;
	ldh = m;
	printf ("\n");
	for (j = 0; j < n; j++) {
		for (i = 0; i < m; i++) {
			tmp = devC[j*ldh+i];
			if (tmp != 0) {
				printf ("[%2d,%2d] ", j, i);
				printBits (tmp);
				printf ("\n");
			}
		}
	}
	printf ("\n");
}

void PrintMatInt (
	const int32_t m,
	const int32_t n,
	const int32_t *devC,
	const int32_t ldd
) {
	int32_t tmp;
	int32_t i, j, ldh;
	ldh = m;
	printf ("\n");
	for (j = 0; j < n; j++) {
		for (i = 0; i < m; i++) {
			tmp = devC[j*ldh+i];
		//	if (tmp != 0) {
				printf ("[%2d,%2d] %d", j, i, tmp);
				printf ("\n");
		//	}
		}
	}
	printf ("\n");
}

void ozblasPrintVec (
	const int32_t n,
	const FP_DTYPE *devC
) {
	for (int32_t i = 0; i < n; i++) 
		printf ("%1.18e\n", devC[i]);
}

// =========================================
// Matrix Allocation
// =========================================
void ozblasMallocSplitVec (
	ozblasHandle_t *oh,
	const int n,
	const uint32_t numSplitArraysMax,
	FP_CTYPE **devSplit,
	FP_CTYPE **devMax,
	int &lds
) {
	// oh->workSizeBytes; // size of work memory [Bytes]
	// oh->devWork; // the start point of the work memory
	// devXsplit starts from the end of devXsplit0
	lds = getPitchSize (n);
	devSplit[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds * numSplitArraysMax; 
	int ldv = 1;
	// '+1': devMax needs work areas staring from [getPitchSize(1)]
	devMax[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * ldv;
	memCheck (oh);
}

void ozblasMallocResultVec (
	ozblasHandle_t *oh,
	const int n,
	const uint32_t numSplitArraysMax,
	FP_CTYPE **devSplit,
	int &lds
) {
	lds = getPitchSize (n);
	devSplit[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds * numSplitArraysMax * numSplitArraysMax;
	memCheck (oh);
}

void ozblasMallocSplitMat (
	ozblasHandle_t *oh,
	const int m,
	const int n,
	const uint32_t numSplitArraysMax,
	FP_CTYPE **devSplit,
	FP_CTYPE **devMax,
	int &lds
) {
	lds = getPitchSize (m);
	devSplit[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds * n * (numSplitArraysMax + 1); // +1 is for output (work)
	devMax[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds;
	memCheck (oh);
}

#if defined (PREC_SD)
void ozblasSDMallocTmpVec (
	ozblasHandle_t *oh,
	const int n,
	FP_CTYPE **devTmp,
	int &lds
) {
	lds = getPitchSize (n);
	devTmp[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds;
}

void ozblasSDMallocTmpMat (
	ozblasHandle_t *oh,
	const int m,
	const int n,
	FP_CTYPE **devTmp,
	int &lds
) {
	lds = getPitchSize (m);
	devTmp[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds * n; // +1 is for output (work)
}

void ozblasSDCopyMat (
	const int m,
	const int n,
	const FP_DTYPE *devA,
	const int lda,
	FP_CTYPE *devB,
	const int ldb
) {
	int i, j;
	#pragma omp parallel for private (i)
	for (j = 0; j < n; j++){
		for (i = 0; i < m; i++)
			devB[j*ldb+i] = devA[j*lda+i];
	}
}

void ozblasCopyVec (
	const int n,
	const FP_CTYPE *devA,
	FP_CTYPE *devB
) {
	int i;
	#pragma omp parallel for
	for (i = 0; i < n; i++)
		devB[i] = devA[i];
}

#endif

void ozblasMallocResultMat (
	ozblasHandle_t *oh,
	const int m,
	const int n,
	const uint32_t numSplitArraysMax,
	FP_CTYPE **devSplit,
	int &lds
) {
	lds = getPitchSize (m);
	devSplit[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds * n * numSplitArraysMax * numSplitArraysMax;
	memCheck (oh);
}

void ozblasMallocSplitMatSparse (
	ozblasHandle_t *oh,
	const int m,
	const int nnz,
	const uint32_t numSplitArraysMax,
	FP_CTYPE **devSplit,
	FP_CTYPE **devMax,
	int &lds
) {
	lds = getPitchSize (nnz);
	devSplit[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * lds * (numSplitArraysMax + 1); // +1 is for output (work)
	devMax[0] = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * getPitchSize(m);
}

