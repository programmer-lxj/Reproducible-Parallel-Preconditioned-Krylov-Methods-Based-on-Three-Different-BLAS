#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

// setting
#define DefaultWorkSize 1e9 // 1GB
#define NumSplitDefaultMax 20

#include <stdio.h>
#include <stdlib.h>
#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include <sys/time.h>
#include <float.h>

#ifdef NVBLAS
#include <nvblas.h>
#endif
#ifdef MKL
#include <mkl.h>
#else
#include <cblas.h>
#endif

#include <math.h>
#include <omp.h>
#include "../../include/ozblas.h"
#include "ozblas_internal.h"

#if defined (PREC_S)
#define FP_DTYPE	float
#define FP_CTYPE	float
#define UNIT	24

#define OzCG	ozblasScg
#define OzDOT	ozblasSdot 
#define OzAXPY	ozblasSaxpy 
#define OzGEMV	ozblasSgemv
#define OzGEMM	ozblasSgemm
#define OzNRM2	ozblasSnrm2
#define OzCSRMV	ozblasScsrmv
#define OzCSRMVSplitA ozblasScsrmvSplitA

#define RCBLAS_AXPY	cblas_saxpy 
#define RCBLAS_DOT	cblas_sdot 
#define RCBLAS_GEMV	cblas_sgemv
#define RCBLAS_GEMM	cblas_sgemm
#define RNVBLAS_GEMM	sgemm
#define RCBLAS_NRM2	cblas_snrm2
#define RMKL_CSRMV	mkl_scsrmv

#define NVBLAS_GEMM			sgemm
#define NVBLAS_GEMMBATCH	sgemm_batch
#define MKL_OMATCOPY		mkl_somatcopy
#define MKL_CSRMV			mkl_scsrmv
#define MKL_CSRMM			mkl_scsrmm

#define CBLAS_OMATCOPY	cblas_somatcopy
#define CBLAS_AXPY	cblas_saxpy 
#define CBLAS_DOT	cblas_sdot 
#define CBLAS_GEMV	cblas_sgemv
#define CBLAS_GEMM	cblas_sgemm
#define CBLAS_GEMMBATCH cblas_sgemm_batch
#define CBLAS_NRM2	cblas_snrm2
#define CBLAS_SCAL	cblas_sscal
#define CBLAS_ASUM	cblas_sasum 
#define CBLAS_IAMAX	cblas_isamax

#define ozblasMallocSplitMat		ozblasSMallocSplitMat
#define ozblasMallocSplitMatSparse	ozblasSMallocSplitMatSparse
#define ozblasMallocResultMat		ozblasSMallocResultMat
#define ozblasMallocSplitVec		ozblasSMallocSplitVec
#define ozblasMallocResultVec		ozblasSMallocResultVec
#define ozblasSplitMat				ozblasSSplitMat
#define ozblasSplitMatSparse		ozblasSSplitMatSparse
#define ozblasSplitShiftMat			ozblasSSplitShiftMat
#define ozblasSplitShiftMatSparse	ozblasSSplitShiftMatSparse
#define ozblasSumMat				ozblasSSumMat
#define ozblasSumMatNpara			ozblasSSumMatNpara
#define ozblasPrintVec				ozblasSPrintVec
#define ozblasCopyVec				ozblasSCopyVec

#elif defined (PREC_D)

#define FP_DTYPE	double
#define FP_CTYPE	double
#define UNIT	53

#define OzCG	ozblasDcg
#define OzDOT	ozblasDdot 
#define OzAXPY	ozblasDaxpy 
#define OzGEMV	ozblasDgemv
#define OzGEMM	ozblasDgemm
#define OzNRM2	ozblasDnrm2
#define OzCSRMV	ozblasDcsrmv
#define OzCSRMVSplitA ozblasDcsrmvSplitA

#define RCBLAS_AXPY	cblas_daxpy 
#define RCBLAS_DOT	cblas_ddot 
#define RCBLAS_GEMV	cblas_dgemv
#define RCBLAS_GEMM	cblas_dgemm
#define RNVBLAS_GEMM	dgemm
#define RCBLAS_NRM2	cblas_dnrm2
#define RMKL_CSRMV	mkl_dcsrmv

#define NVBLAS_GEMM			dgemm
#define NVBLAS_GEMMBATCH	dgemm_batch
#define MKL_OMATCOPY		mkl_domatcopy
#define MKL_CSRMV			mkl_dcsrmv
#define MKL_CSRMM			mkl_dcsrmm

#define CBLAS_OMATCOPY	cblas_domatcopy
#define CBLAS_AXPY	cblas_daxpy 
#define CBLAS_DOT	cblas_ddot 
#define CBLAS_GEMV	cblas_dgemv
#define CBLAS_GEMM	cblas_dgemm
#define CBLAS_GEMMBATCH cblas_dgemm_batch
#define CBLAS_NRM2	cblas_dnrm2
#define CBLAS_SCAL	cblas_dscal
#define CBLAS_ASUM	cblas_dasum 
#define CBLAS_IAMAX	cblas_idamax

#define ozblasMallocSplitMat		ozblasDMallocSplitMat
#define ozblasMallocSplitMatSparse	ozblasDMallocSplitMatSparse
#define ozblasMallocResultMat		ozblasDMallocResultMat
#define ozblasMallocSplitVec		ozblasDMallocSplitVec
#define ozblasMallocResultVec		ozblasDMallocResultVec
#define ozblasSplitMat				ozblasDSplitMat
#define ozblasSplitMatSparse		ozblasDSplitMatSparse
#define ozblasSplitShiftMat			ozblasDSplitShiftMat
#define ozblasSplitShiftMatSparse	ozblasDSplitShiftMatSparse
#define ozblasSumMat				ozblasDSumMat
#define ozblasSumMatNpara			ozblasDSumMatNpara
#define ozblasPrintVec				ozblasDPrintVec
#define ozblasCopyVec				ozblasDCopyVec

#elif defined (PREC_SD)

#define FP_DTYPE	float
#define FP_CTYPE	double
#define UNIT	53

#define OzCG	ozblasSDcg
#define OzDOT	ozblasSDdot 
#define OzAXPY	ozblasSDaxpy 
#define OzGEMV	ozblasSDgemv
#define OzGEMM	ozblasSDgemm
#define OzNRM2	ozblasSDnrm2
#define OzCSRMV	ozblasSDcsrmv
#define OzCSRMVSplitA ozblasSDcsrmvSplitA

#define RCBLAS_AXPY	cblas_saxpy 
#define RCBLAS_DOT	cblas_sdot 
#define RCBLAS_GEMV	cblas_sgemv
#define RCBLAS_GEMM	cblas_sgemm
#define RNVBLAS_GEMM	sgemm
#define RCBLAS_NRM2	cblas_snrm2
#define RMKL_CSRMV	mkl_scsrmv

#define NVBLAS_GEMM			dgemm
#define NVBLAS_GEMMBATCH	dgemm_batch
#define MKL_OMATCOPY		mkl_domatcopy
#define MKL_CSRMV			mkl_dcsrmv
#define MKL_CSRMM			mkl_dcsrmm

#define CBLAS_OMATCOPY	cblas_domatcopy
#define CBLAS_AXPY	cblas_daxpy 
#define CBLAS_DOT	cblas_ddot 
#define CBLAS_GEMV	cblas_dgemv
#define CBLAS_GEMM	cblas_dgemm
#define CBLAS_GEMMBATCH cblas_dgemm_batch
#define CBLAS_NRM2	cblas_dnrm2
#define CBLAS_SCAL	cblas_sscal // <- 's'
#define CBLAS_ASUM	cblas_dasum 
#define CBLAS_IAMAX	cblas_idamax

#define ozblasMallocSplitMat		ozblasSDMallocSplitMat
#define ozblasMallocSplitMatSparse	ozblasSDMallocSplitMatSparse
#define ozblasMallocResultMat		ozblasSDMallocResultMat
#define ozblasMallocSplitVec		ozblasSDMallocSplitVec
#define ozblasMallocResultVec		ozblasSDMallocResultVec
#define ozblasSplitMat				ozblasSDSplitMat
#define ozblasSplitMatSparse		ozblasSDSplitMatSparse
#define ozblasSplitShiftMat			ozblasSDSplitShiftMat
#define ozblasSplitShiftMatSparse	ozblasSDSplitShiftMatSparse
#define ozblasSumMat				ozblasSDSumMat
#define ozblasSumMatNpara			ozblasSDSumMatNpara
#define ozblasPrintVec				ozblasSDPrintVec
#define ozblasCopyVec				ozblasSDCopyVec

#endif


