#include "ozblas_common.h"

// =========================================
// NearSum (and AccSum)
// from "ACCURATE FLOATING-POINT SUMMATION" by S.M.RUMP, T.OGITA, S.OISHI (2005)
// http://www.ti3.tu-harburg.de/paper/rump/RuOgOi06.pdf
// =========================================
void ozblasTransform (const int32_t n, FP_CTYPE *vec, const int32_t ld, double rho, double &tau1, double &tau2) {
	int32_t i, m;
	double tmp, mu, sigma, t, tau;

	mu = fabs(vec[0]);
	for (i = 1; i < n; i++)
		mu = MAX (mu, fabs(vec[i*ld])); 
	if ((n == 0) || (mu == 0.)) {
		tau1 = rho;
		tau2 = 0.;
		return;
	}

	m = ceil (log2((double)(n+2)));
	sigma = scalbn (1., m+ceil(log2(mu)));
	t = rho;
	while (1) {
		// ExtractVector
		tau = 0.;
		for (i = 0; i < n; i++) {
			tmp = (sigma + vec[i*ld]) - sigma;
			vec[i*ld] -= tmp;  // <- output
			tau += tmp;
		}
		// here, tau1 = t1
		tau1 = t + tau;
		if ((sigma <= scalbn (1., -1022)) || (fabs(tau1) >= scalbn (1., 2*m+1-53)*sigma)) {
			//FastTwoSum (t, tau, &tau1, &tau2);
			//tau1 = t + tau
			tau2 = tau - (tau1 - t);
			return;
		}
		sigma = scalbn (1., m-53) * sigma;
		t = tau1;
	} 
}

void ozblasTransformK (const int32_t n, FP_CTYPE *vec, const int32_t ld, double rho, double &res, double &r) { 
	double tmp, tau1, tau2;
	ozblasTransform (n, vec, ld, rho, tau1, tau2);
	tmp = 0.;
	for (int32_t i = 0; i < n; i++)
		tmp += vec[i*ld];
	res = tau1 + (tau2 + tmp);
	r = tau2 - (res - tau1);
}

__inline__
double cuSign (double v) {
	return (v < 0) ? -1.:1.;
}

double ozblasNearSum (const int32_t n, FP_CTYPE *vec, const int32_t ld) {
	double tmp, res, res2, r, r2, mu, delta, delta2;
	double eps = scalbn (1., -53);

	ozblasTransformK (n, vec, ld, 0, res, r);
	ozblasTransformK (n, vec, ld, r, delta, r2);
	if (delta == 0) 
		return res;
	res2 = res + cuSign (delta) * eps * fabs(res);
	if (res2 == res) {
		mu = cuSign (delta) * eps * fabs(res);
		res2 = res + 2. * cuSign (delta) * eps * fabs(res);
	} else {
		mu = (res2 - res) / 2.;
	}
	if (fabs(delta) < fabs(mu)) 
		return res;
	if (fabs(delta) > fabs(mu)) 
		return res2;
	ozblasTransformK (n, vec, ld, r2, delta2, tmp);
	if (delta2 == 0) 
		return res + mu;
	if (cuSign (delta2) == cuSign (mu))
		return res2;
	return res;
}

// =========================================
// NearSumMat
// =========================================
void ozblasNearSumMatPdevKernel (
	const int32_t m,
	const int32_t n,
	FP_CTYPE *devCsplit,
	const int32_t llsc,
	const int32_t ldsc,
	const int32_t numsplit,
	FP_DTYPE *devC,
	const int32_t ldc,
	const FP_DTYPE alpha,
	const FP_DTYPE beta
) {
	double t;
	int32_t addrx, addry;
	#pragma omp parallel for private (addry, t)
	for (addrx = 0; addrx < m; addrx++) {
		for (addry = 0; addry < n; addry++) {
			t = ozblasNearSum (numsplit, &devCsplit[addry * ldsc + addrx], llsc);
			if (beta == 0.) 
				devC[addry * ldc + addrx] = (FP_CTYPE)alpha * t;
			else
				devC[addry * ldc + addrx] = fma ((FP_CTYPE)alpha, t, (FP_CTYPE)beta * (FP_CTYPE)devC[addry * ldc + addrx]);
		}
	}
}

void ozblasSumMatPdevKernel (
	const int32_t m,
	const int32_t n,
	const FP_CTYPE *devCsplit,
	const int32_t llsc,
	const int32_t ldsc,
	const int32_t numsplit,
	FP_DTYPE *devC,
	const int32_t ldc,
	const FP_DTYPE alpha,
	const FP_DTYPE beta
) {
	FP_CTYPE t;
	int32_t addrx, addry;
	#pragma omp parallel for private (addry, t)
	for (addrx = 0; addrx < m; addrx++) {
		for (addry = 0; addry < n; addry++) {
			t = 0.;
			for (int32_t i = numsplit-1; i >= 0; i--)
				t += (FP_CTYPE)devCsplit[llsc * i + addry * ldsc + addrx];
			if (beta == 0.) 
				devC[addry * ldc + addrx] = (FP_CTYPE)alpha * t;
			else
				devC[addry * ldc + addrx] = fma ((FP_CTYPE)alpha, t, (FP_CTYPE)beta * (FP_CTYPE)devC[addry * ldc + addrx]);
		}
	}
}

void ozblasSumMat (
	const int32_t m,
	const int32_t n,
	FP_CTYPE *devCsplit,
	const int32_t llsc,
	const int32_t ldsc,
	const int32_t numsplit,
	FP_DTYPE *devC,
	const int32_t ldc,
	const FP_DTYPE alpha,
	const FP_DTYPE beta,
	const uint32_t sumModeFlag
) {
	if (sumModeFlag)
		ozblasNearSumMatPdevKernel (m, n, devCsplit, llsc, ldsc, numsplit, devC, ldc, alpha, beta);
	else
		ozblasSumMatPdevKernel (m, n, devCsplit, llsc, ldsc, numsplit, devC, ldc, alpha, beta);
}

