#include "ozblas_common.h"

void ozblasCopyVec (
	const size_t n,
	const FP_DTYPE *devIn,
	FP_DTYPE *devOut
) {
	#pragma omp parallel for 
	for (size_t i = 0; i < n; i++) {
		devOut[i] = devIn[i];
	}
}

// true residual is computed using standard FP operations
FP_DTYPE getTrueResidual (
	ozblasHandle_t *oh,
	const char tranA, 
	const int32_t dimN,
	const int32_t dimNNZ,
	const char *descrA, 
	const FP_DTYPE *matA,
	const int32_t *matArowptr,
	const int32_t *matAcolind,
    const FP_DTYPE *vecB,
	const FP_DTYPE *vecX,
	FP_DTYPE *vecT
) {
    FP_DTYPE res0, fone = 1., fnegone = -1.;
	// residual: r_i = b-Ax_i
	ozblasCopyVec (dimN, vecB, vecT);  // t = b
	RMKL_CSRMV (&tranA, &dimN, &dimN, &fnegone, descrA, matA, matAcolind, matArowptr, matArowptr+1, vecX, &fone, vecT); // t = t-Ax (b-Ax)
	res0 = RCBLAS_NRM2 (dimN, vecT, 1);
	return res0;
}

// 函数用于获取CSR格式矩阵的对角元素
 void getDiagonalElements(const FP_DTYPE *csrMatrix, const int32_t rows, const int32_t *row_ptr, const int32_t *col_idx, FP_DTYPE *diagonal) 
 {
     for (int i = 0; i < rows; i++) 
     {
           for (int j = row_ptr[i]; j < row_ptr[i + 1]; j++) 
           {
                      if (col_idx[j] == i) 
 		      {
                                     //diagonal[i] = csrMatrix[j];
                                     diagonal[i] = csrMatrix[j];
                                     break; // 找到对角元素后，退出内循环
                      }
           }
     }
 }

// 函数用于计算两个向量的逐元素相乘
 void vectorMultiply(const FP_DTYPE *vector1, const FP_DTYPE *vector2, FP_DTYPE *result, int size) 
 {
    for (int i = 0; i < size; i++) 
    {
           result[i] = vector1[i] * vector2[i];
    }
 }


FP_DTYPE norm_inf(int n_dist, FP_DTYPE *xsolu, FP_DTYPE *xhat) {
    FP_DTYPE nrm = 0.0;

    for (int i = 0; i < n_dist; i++) {
        FP_DTYPE tmp = fabs(xsolu[i]-xhat[i]);
        if (nrm < tmp)
            nrm = tmp;
    }

    return nrm;
}



int32_t
OzCG (
	ozblasHandle_t *oh,
	const char tranA, 
	const int32_t dimN,
	const int32_t dimNNZ,
	const char *descrA, 
	const FP_DTYPE *matA,
	const int32_t *matArowptr,
	const int32_t *matAcolind,
        const FP_DTYPE *vecB,
	FP_DTYPE *vecX,
	int32_t maxiter,
	double tol
) {
	// =================================
	oh->t_SplitMat_total = 0.;
	oh->t_SplitVec_total = 0.;
	oh->t_Sum_total = 0.;
	oh->t_AXPY_SCAL_total = 0.;
	oh->t_DOT_NRM2_total = 0.;
	oh->t_SpMV_SpMM_total = 0.;
	// =================================

	int32_t numiter;
    double t0, t1, t2, t3;
	float *dat1, *dat2;
	if (oh->verbose > 0) {
		dat1 = (float *)malloc(sizeof(float)*maxiter/oh->verbose+1);
		dat2 = (float *)malloc(sizeof(float)*maxiter/oh->verbose+1);
	}

	t1 = timer(); // -----------------------------------------------------

    FP_DTYPE alpha, beta, negalpha, resi, res0, nrmb, tmp, dnew, dold, rou0, rou1, rv, alpha1, alpha0, alphan, sn, ts, tt, omega, omega1, omegan, beom, xinf;
    FP_DTYPE fzero = 0., fone = 1., fnegone = -1.;
    FP_DTYPE *vecT, *vecR, *vecP, *vecQ, *vecR0, *vecR00, *vecX1, *vecX0, *p1, *p0, *v1, *v0, *s, *t, *diags, *p_hat, *s_hat, *exsol, *vecBB;
	vecT = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	vecR = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	vecP = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	vecQ = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	vecR0 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	vecR00 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	//vecX1 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	//vecX0 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	
	vecX1 = (FP_DTYPE *)calloc(dimN,sizeof(FP_DTYPE));
	vecX0 = (FP_DTYPE *)calloc(dimN,sizeof(FP_DTYPE));
	exsol = (FP_DTYPE *)calloc(dimN,sizeof(FP_DTYPE));
	vecBB = (FP_DTYPE *)calloc(dimN,sizeof(FP_DTYPE));
	
	p1 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	p0 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	v1 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	v0 = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	s = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	t = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	diags = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	p_hat = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	s_hat = (FP_DTYPE *)malloc(sizeof(FP_DTYPE) * dimN);
	
#if 1
    int i;
    //CreateDoubles (&y, n_dist);
    //CreateInts (&posd, n_dist);
    //CreateDoubles (&diags, n_dist);
    getDiagonalElements (matA,dimN, matArowptr, matAcolind, diags);
#pragma omp parallel for
    for (i=0; i<dimN; i++)
        diags[i] = 1.0 / diags[i];
#endif

	

	//printf("111\n");

	#if defined (PREC_SD)
	printf ("## * On PREC_SD mat-split is performed at each iterration\n");
	float *matASplit;
	matASplit = (float*)matA;
	#else
	FP_DTYPE *matASplit;
	OzCSRMVSplitA (oh, tranA, dimN, dimN, dimNNZ, descrA, matA, matArowptr, matAcolind, &matASplit);
	#endif
	//printf("222\n");
        
	ozblasCopyVec (dimN, vecB, exsol);  // exsol = 1
        OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fone, descrA, matASplit, matArowptr, matAcolind, exsol, fzero, vecBB); // b = Ax
 
 	nrmb = OzNRM2 (oh, dimN, vecBB, 1); // nrmb = |b|
	// residual: r_0 = b-Ax_0
	ozblasCopyVec (dimN, vecBB, vecR0);  // r = b
        //得看一下vecX是0初值还是1初值，包括下面的vecX0和vecX1，输出来看一下
        //vecX传进来是0，初值是0，没问题，以这个为准！
	OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fnegone, descrA, matASplit, matArowptr, matAcolind, vecX, fone, vecR0); // r = r-Ax (b-Ax)
	ozblasCopyVec (dimN, vecR0, vecR00);  // r00 = r0
	ozblasCopyVec (dimN, vecR0, vecR);  // r1 = r0
	resi = OzDOT (oh, dimN, vecR, 1, vecR, 1); // dold = <r,r>
	resi = sqrt (resi); // resi = |r|
	if (oh->verbose > 0) {
		t3 = timer();
		dat1[0] = resi/nrmb;
		dat2[0] = (oh->trueres==0) ? t3-t1 : getTrueResidual (oh, tranA, dimN, dimNNZ, descrA, matA, matArowptr, matAcolind, vecBB, vecX, vecT) / nrmb;
	}
	//ozblasCopyVec (dimN, vecR, vecP);  // p = r
	
    numiter = 0;
	t2 = timer(); // -----------------------------------------------------
    //while ( (resi>tol) && (numiter < maxiter))
	
    //vecX初值是1，因此vecX0，vecX1要初始化为1
    //注意和之前代码不同，之前代码初值是0
    ozblasCopyVec (dimN, vecX, vecX1);  // t = b

    ozblasCopyVec (dimN, vecX, vecX0);  // t = b
    while ( (numiter < maxiter)) 
    {
/*
	ozblasCopyVec (dimN, vecB, vecT);  // t = b
	
	OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fnegone, descrA, matASplit, matArowptr, matAcolind, vecX, fone, vecT); // r = b-Ax
	double res_true = OzNRM2 (oh, dimN, vecT, 1);
	
	
	ozblasCopyVec (dimN, vecB, vecT);  // t = b
	OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fnegone, descrA, matASplit, matArowptr, matAcolind, vecX1, fone, vecT); // r = b-Ax
	double res_true_x1 = OzNRM2 (oh, dimN, vecT, 1);
	
	printf("%d \t %e \t %e \t %e \n", numiter, res_true/nrmb, res_true_x1/nrmb, resi/nrmb);
*/
	
	//printf("333\n");
	rou1 = OzDOT (oh, dimN, vecR0, 1, vecR00, 1); // dold = <r,r>

	if(rou1==0)
	{
		ozblasCopyVec (dimN, vecX1, vecX);  // x = x1
		printf("rou1=0,iterative failed!\n");
		break;
	}
	
	if(numiter==0)
	{
		ozblasCopyVec (dimN, vecR0, p1);  // p = r
	}
	else
	{
		beta=(rou1/rou0)*(alpha0/omega);
		beom=-beta*omega;
		ozblasCopyVec (dimN, vecR0, p1);  // p = r
		OzAXPY (oh, dimN, beta, p0, 1, p1, 1); // p += r
		OzAXPY (oh, dimN, beom, v0, 1, p1, 1); // p -= beta*omega * v
	}

	//printf("444\n");
	vectorMultiply(diags, p1, p_hat, dimN);	
	OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fone, descrA, matASplit, matArowptr, matAcolind, p_hat, fzero, v1); // v = Ap_hat
	//OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fone, descrA, matASplit, matArowptr, matAcolind, p1, fzero, v1); // v = Ap
	rv = OzDOT (oh, dimN, v1, 1, vecR00, 1); // dold = <r,r>
	alpha1=rou1/rv;
	alphan=-1.0*alpha1;
	ozblasCopyVec (dimN, vecR0, s);  // s = r
	OzAXPY (oh, dimN, alphan, v1, 1, s, 1); // s = r-alpha*v
	sn = OzDOT (oh, dimN, s, 1, s, 1); // sn = <s,s>
	sn = sqrt (sn); // sn = |s|
	
	//printf("444-1,%d\n",numiter);
	
	vectorMultiply(diags, s, s_hat, dimN);	
	OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fone, descrA, matASplit, matArowptr, matAcolind, s_hat, fzero, t); // t = As_hat
	//OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fone, descrA, matASplit, matArowptr, matAcolind, s, fzero, t); // t = As
	
	//printf("444-1-0,%d\n",numiter);
	
	ts = OzDOT (oh, dimN, t, 1, s, 1); // ts = <t,s>
	tt = OzDOT (oh, dimN, t, 1, t, 1); // tt = <t,t>
	omega1 = ts/tt;

	//printf("444-1-1, %d\n",numiter);

	ozblasCopyVec (dimN, vecX0, vecX1);  // x1 = x0
	OzAXPY (oh, dimN, alpha1, p_hat, 1, vecX1, 1); // x1 = x1+alpha*p
	OzAXPY (oh, dimN, omega1, s_hat, 1, vecX1, 1); // x1 = x1+omega*s
	//OzAXPY (oh, dimN, alpha1, p1, 1, vecX1, 1); // x1 = x1+alpha*p
	//OzAXPY (oh, dimN, omega1, s, 1, vecX1, 1); // x1 = x1+omega*s
	omegan=-1.0*omega1;

	//printf("444-1-2, %d\n",numiter);

	ozblasCopyVec (dimN, s, vecR);  // r = s
	OzAXPY (oh, dimN, omegan, t, 1, vecR, 1); // r = s-omega*t
	resi = OzDOT (oh, dimN, vecR, 1, vecR, 1); // resi = <r,r>
	resi = sqrt (resi); // resi = |r|
	
	//printf("444-2\n");
	
	rou0=rou1;
	alpha0=alpha1;
	omega=omega1;
	ozblasCopyVec (dimN, vecR, vecR0);  // r0 = r1
	ozblasCopyVec (dimN, p1, p0);  // p0 = p1
	ozblasCopyVec (dimN, v1, v0);  // v0 = v1
	ozblasCopyVec (dimN, vecX1, vecX0);  // x0 = x1
	ozblasCopyVec (dimN, vecX1, vecX);  // x = x1

        numiter++;
	
	if(omega1==0)
	{
		ozblasCopyVec (dimN, vecX1, vecX);  // x = x1
		printf("w=0, back\n");
		break;
	}
	//printf("444-3\n");

		//OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fone, descrA, matASplit, matArowptr, matAcolind, vecP, fzero, vecQ); // q = Ap
		//tmp = OzDOT (oh, dimN, vecP, 1, vecQ, 1); // tmp = <p,q>
        //alpha = dold / tmp;
		//negalpha = -alpha;

		t0 = timer();
		//OzAXPY (oh, dimN, alpha, vecP, 1, vecX, 1); // x = x+alpha*p
		//OzAXPY (oh, dimN, negalpha, vecQ, 1, vecR, 1); // r = r-alpha*q
		oh->t_AXPY_SCAL_total += timer() - t0;

		//dnew = OzDOT (oh, dimN, vecR, 1, vecR, 1); // dnew = <r,r>
		//resi = sqrt(dnew);
        //beta = dnew / dold; // beta = dnew/dold
		//dold = dnew;

		t0 = timer();
        //CBLAS_SCAL (dimN, beta, vecP, 1); // p = beta*p
		//OzAXPY (oh, dimN, fone, vecR, 1, vecP, 1); // p = p+r
		oh->t_AXPY_SCAL_total += timer() - t0;

		if (oh->verbose > 0) {
			if (numiter%oh->verbose == 0 ) {
				t3 = timer();
				dat1[numiter/oh->verbose] = resi/nrmb;
				dat2[numiter/oh->verbose] = (oh->trueres==0) ? t3-t1 : getTrueResidual (oh, tranA, dimN, dimNNZ, descrA, matA, matArowptr, matAcolind, vecBB, vecX, vecT) / nrmb;
            }
        }
	//edit	
	//ozblasCopyVec (dimN, vecB, vecT);  // t = b
	
	//OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fnegone, descrA, matASplit, matArowptr, matAcolind, vecX, fone, vecT); // r = b-Ax
	//double res_true = OzNRM2 (oh, dimN, vecT, 1);
	//printf("%d \t %f \t %e \n", numiter, res_true/nrmb, resi/nrmb);
        
	printf("##########\n"); 
	xinf = norm_inf(dimN,exsol,vecX);
	printf ("Size: %d \n", dimN);
        printf ("Iter: %d \n", numiter);
        printf ("Tol: %a \n", resi);
        //printf("flag: %d \n",flag);
        printf ("Tol: %20.15e \n", resi);
        //printf ("Direct_error: %20.15e \n", direct_err);
	printf ("## ||exsol-xhat|| = %1.3e\n", xinf);
	printf("##########\n"); 
        //printf ("Time_loop: %20.15e\n", (t3-t1));
        //                                        printf ("Time_iter: %20.15e\n", (t3-t1)/iter);
        

        //if (resi/nrmb < tol) break;
        if (resi < tol) break;
    }
	t3 = timer(); // -----------------------------------------------------
	//printf("555\n");
	// =================================
	double tloc_SpMV_SpMM_total = oh->t_SpMV_SpMM_total;
	double tloc_DOT_NRM2_total = oh->t_DOT_NRM2_total;
	double tloc_AXPY_SCAL_total = oh->t_AXPY_SCAL_total;
	double tloc_Sum_total = oh->t_Sum_total;
	double tloc_SplitVec_total = oh->t_SplitVec_total;
	double tloc_SplitMat_total = oh->t_SplitMat_total;
	double tloc_Other_total = (t3-t1) -tloc_SpMV_SpMM_total -tloc_DOT_NRM2_total -tloc_AXPY_SCAL_total
									-tloc_Sum_total -tloc_SplitVec_total -tloc_SplitMat_total;
	// =================================
	
	if (oh->verbose > 0) {
		// residual: r_i = b-Ax_i (correctly-rounded)
		ozblasCopyVec (dimN, vecBB, vecT);  // t = b
		oh->memMaskSplitA = 0; // this is needed
		oh->numSplitArraysMax = 0;
		oh->reproModeFlag = 1;
		oh->fastModeFlag = 0;
		oh->sumModeFlag = 1;
		OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fnegone, descrA, matA, matArowptr, matAcolind, vecX, fone, vecT); // t = t-Ax (b-Ax)
		res0 = OzNRM2 (oh, dimN, vecT, 1);
		xinf = norm_inf(dimN,exsol,vecX);
		// note: parameter-reset is needed here if user wants to continue the use of OzBLAS later on

		if (oh->trueres) 
			printf ("\n## iter\t||r_i||/||b||\t||b-Ax||/||b||\n");
		else
			printf ("\n## iter\t||r_i||/||b||\ttime(sec)\n");
		for (int32_t i = 1; i <= numiter/oh->verbose; i++) 
			printf ("%d\t%1.3e\t%1.3e\n", i*oh->verbose, dat1[i], dat2[i]);
		printf ("## total time = %1.3e\n", t3-t1);
		if (oh->trueres) printf ("## -> including true residual computation\n");
		printf ("## iter-part time = %1.3e\n", t3-t2);
		if (oh->trueres) printf ("## -> including true residual computation\n");
		printf ("## total iter = %d\n", numiter);
		printf ("## time per iter = %1.3e\n", (t3-t2)/numiter);
		printf ("## ||r_i||/||b|| = %1.3e\n", resi/nrmb);
		printf ("## ||b-Ax||/||b|| = %1.3e\n", res0/nrmb);
		printf ("## ||r_i|| = %1.3e\n", resi);
		printf ("## ||b-Ax|| = %1.3e\n", res0);
		printf ("## ||exsol-xhat|| = %1.3e\n", xinf);
	// =================================
		printf ("%1.3e\t", tloc_SpMV_SpMM_total);
		printf ("%1.3e\t", tloc_DOT_NRM2_total);
		printf ("%1.3e\t", tloc_AXPY_SCAL_total);
		printf ("%1.3e\t", tloc_Sum_total);
		printf ("%1.3e\t", tloc_SplitVec_total);
		printf ("%1.3e\t", tloc_SplitMat_total);
		printf ("%1.3e\t#(SpMV/MM, DOT/NRM, AXPY/SCAL, Sum, SpltVec, SpltMat, Other)\n", tloc_Other_total);
	// =================================
		printf ("%d\t%1.3e\t(%a)\t%1.3e\t(%a)\t%1.3e\t%1.3e\t#(iter, res/b, trueres/b, ttl-time, itr-prt-time)\n", numiter, resi/nrmb, resi/nrmb, res0/nrmb, res0/nrmb, t3-t1, t3-t2);
		printf ("%d  %1.3e(%a)  %1.3e(%a)  %1.3e(%a) %1.3e %1.3e #(iter, res, trueres, ttl-time, itr-prt-time)\n", numiter, resi, resi, res0, res0, xinf, xinf, t3-t1, t3-t2);
		free (dat1);
		free (dat2);
	}
    free (vecT);
    free (vecR);
    free (vecP);
    free (vecQ);
    free (vecR0);
    free (vecR00);
    free (vecX1);
    free (vecX0);
    free (p1);
    free (p0);
    free (v1);
    free (v0);
    free (s);


	// =================================
	oh->t_SplitMat_total = 0.;
	oh->t_SplitVec_total = 0.;
	oh->t_Sum_total = 0.;
	oh->t_AXPY_SCAL_total = 0.;
	oh->t_DOT_NRM2_total = 0.;
	oh->t_SpMV_SpMM_total = 0.;

	// reset parameters
	oh->memMaskSplitA = 0; // disable pre-split of matA 
	oh->splitShift = 1; // default (no-Splitshift)
	// =================================

	return 0;
}  

