#include "ozblas_common.h"

double timer () {
	struct timeval tv;
	gettimeofday (&tv, NULL);
	return tv.tv_sec + (double) tv.tv_usec * 1.0e-6;
}

int32_t getPitchSize (int32_t n) {
	return ceil((double)n / 128) * 128;
}

uint32_t memCheck (ozblasHandle_t *oh) {
	if (oh->memAddr > oh->workSizeBytes) return 1;
	return 0;
}

void counterInit (ozblasHandle_t *oh) {
	oh->t_SplitA = 0.;
	oh->t_SplitB = 0.;
	oh->t_comp = 0.;
	oh->t_sum = 0.;
	oh->t_total = 0.;
	oh->numSplitArraysA = 0;
	oh->numSplitArraysB = 0;
	oh->numSplitArraysC = 0;
	oh->lastFlagA = 0;
	oh->lastFlagB = 0;
	oh->memAddr = oh->memMaskSplitA;
}

void ozblasCreate (ozblasHandle_t *oh, uint64_t WorkSizeBytes, uint32_t NumSplitArraysMax, uint32_t FastMode, uint32_t ReproMode, uint32_t SumMode) {
	oh->workSizeBytes = (WorkSizeBytes) ? WorkSizeBytes : DefaultWorkSize; 
	oh->numSplitArraysMax = NumSplitArraysMax;
	oh->fastModeFlag = FastMode;
	oh->reproModeFlag = ReproMode;
	oh->sumModeFlag = SumMode;

	// for CG
	oh->memMaskSplitA = 0; // disable pre-split of matA 
	oh->splitShift = 1; // default (no-Splitshift)

	// experimental parameters (default)
	oh->useGemmFlag = 1;
	oh->useMyGemmFlag = 1;
	#ifdef MKL
	oh->useBatchedGemmFlag = 1;
	#else
	oh->useBatchedGemmFlag = 0; // currently OpenBLAS does not support it
	#endif
//	oh->sparseThreshold = 0.;

	// work memory allocation
	char *devWork_;
	devWork_ = (char*) malloc (oh->workSizeBytes);
	oh->devWork = devWork_;

	// batched BLAS
	if (oh->useBatchedGemmFlag) {
		char *devBatchAddr_;
		devBatchAddr_ = (char*) malloc (sizeof(double*) * NumSplitDefaultMax * NumSplitDefaultMax * 3);
		oh->devBatchAddr = devBatchAddr_;
	}
}

void ozblasProfilingSetting (ozblasHandle_t *oh, uint32_t useGemmFlag, uint32_t useMyGemmFlag, uint32_t useBatchedGemmFlag) {
	oh->useGemmFlag = useGemmFlag;
	oh->useMyGemmFlag = useMyGemmFlag;
	#ifdef MKL
	oh->useBatchedGemmFlag = useBatchedGemmFlag;
	#else
	oh->useBatchedGemmFlag = 0;
	#endif
}

void ozblasSetNumSplitArraysMax (ozblasHandle_t *oh, uint32_t NumSplitArraysMax) {
	oh->numSplitArraysMax = NumSplitArraysMax;
}

void ozblasSetFastMode (ozblasHandle_t *oh, uint32_t FastMode) {
	oh->fastModeFlag = (FastMode == 0) ? 0 : 1;
}

void ozblasSetReproMode (ozblasHandle_t *oh, uint32_t ReproMode) {
	oh->reproModeFlag = (ReproMode == 0) ? 0 : 1;
}

void ozblasSetSumMode (ozblasHandle_t *oh, uint32_t SumMode) {
	oh->sumModeFlag = (SumMode == 0) ? 0 : 1;
}

uint32_t ozblasGetNumSplitArraysMax (ozblasHandle_t *oh) {
	return oh->numSplitArraysMax;
}

uint32_t ozblasGetFastMode (ozblasHandle_t *oh) {
	return oh->fastModeFlag;
}

uint32_t ozblasGetReproMode (ozblasHandle_t *oh) {
	return oh->reproModeFlag;
}

uint32_t ozblasGetSumMode (ozblasHandle_t *oh) {
	return oh->sumModeFlag;
}

void ozblasDestroy (ozblasHandle_t *oh) {
	free (oh->devWork);
	if (oh->useBatchedGemmFlag) 
		free (oh->devBatchAddr);
}

CBLAS_TRANSPOSE ToCblasOp (char tran) {
	if (tran == 'N' || tran == 'n') return CblasNoTrans;
	if (tran == 'T' || tran == 't') return CblasTrans;
	if (tran == 'C' || tran == 'c') return CblasConjTrans;
	return CblasNoTrans;
}

char FromCublasOp (CBLAS_TRANSPOSE tran) {
	if (tran == CblasNoTrans) return 'n';
	if (tran == CblasTrans) return 't';
	if (tran == CblasConjTrans) return 'c';
	return 'n';
}

