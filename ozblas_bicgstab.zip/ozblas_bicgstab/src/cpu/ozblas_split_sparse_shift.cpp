// =========================================
// ozblasSplitShiftMat
// =========================================
void ozblasSplitShiftMatSparseNKernel (
	const int32_t m,
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devOutput,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	int32_t indexbase,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addrx = 0; addrx < m; addrx++) {
		int32_t dim = devRowptr[addrx+1] - devRowptr[addrx];
		int32_t rho = ceil((double)(UNIT+log2((double)dim))/2.);
		max = devMax[addrx];
		sigma = scalbn (1., rho) * NextPowTwo (max) * splitShift;
		max = 0.;
		for (int32_t i = devRowptr[addrx]-indexbase; i < devRowptr[addrx+1]-indexbase; i++) {
			input = devInput[i];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[i] = split;
			devOutput[i] = input;
			if (max < fabs(input)) max = fabs(input);
		}
		devMax[addrx] = max;
	}
}

void ozblasSplitShiftMatSparseEarlyExitNKernel (
	const int32_t m,
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	int32_t indexbase,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addrx = 0; addrx < m; addrx++) {
		int32_t dim = devRowptr[addrx+1] - devRowptr[addrx];
		int32_t rho = ceil((double)(UNIT+log2((double)dim))/2.);
		max = fabs(devMax[addrx]);
		sigma = scalbn (1., rho) * NextPowTwo (max) * splitShift;
		for (int32_t i = devRowptr[addrx]-indexbase; i < devRowptr[addrx+1]-indexbase; i++) {
			input = devInput[i];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[i] = split;
		}
	}
}

void ozblasSplitShiftMatSparseDevice (
	const char trans,
	const int32_t m, 
	const FP_CTYPE *devInput, // input matrix (devAwrk) 
	const int32_t *devRowptr,
	FP_CTYPE *devOutput, // output matrix (devAwrk)
	FP_CTYPE *devSplit, // split matrices (output): this includes NumSplitMax matrices
	FP_CTYPE *devMax,
	uint32_t lastFlag,
	int32_t indexbase,
	const int32_t splitShift
) {
/*
	FP_CTYPE *devC;
	devC = (FP_CTYPE*)malloc (sizeof(FP_CTYPE) * m);
*/
	if (trans == 'n' || trans == 'N') {
//		PrintMat (m, 1, devMax, m);
		if (!lastFlag) 
			ozblasSplitShiftMatSparseNKernel (m, devInput, devRowptr, devOutput, devSplit, devMax, indexbase, splitShift);
		else 
			ozblasSplitShiftMatSparseEarlyExitNKernel (m, devInput, devRowptr, devSplit, devMax, indexbase, splitShift);
	} else {
		fprintf (stderr, "error: Split T is not implemented.\n");
		exit (1);
	}
/*
//	for (int32_t i = 0; i < m; i++) 
//		printf ("%d:%a\n", i, devC[i]);
	free (devC);
*/
}

void
ozblasSplitShiftMatSparse (
	ozblasHandle_t *oh,
	const char trans,
	const int32_t m,
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	const int32_t lds,
	uint32_t &numSplitArrays,
	uint32_t &lastFlag
) {
	uint32_t numSplitArraysMax = numSplitArrays;
	uint32_t i = 1;
	int32_t one = 1;
	int32_t indexbase = oh->useGemmFlag;
	FP_CTYPE check;

	// Note: indexbase specifies zero-base index (C-style, useGemmFlag=0) or one-base index (F-style, useGemmFlag=1) for MKL
	// ozblasFindMax^(0)
	ozblasFindMaxMatSparseDevice (trans, m, devInput, devRowptr, devMax, indexbase);

	// Split^(0) & ozblasFindMax^(1)
	lastFlag = (oh->reproModeFlag && numSplitArraysMax == 1) ? 1 : 0;
	ozblasSplitShiftMatSparseDevice (trans, m, devInput, devRowptr, &devSplit[lds], &devSplit[0], devMax, lastFlag, indexbase, oh->splitShift);

	while (i < numSplitArraysMax) {
		// Check
		if (numSplitArraysMax-1 == i && !oh->reproModeFlag) { i++; break;} // when repromode=0
		check = CBLAS_ASUM (m, devMax, one);
		if (fabs(check) == 0) break;

		// Split^(i) & ozblasFindMax^(i+1)
		lastFlag = (oh->reproModeFlag && numSplitArraysMax-1 == i) ? 1 : 0;
		ozblasSplitShiftMatSparseDevice (trans, m, &devSplit[lds*i], devRowptr, &devSplit[lds*(i+1)], &devSplit[lds*i], devMax, lastFlag, indexbase, oh->splitShift);
		i++;
	}

	numSplitArrays = i;
	if (lastFlag == 1 && oh->numSplitArraysMax == 0) {
		fprintf (stderr, "split error: out of memory (the result may be not correct rounding)\n");
		exit (1);
	}
}

