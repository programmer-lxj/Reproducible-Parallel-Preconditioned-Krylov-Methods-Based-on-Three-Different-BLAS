#include "ozblas_common.h"

// reproducible but not accurate

FP_DTYPE
OzNRM2 (
	ozblasHandle_t *oh,
	const int n,
	const FP_DTYPE* devX,
	const int incx
) {
	counterInit (oh);
	if (oh->reproModeFlag == 0 && oh->numSplitArraysMax == 1) {
		return RCBLAS_NRM2 (n, devX, incx);
	}
	if (incx != 1) {
		fprintf (stderr, "* incx and incy are not supported.\n");
		exit (1);
	}
	
	FP_DTYPE ret;
	ret = OzDOT (oh, n, devX, incx, devX, incx);

	// ------------------------------
	// computation of SQRT (ret) on host
	// Not accurate but reproducible
	ret = sqrt (ret);
	// ------------------------------

	return ret;
}

