#ifndef OZBLAS_INTERNAL_H
#define OZBLAS_INTERNAL_H

double timer ();
int getPitchSize (int n);
void counterInit (ozblasHandle_t *oh);
uint32_t memCheck (ozblasHandle_t *oh);

#if defined (PREC_D)
void ozblasDMallocSplitMat  ( ozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, double **hstMax, int32_t &lds);
void ozblasDMallocSplitMatSparse ( ozblasHandle_t *oh, const int32_t m, const int32_t nnz, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void ozblasDMallocResultMat ( ozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, int32_t &lds);
void ozblasDMallocSplitVec  ( ozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, double **hstMax, int32_t &lds);
void ozblasDMallocResultVec ( ozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, int32_t &lds);
void ozblasDSplitMat ( ozblasHandle_t *oh, const char trans, const int32_t m, const int32_t n, const double *hstInput, const int32_t ld, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasDSplitMatSparse ( ozblasHandle_t *oh, const char trans, const int32_t m, const double *hstInput, const int32_t *hstRowptr, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasDSplitShiftMat ( ozblasHandle_t *oh, const char trans, const int32_t m, const int32_t n, const double *hstInput, const int32_t ld, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasDSplitShiftMatSparse ( ozblasHandle_t *oh, const char trans, const int32_t m, const double *hstInput, const int32_t *hstRowptr, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasDSumMat ( const int32_t m, const int32_t n, double *hstCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, double *hstC, const int32_t ldc, const double alpha, const double beta, const uint32_t summode);
void ozblasDSumMatNpara ( const int32_t m, const int32_t n, double *hstCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, double *hstC, const int32_t ldc, const double alpha, const double beta, const uint32_t summode);
void ozblasDPrintVec ( const int32_t n, const double *devC);
void ozblasDCopyVec ( const size_t n, const double *hstA, double *hstB);
#elif defined (PREC_S)
void ozblasSMallocSplitMat  ( ozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, float **hstSplit, float **hstMax, int32_t &lds);
void ozblasSMallocSplitMatSparse ( ozblasHandle_t *oh, const int32_t m, const int32_t nnz, const uint32_t numSplitArraysMax, float **devSplit, float **devMax, int32_t &lds);
void ozblasSMallocResultMat ( ozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, float **hstSplit, int32_t &lds);
void ozblasSMallocSplitVec  ( ozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, float **hstSplit, float **hstMax, int32_t &lds);
void ozblasSMallocResultVec ( ozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, float **hstSplit, int32_t &lds);
void ozblasSSplitMat ( ozblasHandle_t *oh, const char trans, const int32_t m, const int32_t n, const float *hstInput, const int32_t ld, float *hstSplit, float *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSSplitMatSparse ( ozblasHandle_t *oh, const char trans, const int32_t m, const float *hstInput, const int32_t *hstRowptr, float *hstSplit, float *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSSplitShiftMat ( ozblasHandle_t *oh, const char trans, const int32_t m, const int32_t n, const float *hstInput, const int32_t ld, float *hstSplit, float *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSSplitShiftMatSparse ( ozblasHandle_t *oh, const char trans, const int32_t m, const float *hstInput, const int32_t *hstRowptr, float *hstSplit, float *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSSumMat ( const int32_t m, const int32_t n, float *hstCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, float *hstC, const int32_t ldc, const float alpha, const float beta, const uint32_t summode);
void ozblasSSumMatNpara ( const int32_t m, const int32_t n, float *hstCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, float *hstC, const int32_t ldc, const float alpha, const float beta, const uint32_t summode);
void ozblasSPrintVec ( const int32_t n, const float *devC);
void ozblasSCopyVec ( const size_t n, const float *hstA, float *hstB);
#elif defined (PREC_SD)
void ozblasSDMallocSplitMat  ( ozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, double **hstMax, int32_t &lds);
void ozblasSDMallocSplitMatSparse ( ozblasHandle_t *oh, const int32_t m, const int32_t nnz, const uint32_t numSplitArraysMax, double **devSplit, double **devMax, int32_t &lds);
void ozblasSDMallocResultMat ( ozblasHandle_t *oh, const int32_t m, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, int32_t &lds);
void ozblasSDMallocSplitVec  ( ozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, double **hstMax, int32_t &lds);
void ozblasSDMallocTmpMat ( ozblasHandle_t *oh, const int32_t m, const int32_t n, double **hstSplit, int32_t &lds);
void ozblasSDMallocTmpVec  ( ozblasHandle_t *oh, const int32_t n, double **hstSplit, int32_t &lds);
void ozblasSDCopyMat ( const int32_t m, const int32_t n, const float *hstA, const int32_t lda, double *hstB, const int32_t ldb);
void ozblasDCopyMat ( const int32_t m, const int32_t n, const double *hstA, const int32_t lda, double *hstB, const int32_t ldb);
void ozblasSDMallocResultVec ( ozblasHandle_t *oh, const int32_t n, const uint32_t numSplitArraysMax, double **hstSplit, int32_t &lds);
void ozblasSDSplitMat ( ozblasHandle_t *oh, const char trans, const int32_t m, const int32_t n, const double *hstInput, const int32_t ld, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSDSplitMatSparse ( ozblasHandle_t *oh, const char trans, const int32_t m, const double *hstInput, const int32_t *hstRowptr, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSDSplitShiftMat ( ozblasHandle_t *oh, const char trans, const int32_t m, const int32_t n, const double *hstInput, const int32_t ld, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSDSplitShiftMatSparse ( ozblasHandle_t *oh, const char trans, const int32_t m, const double *hstInput, const int32_t *hstRowptr, double *hstSplit, double *hstMax, const int32_t lds, uint32_t &numSplitArrays, uint32_t &lastFlag);
void ozblasSDSumMat ( const int32_t m, const int32_t n, double *hstCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, float *hstC, const int32_t ldc, const float alpha, const float beta, const uint32_t summode);
void ozblasSDSumMatNpara ( const int32_t m, const int32_t n, double *hstCsplit, const int32_t llsc, const int32_t ldsc, const int32_t numsplit, float *hstC, const int32_t ldc, const float alpha, const float beta, const uint32_t summode);
void ozblasSDPrintVec ( const int32_t n, const float *devC);
void ozblasSDCopyVec ( const size_t n, const float *hstA, float *hstB);
void ozblasDCopyVec ( const size_t n, const double *hstA, double *hstB);
#endif

//void ozblasInitVecDevice ( const int32_t n, int64_t *hstA);
CBLAS_TRANSPOSE ToCblasOp (char tran);
char FromCublasOp (CBLAS_TRANSPOSE tran);
void PrintMat ( const int32_t m, const int32_t n, const double *devC, const int32_t ldd);
void PrintMatInt ( const int32_t m, const int32_t n, const int32_t *devC, const int32_t ldd);
	
#endif
