#include "ozblas_common.h"

int
OzAXPY (
	ozblasHandle_t *oh,
	const int n,
	const FP_DTYPE alpha,
	const FP_DTYPE *devX, const int incx,
	FP_DTYPE *devY, const int incy
) {
	if (oh->reproModeFlag == 0) {
		RCBLAS_AXPY (n, alpha, devX, incx, devY, incy);
		return 0;
	}
	if (incx != 1 || incy != 1) {
		printf ("incx and incy are not supported.\n");
		return 0;
	}

	#pragma omp parallel for 
	for (int i = 0; i < n; i++) {
		devY[i] = fma (alpha, devX[i], devY[i]);
	}

	return 0;
}

