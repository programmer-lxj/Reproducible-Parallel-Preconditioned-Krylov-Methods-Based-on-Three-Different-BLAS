#include "ozblas_common.h"

#if !defined (PREC_SD)
int
OzGEMM (
	ozblasHandle_t *oh,	
	const char tranA, const char tranB,
	const int m, const int n, const int k,
	const FP_DTYPE alpha,
	const FP_DTYPE *devA, const int lda,
	const FP_DTYPE *devB, const int ldb,
	const FP_DTYPE beta,
	FP_DTYPE *devC, const int ldc
) {
	counterInit (oh);
	if (oh->reproModeFlag == 0 && oh->numSplitArraysMax == 1) {
		#if (NVBLAS)
		RNVBLAS_GEMM (&tranA, &tranB, &m, &n, &k, &alpha, devA, &lda, devB, &ldb, &beta, devC, &ldc);
		#else
		RCBLAS_GEMM (CblasColMajor, ToCblasOp(tranA), ToCblasOp(tranB), m, n, k, alpha, devA, lda, devB, ldb, beta, devC, ldc);
		#endif
		return 0;
	}
	FP_CTYPE fone = 1., fzero = 0.;
	double t1, t0 = timer();
	uint32_t numSplitArraysMax = (oh->numSplitArraysMax > 0) ? oh->numSplitArraysMax : NumSplitDefaultMax;
	int ldas, ldbs, ldcs;
	FP_CTYPE *devAmax, *devBmax;
	FP_CTYPE *devASplit, *devBSplit, *devCSplit;

	int mbk = m;
	int nbk = n;
	uint64_t memAddrTmp = oh->memAddr;
	while (mbk > 0) {
		ozblasMallocSplitMat (oh, k, mbk, numSplitArraysMax, &devASplit, &devAmax, ldas); // TRANSPOSE
		ozblasMallocSplitMat (oh, k, nbk, numSplitArraysMax, &devBSplit, &devBmax, ldbs);
		ozblasMallocResultMat (oh, mbk, n, numSplitArraysMax, &devCSplit, ldcs);
		if (!memCheck (oh)) break;
		oh->memAddr = memAddrTmp;
		mbk = ceil (mbk / 2.);
		nbk = ceil (nbk / 2.);
	}

	FP_CTYPE **devAptr, **devBptr, **devCptr;
	if (oh->useBatchedGemmFlag) {
		int memorysize = 0;
		devAptr = (FP_CTYPE**)(oh->devBatchAddr);
		memorysize += sizeof(FP_CTYPE*) * numSplitArraysMax * numSplitArraysMax;
		devBptr = (FP_CTYPE**)(oh->devBatchAddr + memorysize);
		memorysize += sizeof(FP_CTYPE*) * numSplitArraysMax * numSplitArraysMax;
		devCptr = (FP_CTYPE**)(oh->devBatchAddr + memorysize);
		memorysize = 0;
		devAptr = (FP_CTYPE**)(oh->devBatchAddr);
		memorysize += sizeof(FP_CTYPE*) * numSplitArraysMax * numSplitArraysMax;
		devBptr = (FP_CTYPE**)(oh->devBatchAddr + memorysize);
		memorysize += sizeof(FP_CTYPE*) * numSplitArraysMax * numSplitArraysMax;
		devCptr = (FP_CTYPE**)(oh->devBatchAddr + memorysize);
	}

	for (int im = 0; im < ceil((float)m/mbk); im++) {
		int mbk_ = (m-mbk*im >= mbk) ? mbk : m-mbk*im;

		// Split of A -----------------------------------
		t1 = timer();
		oh->numSplitArraysA = numSplitArraysMax;
		if (tranA == 'n' || tranA == 'N') {
			#ifdef MKL
			MKL_OMATCOPY ('c', 't', k, mbk_, fone, devA+im*mbk, lda, devASplit, ldas); // TRANSPOSE
			#else
			CBLAS_OMATCOPY (CblasColMajor, CblasTrans, mbk_, k, fone, devA+im*mbk, lda, devASplit, ldas); // TRANSPOSE
			#endif
			ozblasSplitMat (oh, 'c', k, mbk_, devASplit, ldas, devASplit, devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA); // TRANSPOSE
		} else {
			ozblasSplitMat (oh, 'c', k, mbk_, devA+im*mbk, lda, devASplit, devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
		}
		oh->t_SplitA += timer() - t1;

		for (int in = 0; in < ceil((float)n/nbk); in++) {
			int nbk_ = (n-nbk*in >= nbk) ? nbk : n-nbk*in;
			// Split of B -----------------------------------
			t1 = timer();
			oh->numSplitArraysB = numSplitArraysMax;
			if (tranB == 'n' || tranB == 'N') {
				ozblasSplitMat (oh, 'c', k, nbk_, devB+in*nbk*ldb, ldb, devBSplit, devBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
			} else {
				#ifdef MKL
				MKL_OMATCOPY ('c', 't', k, nbk_, fone, devB+in*nbk*ldb, ldb, devBSplit, ldbs); // TRANSPOSE
				#else
				CBLAS_OMATCOPY (CblasColMajor, CblasTrans, nbk_, k, fone, devB+in*nbk*ldb, ldb, devBSplit, ldbs); // TRANSPOSE
				#endif
				ozblasSplitMat (oh, 'c', k, nbk_, devBSplit, ldbs, devBSplit, devBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
			}
			oh->t_SplitB += timer() - t1;

			// Compute --------------------------------------
			uint32_t ia, ib, ic;
			uint32_t maxlevel = (oh->numSplitArraysA-1) + (oh->numSplitArraysB-1);
			if (oh->fastModeFlag) {
				if (oh->numSplitArraysMax == 0)	
					maxlevel = MIN (oh->numSplitArraysA-1, oh->numSplitArraysB-1);
				else
					maxlevel = oh->numSplitArraysMax-1;
			}

			if (oh->numSplitArraysMax == 1) {
				t1 = timer();
				#if (NVBLAS)
				char tranAt = 't';
				NVBLAS_GEMM (&tranAt, &tranB, &mbk_, &nbk_, &k, &fone, devASplit, &ldas, devBSplit, &ldbs, &fzero, devCSplit, &ldcs);
				#else
				CBLAS_GEMM (CblasColMajor, CblasTrans, ToCblasOp(tranB), mbk_, nbk_, k, fone, devASplit, ldas, devBSplit, ldbs, fzero, devCSplit, ldcs);
				#endif
				oh->numSplitArraysC = 1;
			} else {
				ic = 0;
				if (oh->useBatchedGemmFlag) {
					for (ia = 0; ia < oh->numSplitArraysA; ia++) {
						for (ib = 0; ib < oh->numSplitArraysB; ib++) {
							if (ia + ib <= maxlevel) {
								devAptr[ic] = devASplit+ldas*mbk*ia;
								devBptr[ic] = devBSplit+ldbs*nbk*ib;
								devCptr[ic] = devCSplit+ldcs*nbk*ic;
								ic++;
							}
						}
					}
					oh->numSplitArraysC = ic;
					t1 = timer();
					#ifdef MKL
					#if (NVBLAS)
					char tranAt = 't';
					char tranBn = 'n';
					NVBLAS_GEMMBATCH (&tranAt, &tranBn, &mbk_, &nbk_, &k, &fone,
										(const FP_CTYPE**)devAptr, &ldas,
										(const FP_CTYPE**)devBptr, &ldbs, &fzero,
										(FP_CTYPE**)devCptr, &ldcs, &one, (int*)&oh->numSplitArraysC);
					#else
					CBLAS_TRANSPOSE trans_ = CblasTrans;
					CBLAS_TRANSPOSE notrans_ = CblasNoTrans;
					CBLAS_GEMMBATCH (CblasColMajor, &trans_, &notrans_, &mbk_, &nbk_, &k, &fone,
										(const FP_CTYPE**)devAptr, &ldas,
										(const FP_CTYPE**)devBptr, &ldbs, &fzero,
										(FP_CTYPE**)devCptr, &ldcs, 1, (int*)&oh->numSplitArraysC);
					#endif
					#else
					fprintf (stderr, "* no batched BLAS support.\n");
					exit(1);
					#endif
				} else {
					t1 = timer();
					FP_CTYPE *ptrA, *ptrB, *ptrC;
					for (ia = 0; ia < oh->numSplitArraysA; ia++) {
						for (ib = 0; ib < oh->numSplitArraysB; ib++) {
							if (ia + ib <= maxlevel) {
								ptrA = devASplit+ldas*mbk*ia;
								ptrB = devBSplit+ldbs*nbk*ib;
								ptrC = devCSplit+ldcs*nbk*ic;
								#if (NVBLAS)
								char tranAt = 't';
								char tranBn = 'n';
								NVBLAS_GEMM (&tranAt, &tranBn, &mbk_, &nbk_, &k, &fone, ptrA, &ldas, ptrB, &ldbs, &fzero, ptrC, &ldcs);
								#else
								CBLAS_GEMM (CblasColMajor, CblasTrans, CblasNoTrans, mbk_, nbk_, k, fone, ptrA, ldas, ptrB, ldbs, fzero, ptrC, ldcs);
								#endif
								ic++;
							}
						}
					}
					oh->numSplitArraysC = ic;
				}
			}
			oh->t_comp += timer() - t1;

			// Sum -----------------------------------------
			t1 = timer();
			ozblasSumMat (mbk_, nbk_, devCSplit, ldcs*nbk, ldcs, oh->numSplitArraysC, &devC[ldc*(in*nbk)+im*mbk], ldc, alpha, beta, oh->sumModeFlag);
			oh->t_sum += timer() - t1;
		}
	}

	oh->t_total = timer() - t0;

	return 0;
}
#endif
