#include "ozblas_common.h"

// =========================================
// InitVec
// =========================================

void ozblasInitVecDevice (
	const int n,
	int64_t *hstA
) {
	#pragma omp parallel for
	for (int addrx = 0; addrx < n; addrx++)
		hstA[addrx] = 0;
}


FP_DTYPE OzDOT (
	ozblasHandle_t *oh,
	const int n,
	const FP_DTYPE *hstA, const int incx,
	const FP_DTYPE *hstB, const int incy
) {
	counterInit (oh);
	if (oh->reproModeFlag == 0 && oh->numSplitArraysMax == 1) {
		double t0 = timer();
		FP_DTYPE r = RCBLAS_DOT (n, hstA, incx, hstB, incy);
		oh->t_DOT_NRM2_total += timer() - t0;
		return r;
	}
	if (incx != 1 || incy != 1 ) {
		fprintf (stderr, "* incx and incy are not supported.\n");
		exit (1);
	}

	double t1, t0 = timer();
	uint32_t numSplitArraysMax = (oh->numSplitArraysMax > 0) ? oh->numSplitArraysMax : NumSplitDefaultMax;
	int ldas, ldbs, ldcs;
	FP_CTYPE fone = 1., fzero = 0.;
	FP_CTYPE *hstAmax, *hstBmax;
	FP_CTYPE *hstASplit, *hstBSplit, *hstCSplit;

	if (oh->numSplitArraysMax > 0) numSplitArraysMax = oh->numSplitArraysMax;
	ozblasMallocSplitVec (oh, n, numSplitArraysMax, &hstASplit, &hstAmax, ldas);
	ozblasMallocSplitVec (oh, n, numSplitArraysMax, &hstBSplit, &hstBmax, ldbs);
	ozblasMallocResultVec (oh, 1, numSplitArraysMax, &hstCSplit, ldcs);
#if defined (PREC_SD)
	int ldat, ldbt;
	FP_CTYPE *hstATmp, *hstBTmp;
	ozblasSDMallocTmpVec (oh, n, &hstATmp, ldat);
	ozblasSDMallocTmpVec (oh, n, &hstBTmp, ldbt);
	ozblasSDCopyMat (n, 1, hstA, n, hstATmp, ldat);
	ozblasSDCopyMat (n, 1, hstB, n, hstBTmp, ldbt);
#endif
	memCheck (oh);
	
	ozblasInitVecDevice (ldcs * numSplitArraysMax * numSplitArraysMax, (int64_t*)hstCSplit);

	// Split of A -----------------------------------
	t1 = timer();
	oh->numSplitArraysA = numSplitArraysMax;
#if defined (PREC_SD)
	ozblasSplitMat (oh, 'r', n, 1, hstATmp, n, hstASplit, hstAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
#else
	ozblasSplitMat (oh, 'r', n, 1, hstA, n, hstASplit, hstAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
#endif
	oh->t_SplitA = timer() - t1;

	// Split of B -----------------------------------
	t1 = timer();
	oh->numSplitArraysB = numSplitArraysMax;
#if defined (PREC_SD)
	ozblasSplitMat (oh, 'r', n, 1, hstBTmp, n, hstBSplit, hstBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
#else
	ozblasSplitMat (oh, 'r', n, 1, hstB, n, hstBSplit, hstBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
#endif
	oh->t_SplitB = timer() - t1;

	// Compute --------------------------------------
	t1 = timer();
	uint32_t ia, ib;
	uint32_t maxlevel = (oh->numSplitArraysA-1) + (oh->numSplitArraysB-1);
	if (oh->fastModeFlag) {
		if (oh->numSplitArraysMax == 0)	
			maxlevel = MIN (oh->numSplitArraysA-1, oh->numSplitArraysB-1);
		else
			maxlevel = oh->numSplitArraysMax-1;
	}

	if (oh->useGemmFlag) {
	/*
		if (oh->useMyGemmFlag) {
			FP_CTYPE *hstW = (FP_CTYPE*)(oh->hstWork + oh->memAddr);
			oh->memAddr += sizeof(FP_CTYPE) * oh->numSplitArraysA * oh->numSplitArraysB * SPLIT_VEC_NBX;
			memCheck (oh);
			mublasDgemmdot (oh->ch, n, oh->numSplitArraysA, oh->numSplitArraysB, hstASplit, ldas, hstBSplit, ldbs, hstCSplit, oh->numSplitArraysA, hstW);
		} else {
			*/
			CBLAS_GEMM (CblasColMajor, CblasTrans, CblasNoTrans, oh->numSplitArraysA, oh->numSplitArraysB, n, fone, hstASplit, ldas, hstBSplit, ldbs, fzero, hstCSplit, oh->numSplitArraysA);
	//	}
		oh->numSplitArraysC = oh->numSplitArraysA * oh->numSplitArraysB;
		// to ensure the consistency with the computation result by GEMM when FS
		if (oh->fastModeFlag) {
			for (ia = 0; ia < oh->numSplitArraysA; ia++) {
				for (ib = 0; ib < oh->numSplitArraysB; ib++) {
					if (ia + ib > maxlevel) 
						hstCSplit[oh->numSplitArraysA*ib+ia] = 0.;
				}
			}
		}
	} else {
		uint32_t ic = 0;
		FP_CTYPE *ptrA, *ptrB, *ptrC;
		for (ia = 0; ia < oh->numSplitArraysA; ia++) {
			for (ib = 0; ib < oh->numSplitArraysB; ib++) {
				if (ia + ib <= maxlevel) {
					ptrA = hstASplit+ldas*ia;
					ptrB = hstBSplit+ldbs*ib;
					ptrC = hstCSplit+ic;
					int one = 1;
					ptrC[0] = CBLAS_DOT (n, ptrA, one, ptrB, one);
					ic++;
				}
			}
		}
		oh->numSplitArraysC = ic;
	}

	oh->t_comp = timer() - t1;

	// Sum -----------------------------------------
	t1 = timer();
	FP_DTYPE ret;
	ozblasSumMatNpara (1, 1, hstCSplit, 1, 1, oh->numSplitArraysC, &ret, 1, 1., 0., oh->sumModeFlag);
	//ozblasSumMat (1, 1, hstCSplit, 1, 1, oh->numSplitArraysC, &ret, 1, 1., 0., oh->sumModeFlag);
	oh->t_sum = timer() - t1;

	oh->t_total = timer() - t0;

	// for CG, time
	// =================================
	oh->t_SplitMat_total += 0.;
	oh->t_SplitVec_total += oh->t_SplitA + oh->t_SplitB;
	oh->t_Sum_total += oh->t_sum;
	oh->t_AXPY_SCAL_total += 0.;
	oh->t_DOT_NRM2_total += oh->t_comp;
	oh->t_SpMV_SpMM_total += 0.;
	// =================================

	return ret;
}

