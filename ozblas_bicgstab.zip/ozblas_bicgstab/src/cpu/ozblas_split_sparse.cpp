#include "ozblas_common.h"

// =========================================
// ozblasSplitMat
// =========================================

__inline__ double NextPowTwo (const double p) {
	return scalbn (p, UNIT) - ((scalbn (1., UNIT) - 1) * p);
}

void ozblasFindMaxMatSparseNKernel (
	const int32_t m,
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devMax,
	int32_t indexbase
) {
	FP_CTYPE max, input;

	#pragma omp parallel for private (max, input)
	for (int32_t addrx = 0; addrx < m; addrx++) {
		max = 0.;
		for (int32_t i = devRowptr[addrx]-indexbase; i < devRowptr[addrx+1]-indexbase; i++) {
			input = devInput[i];
			if (max < fabs(input)) max = fabs(input);
		}
		devMax[addrx] = max;
	}
}

void ozblasFindMaxMatSparseDevice (
	const char trans,
	const int32_t m, 
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devMax,
	int32_t indexbase
) {
	if (trans == 'n' || trans == 'N') {
		ozblasFindMaxMatSparseNKernel (m, devInput, devRowptr, devMax, indexbase);
	} else {
		fprintf (stderr, "error: Split T is not implemented.\n");
		exit (1);
	}
}

void ozblasSplitMatSparseNKernel (
	const int32_t m,
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devOutput,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	int32_t indexbase
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addrx = 0; addrx < m; addrx++) {
		int32_t dim = devRowptr[addrx+1] - devRowptr[addrx];
		int32_t rho = ceil((double)(UNIT+log2((double)dim))/2.);
		max = devMax[addrx];
		sigma = scalbn (1., rho) * NextPowTwo (max);
		max = 0.;
		for (int32_t i = devRowptr[addrx]-indexbase; i < devRowptr[addrx+1]-indexbase; i++) {
			input = devInput[i];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[i] = split;
			devOutput[i] = input;
			if (max < fabs(input)) max = fabs(input);
		}
		devMax[addrx] = max;
	}
}

void ozblasSplitMatSparseEarlyExitNKernel (
	const int32_t m,
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	int32_t indexbase
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addrx = 0; addrx < m; addrx++) {
		int32_t dim = devRowptr[addrx+1] - devRowptr[addrx];
		int32_t rho = ceil((double)(UNIT+log2((double)dim))/2.);
		max = fabs(devMax[addrx]);
		sigma = scalbn (1., rho) * NextPowTwo (max);
		for (int32_t i = devRowptr[addrx]-indexbase; i < devRowptr[addrx+1]-indexbase; i++) {
			input = devInput[i];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[i] = split;
		}
	}
}

void ozblasSplitMatSparseDevice (
	const char trans,
	const int32_t m, 
	const FP_CTYPE *devInput, // input matrix (devAwrk) 
	const int32_t *devRowptr,
	FP_CTYPE *devOutput, // output matrix (devAwrk)
	FP_CTYPE *devSplit, // split matrices (output): this includes NumSplitMax matrices
	FP_CTYPE *devMax,
	uint32_t lastFlag,
	int32_t indexbase
) {
/*
	FP_CTYPE *devC;
	devC = (FP_CTYPE*)malloc (sizeof(FP_CTYPE) * m);
*/
	if (trans == 'n' || trans == 'N') {
//		PrintMat (m, 1, devMax, m);
		if (!lastFlag) 
			ozblasSplitMatSparseNKernel (m, devInput, devRowptr, devOutput, devSplit, devMax, indexbase);
		else 
			ozblasSplitMatSparseEarlyExitNKernel (m, devInput, devRowptr, devSplit, devMax, indexbase);
	} else {
		fprintf (stderr, "error: Split T is not implemented.\n");
		exit (1);
	}
/*
//	for (int32_t i = 0; i < m; i++) 
//		printf ("%d:%a\n", i, devC[i]);
	free (devC);
*/
}

void
ozblasSplitMatSparse (
	ozblasHandle_t *oh,
	const char trans,
	const int32_t m,
	const FP_CTYPE *devInput,
	const int32_t *devRowptr,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	const int32_t lds,
	uint32_t &numSplitArrays,
	uint32_t &lastFlag
) {
	uint32_t numSplitArraysMax = numSplitArrays;
	uint32_t i = 1;
	int32_t one = 1;
	int32_t indexbase = oh->useGemmFlag;
	FP_CTYPE check;

	// Note: indexbase specifies zero-base index (C-style, useGemmFlag=0) or one-base index (F-style, useGemmFlag=1) for MKL
	// ozblasFindMax^(0)
	ozblasFindMaxMatSparseDevice (trans, m, devInput, devRowptr, devMax, indexbase);

	// Split^(0) & ozblasFindMax^(1)
	lastFlag = (oh->reproModeFlag && numSplitArraysMax == 1) ? 1 : 0;
	ozblasSplitMatSparseDevice (trans, m, devInput, devRowptr, &devSplit[lds], &devSplit[0], devMax, lastFlag, indexbase);

	while (i < numSplitArraysMax) {
		// Check
		if (numSplitArraysMax-1 == i && !oh->reproModeFlag) { i++; break;} // when repromode=0
		check = CBLAS_ASUM (m, devMax, one);
		if (fabs(check) == 0) break;

		// Split^(i) & ozblasFindMax^(i+1)
		lastFlag = (oh->reproModeFlag && numSplitArraysMax-1 == i) ? 1 : 0;
		ozblasSplitMatSparseDevice (trans, m, &devSplit[lds*i], devRowptr, &devSplit[lds*(i+1)], &devSplit[lds*i], devMax, lastFlag, indexbase);
		i++;
	}

	numSplitArrays = i;
	if (lastFlag == 1 && oh->numSplitArraysMax == 0) {
		fprintf (stderr, "split error: out of memory (the result may be not correct rounding)\n");
		exit (1);
	}
}

#include "ozblas_split_sparse_shift.cpp"
