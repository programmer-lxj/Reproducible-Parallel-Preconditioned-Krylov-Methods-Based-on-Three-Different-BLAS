// =========================================
// Split
// Based on K.Ozaki et al., "Error-free transformations of matrix multiplication
// by using fast routines of matrix multiplication and its applications", 2012
// =========================================
void ozblasSplitShiftVecKernel (
	const int32_t n,
	const int32_t rho,
	const FP_CTYPE *devInput,
	FP_CTYPE *devOutput,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max_, input, split;

	max_ = devMax[0];
	sigma = scalbn (1., rho) * NextPowTwo (max_) / splitShift;
	max_ = 0.;
	#pragma omp parallel for private (input, split) reduction(max:max_)
	for (int32_t i = 0; i < n; i++) {
		input = devInput[i];
		split = (input + sigma) - sigma;
		input = input - split;
		devSplit[i] = split;
		devOutput[i] = input;
		if (max_ < fabs(input)) {
			max_ = fabs(input);
		}
	}
	devMax[0] = max_;
}

void ozblasSplitShiftVecEarlyExitKernel (
	const int32_t n,
	const int32_t rho,
	const FP_CTYPE *devInput,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max, input, split;

	max = devMax[0];
	sigma = scalbn (1., rho) * NextPowTwo (max) / splitShift;
	#pragma omp parallel for private (input, split)
	for (int32_t i = 0; i < n; i++) {
		input = devInput[i];
		split = (input + sigma) - sigma;
		input = input - split;
		devSplit[i] = split;
	}
}

// =========================================
// ozblasSplitShiftMat
// =========================================
void ozblasSplitShiftMatNKernel (
	const int32_t m,
	const int32_t n,
	const int32_t rho,
	const FP_CTYPE *devInput,
	const int32_t ldi,
	FP_CTYPE *devOutput,
	FP_CTYPE *devSplit,
	const int32_t lds,
	FP_CTYPE *devMax,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addrx = 0; addrx < m; addrx++) {
		max = devMax[addrx];
		sigma = scalbn (1., rho) * NextPowTwo (max) / splitShift;
		max = 0.;
		for (int32_t j = 0; j < n; j++) {
			input = devInput[j * ldi + addrx];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[j * lds + addrx] = split;
			devOutput[j * lds + addrx] = input;
			if (max < fabs(input)) max = fabs(input);
		}
		devMax[addrx] = max;
	}
}

void ozblasSplitShiftMatTKernel (
	const int32_t m,
	const int32_t n,
	const int32_t rho,
	const FP_CTYPE *devInput,
	const int32_t ldi,
	FP_CTYPE *devOutput,
	FP_CTYPE *devSplit,
	const int32_t lds,
	FP_CTYPE *devMax,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addry = 0; addry < n; addry++) {
		max = devMax[addry];
		sigma = scalbn (1., rho) * NextPowTwo (max) / splitShift;
		max = 0.;
		for (int32_t i = 0; i < m; i++) {
			input = devInput[addry * ldi + i];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[addry * lds + i] = split;
			devOutput[addry * lds + i] = input;
			if (max < fabs(input)) max = fabs(input);
		}
		devMax[addry] = max;
	}
}

void ozblasSplitShiftMatEarlyExitNKernel (
	const int32_t m,
	const int32_t n,
	const int32_t rho,
	const FP_CTYPE *devInput,
	const int32_t ldi,
	FP_CTYPE *devSplit,
	const int32_t lds,
	FP_CTYPE *devMax,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addrx = 0; addrx < m; addrx++) {
		max = devMax[addrx];
		sigma = scalbn (1., rho) * NextPowTwo (max) / splitShift;
		for (int32_t j = 0; j < n; j++) {
			input = devInput[j * ldi + addrx];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[j * lds + addrx] = split;
		}
	}
}

void ozblasSplitShiftMatEarlyExitTKernel (
	const int32_t m,
	const int32_t n,
	const int32_t rho,
	const FP_CTYPE *devInput,
	const int32_t ldi,
	FP_CTYPE *devSplit,
	const int32_t lds,
	FP_CTYPE *devMax,
	const int32_t splitShift
) {
	FP_CTYPE sigma, max, input, split;

	#pragma omp parallel for private (max, sigma, input, split)
	for (int32_t addry = 0; addry < n; addry++) {
		max = devMax[addry];
		sigma = scalbn (1., rho) * NextPowTwo (max) / splitShift;
		for (int32_t i = 0; i < m; i++) {
			input = devInput[addry * ldi + i];
			split = (input + sigma) - sigma;
			input = input - split;
			devSplit[addry * lds + i] = split;
		}
	}
}

void ozblasSplitShiftMatDevice (
	const char major,
	const int32_t m, 
	const int32_t n,
	const FP_CTYPE *devInput, // input matrix (devAwrk) 
	const int32_t ldi, // leading dimension of input matrix
	FP_CTYPE *devOutput, // output matrix (devAwrk)
	FP_CTYPE *devSplit, // split matrices (output): this includes NumSplitMax matrices
	const int32_t lds, // leading dimension of split matrix (# of cols)
	FP_CTYPE *devMax,
	uint32_t lastFlag,
	const int32_t splitShift
) {
	const int32_t dim = ((major == 'r') && n > 1) ? n : m;
	int32_t rho = ceil((double)(UNIT+log2((double)dim))/2.);

	if (major == 'r') {
		if (n == 1) {
			if (!lastFlag) 
				ozblasSplitShiftVecKernel (m, rho, devInput, devOutput, devSplit, devMax, splitShift);
			else 
				ozblasSplitShiftVecEarlyExitKernel (m, rho, devInput, devSplit, devMax, splitShift);
		} else {
			if (!lastFlag) 
				ozblasSplitShiftMatNKernel (m, n, rho, devInput, ldi, devOutput, devSplit, lds, devMax, splitShift);
			else 
				ozblasSplitShiftMatEarlyExitNKernel (m, n, rho, devInput, ldi, devSplit, lds, devMax, splitShift);
		}
	} else {
		if (!lastFlag) 
			ozblasSplitShiftMatTKernel (m, n, rho, devInput, ldi, devOutput, devSplit, lds, devMax, splitShift);
		else 
			ozblasSplitShiftMatEarlyExitTKernel (m, n, rho, devInput, ldi, devSplit, lds, devMax, splitShift);
	}
}

void
ozblasSplitShiftMat (
	ozblasHandle_t *oh,
	const char major,
	const int32_t m,
	const int32_t n,
	const FP_CTYPE *devInput,
	const int32_t ld,
	FP_CTYPE *devSplit,
	FP_CTYPE *devMax,
	const int32_t lds,
	uint32_t &numSplitArrays,
	uint32_t &lastFlag
) {
	uint32_t numSplitArraysMax = numSplitArrays;
	uint32_t i = 1;
	int32_t one = 1;
	FP_CTYPE check;

	// FindMax^(0)
	if (n == 1 && major == 'r') {
		int32_t ptrMax = 0;
		ptrMax = CBLAS_IAMAX (m, devInput, one);
		// Warning: note that cublas returns the index on the basis of 1-origin, while MKL (CBLAS) returns it on the basis of 0-origin !! 
		devMax[0] = devInput[ptrMax]; // so, here do not -1 !!
	} else {
		ozblasFindMaxMatDevice (major, m, n, devInput, ld, devMax);
	}

	// Split^(0) & FindMax^(1)
	lastFlag = (oh->reproModeFlag && numSplitArraysMax == 1) ? 1 : 0;
												// in, out, split
	ozblasSplitShiftMatDevice (major, m, n, devInput, ld, &devSplit[lds*n], &devSplit[0], lds, devMax, lastFlag, oh->splitShift);

	while (i < numSplitArraysMax) {
		// Check
		if (numSplitArraysMax-1 == i && !oh->reproModeFlag) { i++; break;} // when repromode=0
		if (n == 1 && major == 'r') 
			check = devMax[0];
		else
			check = CBLAS_ASUM ((major=='r')?m:n, devMax, one);
		if (fabs(check) == 0) break;

		// Split^(i) & FindMax^(i+1)
		lastFlag = (oh->reproModeFlag && numSplitArraysMax-1 == i) ? 1 : 0;
		ozblasSplitShiftMatDevice (major, m, n, &devSplit[lds*n*i], lds, &devSplit[lds*n*(i+1)], &devSplit[lds*n*i], lds, devMax, lastFlag, oh->splitShift);
		i++;
	}
	numSplitArrays = i;
	if (lastFlag == 1 && oh->numSplitArraysMax == 0) {
		fprintf (stderr, "* split error: out of memory (the result may be not correct rounding)\n");
		exit (1);
	}
}

