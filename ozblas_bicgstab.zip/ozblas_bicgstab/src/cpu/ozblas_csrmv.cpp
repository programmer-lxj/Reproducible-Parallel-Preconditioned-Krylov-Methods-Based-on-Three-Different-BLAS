#include "ozblas_common.h"

int32_t
OzCSRMV (
	ozblasHandle_t *oh,
	const char tranA, 
	const int32_t m,
	const int32_t n,
	const int32_t nnz,
	const FP_DTYPE alpha,
	const char *descrA, 
	const FP_DTYPE *devA,
	const int32_t *devArowptr,
	const int32_t *devAcolind,
	const FP_DTYPE *devB,
	const FP_DTYPE beta,
	FP_DTYPE *devC
) {
	counterInit (oh);
	if (oh->reproModeFlag == 0 && oh->numSplitArraysMax == 1) {
		double t0 = timer();
		#if defined (PREC_SD)
		printf ("not supported\n");
		exit(1);
		#else
		RMKL_CSRMV (&tranA, &m, &n, &alpha, descrA, devA, devAcolind, devArowptr, devArowptr+1, devB, &beta, devC);
		#endif
		oh->t_SpMV_SpMM_total += timer() - t0;
		return 0;
	}

	double t1, t0 = timer();
	uint32_t numSplitArraysMax = (oh->numSplitArraysMax > 0) ? oh->numSplitArraysMax : NumSplitDefaultMax;
	int32_t ldas, ldbs, ldcs;
	FP_CTYPE fone = 1., fzero = 0.;
	FP_CTYPE done = 1;
	FP_CTYPE *devASplit;
	FP_CTYPE *devAmax, *devBmax;
	FP_CTYPE *devBSplit, *devCSplit;

	int32_t mbk = m; // currently blocking is not supported
	if (mbk != m && oh->memMaskSplitA) { // when blocking is applied, memMaskSplitA cannot be used
		printf ("Blocking is not supported with WithOutSplitA mode\n");
		exit(1);
	}
	if (oh->memMaskSplitA != 0) oh->memAddr = 0;
	ozblasMallocSplitVec (oh, nnz, numSplitArraysMax, &devASplit, &devAmax, ldas); // this is needed even when memMaskSplitA
	if (oh->memMaskSplitA != 0) oh->memMaskSplitA = oh->memAddr;
	ozblasMallocSplitVec (oh, n, numSplitArraysMax, &devBSplit, &devBmax, ldbs);
	ldcs = getPitchSize (mbk);
	devCSplit = (FP_CTYPE*)(oh->devWork + oh->memAddr);
	oh->memAddr += sizeof(FP_CTYPE) * ldcs * numSplitArraysMax * numSplitArraysMax;
	#if defined (PREC_SD)
	int32_t ldat, ldbt;
	FP_CTYPE *devATmp, *devBTmp;
	if (oh->memMaskSplitA == 0) {
		ozblasSDMallocTmpVec (oh, nnz, &devATmp, ldat);
		ozblasSDCopyMat (nnz, 1, devA, nnz, devATmp, ldat);
	}
	ozblasSDMallocTmpVec (oh, n, &devBTmp, ldbt);
	ozblasSDCopyMat (n, 1, devB, n, devBTmp, ldbt);
	#endif
	memCheck (oh);
	for (int32_t im = 0; im < ceil((float)m/mbk); im++) {
		int32_t mbk_ = (m-mbk*im >= mbk) ? mbk : m-mbk*im;

		// Split of A -----------------------------------
		t1 = timer();
		if (oh->memMaskSplitA == 0) {
			oh->numSplitArraysA = numSplitArraysMax;
			#if defined (PREC_SD)
			ozblasSplitShiftMatSparse (oh, 'n', m, devATmp, devArowptr, devASplit, devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
			#else
			ozblasSplitShiftMatSparse (oh, 'n', m, devA, devArowptr, devASplit, devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
			#endif
		} else {
			devASplit = (FP_CTYPE*)devA;
			oh->numSplitArraysA = oh->numSplitArraysA_;
		}
		oh->t_SplitA += timer() - t1;

		// Split of B -----------------------------------
		t1 = timer();
		oh->numSplitArraysB = numSplitArraysMax;
		#if defined (PREC_SD)
		ozblasSplitShiftMat (oh, 'r', n, 1, devBTmp, n, devBSplit, devBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
		#else
		ozblasSplitShiftMat (oh, 'r', n, 1, devB, n, devBSplit, devBmax, ldbs, oh->numSplitArraysB, oh->lastFlagB);
		#endif
		oh->t_SplitB += timer() - t1;

		// Compute --------------------------------------
		t1 = timer();
		int32_t numB, ia, ic = 0;
		uint32_t maxlevel = (oh->numSplitArraysA-1) + (oh->numSplitArraysB-1);
		if (oh->fastModeFlag) {
			if (oh->numSplitArraysMax == 0)	
				maxlevel = MIN (oh->numSplitArraysA-1, oh->numSplitArraysB-1);
			else
				maxlevel = oh->numSplitArraysMax-1;
		}
		FP_CTYPE *ptrA, *ptrB, *ptrC;
		ptrC = devCSplit;
		for (ia = 0; ia < MIN (maxlevel+1, oh->numSplitArraysA); ia++) {
			ptrA = devASplit+ldas*ia;
			if (oh->useGemmFlag) {
				// Note: mkl_dcsrmm seems to use Row-major storage for dense matrices.
				numB = MIN (oh->numSplitArraysB, maxlevel+1 - ia);
				ptrB = devBSplit;
				MKL_CSRMM (&tranA, &mbk_, &numB, &n, &done, descrA, ptrA, devAcolind, devArowptr, devArowptr+1, ptrB, &ldbs, &fzero, ptrC, &ldcs);
				ptrC += ldcs*numB;
				ic += numB;
			} else {
				for (uint32_t ib = 0; ib < oh->numSplitArraysB; ib++) {
					if (ia + ib <= maxlevel) {
						ptrB = devBSplit+ldbs*ib;
						ptrC = devCSplit+ldcs*ic;
						MKL_CSRMV (&tranA, &mbk_, &n, &fone, descrA, ptrA, devAcolind, devArowptr, devArowptr+1, ptrB, &fzero, ptrC);
						ic++;
					}
				}
			}
		}
		oh->numSplitArraysC = ic;
		oh->t_comp += timer() - t1;

		// Sum -----------------------------------------
		t1 = timer();
		ozblasSumMat (mbk_, 1, devCSplit, ldcs, ldcs, oh->numSplitArraysC, &devC[im*mbk], ldcs, alpha, beta, oh->sumModeFlag);
		oh->t_sum += timer() - t1;
	}

	oh->t_total = timer() - t0;

	// for CG, time
	// =================================
	oh->t_SplitMat_total += oh->t_SplitA;
	oh->t_SplitVec_total += oh->t_SplitB;
	oh->t_Sum_total += oh->t_sum;
	oh->t_AXPY_SCAL_total += 0.;
	oh->t_DOT_NRM2_total += 0.;
	oh->t_SpMV_SpMM_total += oh->t_comp;
	// =================================

	return 0;
}

int32_t
OzCSRMVSplitA (
	ozblasHandle_t *oh,
	const char tranA, 
	const int32_t m,
	const int32_t n,
	const int32_t nnz,
	const char *descrA, 
	const FP_CTYPE *devA,
	const int32_t *devArowptr,
	const int32_t *devAcolind,
	FP_CTYPE **devASplit
) {
	counterInit (oh);

	uint32_t numSplitArraysMax = (oh->numSplitArraysMax > 0) ? oh->numSplitArraysMax : NumSplitDefaultMax;
	uint32_t numSplitArraysMaxOrig = oh->numSplitArraysMax;
	int32_t ldas;
	FP_CTYPE *devAmax;

	#if defined (PREC_SD)
	int32_t ldat;
	FP_CTYPE *devATmp;
	ozblasSDMallocTmpVec (oh, nnz, &devATmp, ldat);
	ozblasDCopyMat (nnz, 1, devA, nnz, devATmp, ldat);
	#endif
	ozblasMallocSplitMatSparse (oh, m, nnz, numSplitArraysMax, &devASplit[0], &devAmax, ldas);
	memCheck (oh);
	oh->memMaskSplitA = oh->memAddr;

	double t1 = timer();
	if (oh->reproModeFlag == 0 && oh->numSplitArraysMax == 1) {
		#if defined (PREC_SD)
		ozblasDCopyVec (nnz, devA, devASplit[0]);
		#else
		ozblasCopyVec (nnz, devA, devASplit[0]);
		#endif
	} else {
		// Split of A -----------------------------------
		oh->numSplitArraysA = numSplitArraysMax;
		#if defined (PREC_SD)
		ozblasSplitMatSparse (oh, 'n', m, devATmp, devArowptr, devASplit[0], devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
		#else
		ozblasSplitMatSparse (oh, 'n', m, devA, devArowptr, devASplit[0], devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
		#endif
		// shiftSize-tuning
		// ------------------------------------------------------------------------
		if (numSplitArraysMaxOrig == 0) { // tuning is possible only when full-splitting (d=0)
			printf ("## CSRMV: << shift-size tuning >> num.split = %d -> ", oh->numSplitArraysA);
			oh->splitShift = 1; 
			int32_t numSplitArraysAOld = oh->numSplitArraysA;
			do {
				numSplitArraysAOld = oh->numSplitArraysA;
				oh->splitShift *= 2;
				// try with new shift-size
				oh->numSplitArraysA = numSplitArraysMax;
				#if defined (PREC_SD)
				ozblasSplitShiftMatSparse (oh, 'n', m, devATmp, devArowptr, devASplit[0], devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
				#else
				ozblasSplitShiftMatSparse (oh, 'n', m, devA, devArowptr, devASplit[0], devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
				#endif
			// if numSplit increased, stop
			} while (numSplitArraysAOld == oh->numSplitArraysA);
	
			// do again with the optimal shift-size
			oh->splitShift /= 2;
			oh->numSplitArraysA = numSplitArraysMax;
			#if defined (PREC_SD)
			ozblasSplitShiftMatSparse (oh, 'n', m, devATmp, devArowptr, devASplit[0], devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
			#else
			ozblasSplitShiftMatSparse (oh, 'n', m, devA, devArowptr, devASplit[0], devAmax, ldas, oh->numSplitArraysA, oh->lastFlagA);
			#endif
			printf ("%d (with splitShift = %d)\n", oh->numSplitArraysA, oh->splitShift);
		}
		// ------------------------------------------------------------------------

		oh->numSplitArraysA_ = oh->numSplitArraysA;
	}
	oh->t_SplitA += timer() - t1;

	// for CG, time
	// =================================
	oh->t_SplitMat_total += oh->t_SplitA;
	oh->t_SplitVec_total += 0.;
	oh->t_Sum_total += 0.;
	oh->t_AXPY_SCAL_total += 0.;
	oh->t_DOT_NRM2_total += 0.;
	oh->t_SpMV_SpMM_total += 0.;
	// =================================

	return 0;
}
