#include "testing_common.h"
#include "testing_common.cpp"

int32_t
main (int32_t argc, char **argv)
{
// testing setup ------------------------------
	testingHandle_t th;
	testingCreate (argc, argv, &th);
	#if defined (OZBLAS)
	// On MKL, CSRMM is slow
	th.useGemmFlag = 0;
	#endif
	//print_info1 (&th);
	#if defined (OZBLAS)
	printf ("## Note: force useGemmFlag = 0\n");
	#endif
// --------------------------------------------

// library setup ------------------------------
	#if defined (CUOZBLAS)
	cusparseMatDescr_t descrA;
	cusparseCreateMatDescr (&descrA);
	cusparseSetMatType (descrA, CUSPARSE_MATRIX_TYPE_GENERAL);
	cusparseSetMatIndexBase (descrA, CUSPARSE_INDEX_BASE_ZERO);
	#else
	char descrA[4];
	descrA[0] = 'G';
	descrA[3] = 'C';
	#if defined (OZBLAS) && defined (MKL) 
	if (th.useGemmFlag) 
		descrA[3] = 'F';
	#endif
	#endif

	//printf("000\n");	
	
	#if defined (CUOZBLAS)
	cuozblasHandle_t ha;
	cuozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode); 
	cuozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#else
	ozblasHandle_t ha;
	ozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode); 
	ozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#endif
	//printf("111\n");	
// --------------------------------------------

// memory setup -------------------------------
	struct sparse_matrix_t* hst_A__ = load_sparse_matrix (MATRIX_MARKET, th.mtx_file);
	sparse_matrix_expand_symmetric_storage (hst_A__);
	int errcode = sparse_matrix_convert (hst_A__, CSR);
	if (errcode != 0) {
	    fprintf (stderr, "err: conversion failed.\n");
		free (hst_A__);
		exit (1);
	}
	struct csr_matrix_t* hst_A_ = (struct csr_matrix_t*) hst_A__->repr;
	int32_t m = hst_A_->m;
	int32_t n = hst_A_->n;
	int32_t nnz = hst_A_->nnz;
	
	//printf("222\n");	

	// malloc host memory
	FP_TYPE alpha, beta;
	FP_TYPE *hst_A = new FP_TYPE[nnz];
	FP_TYPE *hst_X = new FP_TYPE[n];
	FP_TYPE *hst_B = new FP_TYPE[n];
	int32_t *hst_Colind = hst_A_->colidx;
	int32_t *hst_Rowptr = hst_A_->rowptr;
	double *hst_Aptr = (double*) hst_A_->values;
	for (int32_t i = 0; i < nnz; i++) 
		hst_A[i] = (FP_TYPE) hst_Aptr[i];

	#if defined (OZBLAS) && defined (MKL) 
// On MKL, SpMM uses one-based indexing while SpMV uses zero-based
	if (th.useGemmFlag) {
		for (int32_t i = 0; i < m+1; i++) 
			hst_Rowptr[i] += 1;
		for (int32_t i = 0; i < nnz; i++) 
			hst_Colind[i] += 1;
	}
	#endif

	int32_t maxiter = th.maxiter;
	//double tol = 1e-16;
	double tol = 1e-8;
	ha.trueres = th.trueres;
	ha.verbose = th.verbose;

	// initialize
	mublasInitMat (n, 1, 0, hst_X, 0., 1);
	mublasInitMat (n, 1, 0, hst_B, 1., 1);
// --------------------------------------------

	print_info2 (&th);

// evaluation ---------------------------------
	#if defined (CUOZBLAS)
	// malloc device memory
	FP_TYPE *dev_A, *dev_X, *dev_B;
	int32_t *dev_Rowptr, *dev_Colind;
	cudaMalloc ((void **) &dev_A, sizeof (FP_TYPE) * nnz);
	cudaMalloc ((void **) &dev_X, sizeof (FP_TYPE) * n);
	cudaMalloc ((void **) &dev_B, sizeof (FP_TYPE) * n);
	cudaMalloc ((void **) &dev_Colind, sizeof (int32_t) * nnz);
	cudaMalloc ((void **) &dev_Rowptr, sizeof (int32_t) * (m+1));
	cudaMemcpy (dev_A, hst_A, sizeof(FP_TYPE) * nnz, cudaMemcpyHostToDevice);
	cudaMemcpy (dev_Colind, hst_Colind, sizeof(int32_t) * nnz, cudaMemcpyHostToDevice);
	cudaMemcpy (dev_Rowptr, hst_Rowptr, sizeof(int32_t) * (m+1), cudaMemcpyHostToDevice);
	cublasSetVector (n, sizeof(FP_TYPE), hst_X, 1, dev_X, 1);
	cublasSetVector (n, sizeof(FP_TYPE), hst_B, 1, dev_B, 1);
	#endif

	printf ("## %s\t%d\t%d\t%d\n", th.mtx_file, m, n, nnz);
        
        //OzCSRMV (oh, tranA, dimN, dimN, dimNNZ, fone, descrA, matASplit, matArowptr, matAcolind, hst_X, fzero, hst_B); // v = Ap_hat
	
        //printf("111\n");
	#if defined (CUOZBLAS)
	OzCG (&ha, cusparse_trans_const_m(th.tranA), n, nnz, descrA, dev_A, dev_Rowptr, dev_Colind, dev_B, dev_X, maxiter, tol);
	#else
	OzCG (&ha, th.tranA, n, nnz, descrA, hst_A, hst_Rowptr, hst_Colind, hst_B, hst_X, maxiter, tol);
	#endif
	//printf("222\n");

// shutdown -----------------------------------
	#if defined (CUOZBLAS)
	cudaFree (dev_A);
	cudaFree (dev_Rowptr);
	cudaFree (dev_Colind);
	cudaFree (dev_X);
	cudaFree (dev_B);
	#endif
	delete[]hst_A;
	delete[]hst_X;
	delete[]hst_B;

	#if defined (CUOZBLAS)
	cuozblasDestroy (&ha);
	#else
	ozblasDestroy (&ha);
	#endif
	destroy_sparse_matrix(hst_A__);
// --------------------------------------------

	return 0;
}

