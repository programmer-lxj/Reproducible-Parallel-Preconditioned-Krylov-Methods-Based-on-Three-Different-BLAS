#ifndef TESTING_COMMON
#define TESTING_COMMON

// header ------------------------------------------
#include "testing_setting.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <float.h>
#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include <sys/time.h>
#include <unistd.h>
#include <math.h>
#include <getopt.h>
#include <ctype.h>

#if defined (CUDA)
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <cublas_v2.h>
#include <cusparse_v2.h>
#endif

#if defined (CUOZBLAS)
#include <cuozblas.h>
#endif
#if defined (OZBLAS)
#include <ozblas.h>
#endif

#include <mpfr.h>
#include <mblas_mpfr.h>

#if defined (CSRMV) || defined (CG)
extern "C" {
#include <bebop/smc/sparse_matrix.h>
#include <bebop/smc/sparse_matrix_ops.h>
#include <bebop/smc/csr_matrix.h>
//#include <sparse_matrix.h>
//#include <sparse_matrix_ops.h>
//#include <csr_matrix.h>
}
#endif

//#define size_t uint32_t
#if defined (PREC_S)
#define FP_TYPE	float

#define MAGMA_OPTS		magma_sopts
#define MAGMA_MATRIX	magma_s_matrix
#define MAGMA_CSR_MTX	magma_s_csr_mtx
#define MAGMA_MTRANSFER	magma_smtransfer
#define MAGMA_MFREE		magma_smfree
//#define MAGMA_COPY		magma_scopy
//#define MAGMA_VINIT		magma_svinit
#define MAGMA_SCAL		magma_sscal
//#define MAGMA_ZERO		MAGMA_S_ZERO
//#define MAGMA_ONE		MAGMA_S_ONE
//#define MAGMA_MAKE		MAGMA_S_MAKE
//#define MAGMA_SOLVER			magma_s_solver
//#define MAGMA_SOLVER_PAR		magma_s_solver_par
//#define MAGMA_SOLVERINFO		magma_ssolverinfo
//#define MAGMA_SOLVERINFO_INIT	magma_ssolverinfo_init
//#define MAGMA_RESIDUALVEC		magma_sresidualvec
//#define MAGMA_PARSE_OPTS		magma_sparse_opts

#if defined (CUOZBLAS)
#define OzCG	cuozblasScg 
#define OzDOT	cuozblasSdot 
#define OzAXPY	cuozblasSaxpy 
#define OzGEMV	cuozblasSgemv
#define OzGEMM	cuozblasSgemm
#define OzNRM2	cuozblasSnrm2
#define OzCSRMV	cuozblasScsrmv
#define OzCSRMVSplitA cuozblasScsrmvSplitA
#elif defined (OZBLAS)
#define OzCG	ozblasScg 
#define OzDOT	ozblasSdot 
#define OzAXPY	ozblasSaxpy 
#define OzGEMV	ozblasSgemv
#define OzGEMM	ozblasSgemm
#define OzNRM2	ozblasSnrm2
#define OzCSRMV	ozblasScsrmv
#define OzCSRMVSplitA ozblasScsrmvSplitA
#endif

#elif defined (PREC_D)
#define FP_TYPE	double

#define MAGMA_OPTS		magma_dopts
#define MAGMA_MATRIX	magma_d_matrix
#define MAGMA_CSR_MTX	magma_d_csr_mtx
#define MAGMA_MTRANSFER	magma_dmtransfer
#define MAGMA_MFREE		magma_dmfree
#define MAGMA_COPY		magma_dcopy
#define MAGMA_VINIT		magma_dvinit
#define MAGMA_SCAL		magma_dscal
#define MAGMA_ZERO		MAGMA_D_ZERO
#define MAGMA_ONE		MAGMA_D_ONE
#define MAGMA_MAKE		MAGMA_D_MAKE
#define MAGMA_SOLVER			magma_d_solver
#define MAGMA_SOLVER_PAR		magma_d_solver_par
#define MAGMA_SOLVERINFO		magma_dsolverinfo
#define MAGMA_SOLVERINFO_INIT	magma_dsolverinfo_init
#define MAGMA_RESIDUALVEC		magma_dresidualvec
#define MAGMA_PARSE_OPTS		magma_dparse_opts

#if defined (CUOZBLAS)
#define OzCG	cuozblasDcg 
#define OzDOT	cuozblasDdot 
#define OzAXPY	cuozblasDaxpy 
#define OzGEMV	cuozblasDgemv
#define OzGEMM	cuozblasDgemm
#define OzNRM2	cuozblasDnrm2
#define OzCSRMV	cuozblasDcsrmv
#define OzCSRMVSplitA cuozblasDcsrmvSplitA
#elif defined (OZBLAS)
#define OzCG	ozblasDcg 
#define OzDOT	ozblasDdot 
#define OzAXPY	ozblasDaxpy 
#define OzGEMV	ozblasDgemv
#define OzGEMM	ozblasDgemm
#define OzNRM2	ozblasDnrm2
#define OzCSRMV	ozblasDcsrmv
#define OzCSRMVSplitA ozblasDcsrmvSplitA
#endif

#elif defined (PREC_SD)
#define FP_TYPE	float

#define MAGMA_OPTS		magma_sopts
#define MAGMA_MATRIX	magma_s_matrix
#define MAGMA_CSR_MTX	magma_s_csr_mtx
#define MAGMA_MTRANSFER	magma_smtransfer
#define MAGMA_MFREE		magma_smfree
#define MAGMA_COPY		magma_scopy
#define MAGMA_VINIT		magma_svinit
#define MAGMA_SCAL		magma_sscal
#define MAGMA_ZERO		MAGMA_S_ZERO
#define MAGMA_ONE		MAGMA_S_ONE
#define MAGMA_MAKE		MAGMA_S_MAKE
#define MAGMA_SOLVER			magma_s_solver
#define MAGMA_SOLVER_PAR		magma_s_solver_par
#define MAGMA_SOLVERINFO		magma_ssolverinfo
#define MAGMA_SOLVERINFO_INIT	magma_ssolverinfo_init
#define MAGMA_RESIDUALVEC		magma_sresidualvec
#define MAGMA_PARSE_OPTS		magma_sparse_opts

#if defined (CUOZBLAS)
#define OzCG	cuozblasSDcg 
#define OzDOT	cuozblasSDdot 
#define OzAXPY	cuozblasSDaxpy 
#define OzGEMV	cuozblasSDgemv
#define OzGEMM	cuozblasSDgemm
#define OzNRM2	cuozblasSDnrm2
#define OzCSRMV	cuozblasSDcsrmv
#define OzCSRMVSplitA cuozblasSDcsrmvSplitA
#elif defined (OZBLAS)
#define OzCG	ozblasSDcg 
#define OzDOT	ozblasSDdot 
#define OzAXPY	ozblasSDaxpy 
#define OzGEMV	ozblasSDgemv
#define OzGEMM	ozblasSDgemm
#define OzNRM2	ozblasSDnrm2
#define OzCSRMV	ozblasSDcsrmv
#define OzCSRMVSplitA ozblasSDcsrmvSplitA
#endif

#endif
#endif
