#define ROUTINE_FLOPS(m,n,k)	(2*k+2*m+m)
#define ROUTINE_BYTES(m,n,k,s)	((k+2*m+n)*s+(k+m+1)*4) 
#include "testing_common.h"
#include "testing_common.cpp"

void mpfrCsrmv (
	testingHandle_t th, int32_t m, int32_t n, int32_t nnz,
	mpreal alpha, mpreal* matA, int32_t* matAptr, int32_t* matAind,
	mpreal* x, mpreal beta, mpreal* y
	) {
	int32_t i, j;
	mpreal t;
	for(j = 0; j < m; j++) {
		t = 0.;
		for(i = matAptr[j]; i < matAptr[j+1]; i++) 
			t = t + matA[i] * x[matAind[i]];
		y[j] = alpha * t + beta * y[j];
	}
}

/*
FP_TYPE mpfrCsrmvCond (
	testingHandle_t th, int32_t m, int32_t n, int32_t nnz,
	mpreal* matA, int32_t* matAptr, int32_t* matAind,
	mpreal* x
	) {
	// cond (xTy) := 2|xT||y|/|xTy|, xTy neq 0
	int i, j;
	mpreal y, t, s;
	mpreal condmax = 0.;
	mpreal nrmAi, nrmX, condi;

	for(j = 0; j < m; j++) {
		y = 0.;
		// nrmA & nrmX
		nrmAi = 0.;
		nrmX = 0.;
		for(i = matAptr[j]; i < matAptr[j+1]; i++) {
			t = matA[i];
			nrmAi += t*t;
			s = x[matAind[i]];
			nrmX += s*s;
		}
		nrmAi = sqrt(nrmAi);
		nrmX = sqrt(nrmX);
		// y = Ax
		for(i = matAptr[j]; i < matAptr[j+1]; i++) 
			y = y + matA[i] * x[matAind[i]];
		condi = 2.*nrmAi*nrmX/y;
		if (condi > condmax) 
			condmax = condi;
	}
	return mpfr_get_d(condmax,MPFR_RNDN);
}
*/

int32_t
main (int32_t argc, char **argv)
{
	int32_t i;
	double t0, t1, sec;

    mpfr_set_default_prec(MPFR_PREC);
	mpreal::set_default_prec(MPFR_PREC);

// testing setup ------------------------------
	testingHandle_t th;
	testingCreate (argc, argv, &th);
	print_info1 (&th);
// --------------------------------------------

// library setup ------------------------------
	#if defined (CUOZBLAS)
	cusparseMatDescr_t descrA;
	cusparseCreateMatDescr (&descrA);
	cusparseSetMatType (descrA, CUSPARSE_MATRIX_TYPE_GENERAL);
	cusparseSetMatIndexBase (descrA, CUSPARSE_INDEX_BASE_ZERO);
	#else
	char descrA[4];
	descrA[0] = 'G';
	descrA[3] = 'C';
	#if defined (OZBLAS) && defined (MKL)
	if (th.useGemmFlag)
		descrA[3] = 'F';
	#endif
	#endif

	#if defined (CUOZBLAS)
	cuozblasHandle_t ha;
	cuozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode); 
	cuozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#else
	ozblasHandle_t ha;
	ozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode); 
	ozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#endif
// --------------------------------------------

// memory setup -------------------------------
	struct sparse_matrix_t* hst_A__ = load_sparse_matrix (MATRIX_MARKET, th.mtx_file);
	sparse_matrix_expand_symmetric_storage (hst_A__);
	int errcode = sparse_matrix_convert (hst_A__, CSR);
	if (errcode != 0) {
	    fprintf (stderr, "err: conversion failed.\n");
		free (hst_A__);
		exit (1);
	}
	FP_TYPE *VAL;
	struct csr_matrix_t* hst_A_ = (struct csr_matrix_t*) hst_A__->repr;
	int32_t m = hst_A_->m;
	int32_t n = hst_A_->n;
	int32_t nnz = hst_A_->nnz;

	// malloc host memory
	FP_TYPE alpha, beta;
	FP_TYPE *hst_A = new FP_TYPE[nnz];
	FP_TYPE *hst_X = new FP_TYPE[n];
	FP_TYPE *hst_Y = new FP_TYPE[m];
	FP_TYPE *hst_Y_t = new FP_TYPE[m];
	int32_t *hst_Colind = hst_A_->colidx;
	int32_t *hst_Rowptr = hst_A_->rowptr;
	double *hst_Aptr = (double*) hst_A_->values;
	for (int32_t i = 0; i < nnz; i++) 
		hst_A[i] = (FP_TYPE) hst_Aptr[i];

	// initialize
	#if defined (OZBLAS) && defined (MKL)
	// On MKL, SpMM uses one-based indexing while SpMV uses zero-based
	if (th.useGemmFlag) {
		for (i = 0; i < m+1; i++) 
			hst_Rowptr[i] += 1;
		for (i = 0; i < nnz; i++) 
			hst_Colind[i] += 1;
	}
	#endif
	mublasInitMat (1, 1, 0, &alpha, 1., 1);
	mublasInitMat (1, 1, 0, &beta, 0., 1);
	mublasInitMat (n, 1, 0, hst_X, th.phi, 3);
	mublasInitMat (m, 1, 0, hst_Y, th.phi, 3);
// --------------------------------------------

	print_info2 (&th);

// evaluation ---------------------------------
	#if defined (CUOZBLAS)
	// malloc device memory
	FP_TYPE *dev_A, *dev_X, *dev_Y;
	int32_t *dev_Rowptr, *dev_Colind;
	cudaMalloc ((void **) &dev_A, sizeof(FP_TYPE) * nnz);
	cudaMalloc ((void **) &dev_Colind, sizeof(int32_t) * nnz);
	cudaMalloc ((void **) &dev_Rowptr, sizeof(int32_t) * (m+1));
	cudaMalloc ((void **) &dev_X, sizeof (FP_TYPE) * n);
	cudaMalloc ((void **) &dev_Y, sizeof (FP_TYPE) * m);
	cudaMemcpy (dev_A, hst_A, sizeof(FP_TYPE) * nnz, cudaMemcpyHostToDevice);
	cudaMemcpy (dev_Colind, hst_Colind, sizeof(int32_t) * nnz, cudaMemcpyHostToDevice);
	cudaMemcpy (dev_Rowptr, hst_Rowptr, sizeof(int32_t) * (m+1), cudaMemcpyHostToDevice);
	cublasSetVector (n, sizeof(FP_TYPE), hst_X, 1, dev_X, 1);
	cublasSetVector (m, sizeof(FP_TYPE), hst_Y, 1, dev_Y, 1);
	#endif

	printf ("%s\t%d\t%d\t%d\t", th.mtx_file, m, n, nnz);
	th.dim_n_dev = n;
	th.dim_m_dev = m;
	th.dim_k_dev = nnz;
	get_routine_theoretial_performance (&th);
	
	// execution ---------------------------------
	if (th.mode == 'p') {
		// warm up
		for (i = 0; i < WLOOP; i++) {
			#if defined (CUOZBLAS)
			OzCSRMV (&ha, cusparse_trans_const_m(th.tranA), m, n, nnz, &alpha, descrA, dev_A, dev_Rowptr, dev_Colind, dev_X, &beta, dev_Y);
			#else
			OzCSRMV (&ha, th.tranA, m, n, nnz, alpha, descrA, hst_A, hst_Rowptr, hst_Colind, hst_X, beta, hst_Y);
			#endif
		}
		t0 = gettime ();
		for (i = 0; i < NLOOP; i++) {
			#if defined (CUOZBLAS)
			OzCSRMV (&ha, cusparse_trans_const_m(th.tranA), m, n, nnz, &alpha, descrA, dev_A, dev_Rowptr, dev_Colind, dev_X, &beta, dev_Y);
			#else
			OzCSRMV (&ha, th.tranA, m, n, nnz, alpha, descrA, hst_A, hst_Rowptr, hst_Colind, hst_X, beta, hst_Y);
			#endif
		}
		t1 = gettime ();
		sec = (t1 - t0) / NLOOP;
		printf ("\t%1.3e\t%1.3e\t%1.3e\t%d", sec, (th.routine_flops / sec) * 1.0e-9, (th.routine_bytes / sec) * 1.0e-9, NLOOP);
	}
	if (th.mode == 'c') {
		#if defined (CUOZBLAS)
		cublasSetVector (m, sizeof(FP_TYPE), hst_Y, 1, dev_Y, 1);
		OzCSRMV (&ha, cusparse_trans_const_m(th.tranA), m, n, nnz, &alpha, descrA, dev_A, dev_Rowptr, dev_Colind, dev_X, &beta, dev_Y);
		//// w/o SplitA
		//FP_TYPE *devASplit;
		//OzCSRMVSplitA (&ha,cusparse_trans_const_m('n'),m,n,nnz,descrA,dev_A,dev_Rowptr,dev_Colind,&devASplit);
		//OzCSRMV (&ha, cusparse_trans_const_m(th.tranA), m, n, nnz, &alpha, descrA, devASplit, dev_Rowptr, dev_Colind, dev_X, &beta, dev_Y);
		#else
		mublasCopyMat (m, 1, 0, hst_Y, hst_Y_t);
		OzCSRMV (&ha, th.tranA, m, n, nnz, alpha, descrA, hst_A, hst_Rowptr, hst_Colind, hst_X, beta, hst_Y_t);
		#endif
	}
	// -------------------------------------------

	#if defined (CUOZBLAS)
	if (th.mode == 'c') cublasGetVector (m, sizeof(FP_TYPE), dev_Y, 1, hst_Y_t, 1);
	cudaFree (dev_A);
	cudaFree (dev_Colind);
	cudaFree (dev_Rowptr);
	cudaFree (dev_X);
	cudaFree (dev_Y);
	#endif
	if (th.mode == 'c') {
		mpreal alpha_r = 0;
		mpreal beta_r = 0;
		mpreal *hst_A_r = new mpreal[nnz];
		mpreal *hst_X_r = new mpreal[n];
		mpreal *hst_Y_r = new mpreal[m];
		mublasConvMat (1, 1, 0, &alpha, &alpha_r);
		mublasConvMat (1, 1, 0, &beta, &beta_r);
		mublasConvMat (nnz, 1, 0, hst_A, hst_A_r);
		mublasConvMat (n, 1, 0, hst_X, hst_X_r);
		mublasConvMat (m, 1, 0, hst_Y, hst_Y_r);

		#if defined (OZBLAS) && defined (MKL)
		if (th.useGemmFlag) {
			for (i = 0; i < m+1; i++) 
				hst_Rowptr[i] -= 1;
			for (i = 0; i < nnz; i++) 
				hst_Colind[i] -= 1;
		}
		#endif

		mpfrCsrmv (th, m, n, nnz, alpha_r, hst_A_r, hst_Rowptr, hst_Colind, hst_X_r, beta_r, hst_Y_r);
//		FP_TYPE condmax;
//		condmax = mpfrCsrmvCond (th,m, n, nnz, hst_A_r, hst_Rowptr, hst_Colind, hst_X_r);
//		printf ("### condmax = %1.3e\n", condmax);
		mublasCheckMatrix (m, 1, hst_Y_t, m, hst_Y_r, m);
		delete[]hst_A_r;
		delete[]hst_X_r;
		delete[]hst_Y_r;
	}
	#if defined (CUOZBLAS)
	print_cuozblas_info1 (&th, &ha);
	#else
	print_ozblas_info1 (&th, &ha);
	#endif
	printf ("\n");
// --------------------------------------------

// shutdown -----------------------------------
	delete[]hst_A;
	delete[]hst_X;
	delete[]hst_Y;
	delete[]hst_Y_t;

	#if defined (CUOZBLAS)
	cuozblasDestroy (&ha);
	#else
	ozblasDestroy (&ha);
	#endif
// --------------------------------------------
	destroy_sparse_matrix(hst_A__);
	return 0;
}

