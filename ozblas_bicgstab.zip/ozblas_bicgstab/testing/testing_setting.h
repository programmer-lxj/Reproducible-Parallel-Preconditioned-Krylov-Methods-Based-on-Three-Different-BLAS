#ifndef TESTING_SETTING
#define TESTING_SETTING

// ***** SETTING ***********************************
#define SIZE_T			size_t
#define CUBLAS_POINTER_MODE_VALUE	CUBLAS_POINTER_MODE_HOST
#define WLOOP			3 // (times)
#define NLOOP			10 // (times)
#define MPFR_PREC		2048 // (bits)
#define WORK_MEM_SIZE	10e9 // (bytes)
// ***** SETTING ***********************************

#endif
