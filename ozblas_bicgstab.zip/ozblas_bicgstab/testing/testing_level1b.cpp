#define ROUTINE_FLOPS(m,n,k)	(2*n)
#define ROUTINE_BYTES(m,n,k,s)	(2*n*s)
#include "testing_common.h"
#include "testing_common.cpp"

int32_t
main (int32_t argc, char **argv)
{
	int32_t i;
	double t0, t1, sec;
	mpreal hst_result_r;
    mpfr_set_default_prec(MPFR_PREC);
	mpreal::set_default_prec(MPFR_PREC);

// testing setup ------------------------------
	testingHandle_t th;
	testingCreate (argc, argv, &th);
	print_info1 (&th);
// --------------------------------------------

// library setup ------------------------------
	#if defined (CUOZBLAS)
	cuozblasHandle_t ha;
	cuozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode);
	cuozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#else
	ozblasHandle_t ha;
	ozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode);
	ozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#endif
// --------------------------------------------

// memory setup -------------------------------
	FP_TYPE hst_result_t;
	#if defined (CUOZBLAS)
	FP_TYPE *dev_X, *dev_Y;//, *ptr_result_t;
	/*
	if (th.pmode)	cudaMalloc ((void **) &ptr_result_t, sizeof(FP_TYPE));
	else			ptr_result_t = &hst_result_t;
	if (th.pmode)	cudaMalloc ((void **) &ptr_result_r, sizeof(FP_TYPE));
	else			ptr_result_r = &hst_result_r;
	*/
	#endif

	// dim setup
	dim_hst_setup (&th);
	// malloc host memory
	FP_TYPE *hst_X = new FP_TYPE[th.dim_n_hst * th.incx];
	FP_TYPE *hst_Y = new FP_TYPE[th.dim_n_hst * th.incy];
	// initialize (1:val, 2:phi, 3:erange)
	mublasInitMat (th.dim_n_hst*th.incx, 1, 0, hst_X, th.phi, 3);
	mublasInitMat (th.dim_n_hst*th.incy, 1, 0, hst_Y, th.phi, 3); 
// --------------------------------------------

	print_info2 (&th);

// evaluation ---------------------------------
	dim_dev_setup (&th);
	while (1) {
		if (th.dim_n_const == 0 && th.dim_n_dev > th.dim_stop) break;

		#if defined (CUOZBLAS)
		cudaMalloc ((void **) &dev_X, sizeof(FP_TYPE) * th.dim_n_dev * th.incx);
		cudaMalloc ((void **) &dev_Y, sizeof(FP_TYPE) * th.dim_n_dev * th.incy);
		cublasSetVector(th.dim_n_dev * th.incx, sizeof(FP_TYPE), hst_X, 1, dev_X, 1);
		cublasSetVector(th.dim_n_dev * th.incy, sizeof(FP_TYPE), hst_Y, 1, dev_Y, 1);
		#endif

		printf ("--\t%d\t--", th.dim_n_dev);
		get_routine_theoretial_performance (&th);
		// execution ---------------------------------
		if (th.mode == 'p') {
			// warm up
			for (i = 0; i < WLOOP; i++) {
				#if defined (CUOZBLAS)
				OzDOT (&ha, th.dim_n_dev, dev_X, 1, dev_Y, 1, &hst_result_t);
				#else
				hst_result_t = OzDOT (&ha, th.dim_n_dev, hst_X, 1, hst_Y, 1);
				#endif
			}
			t0 = gettime ();
			for (i = 0; i < NLOOP; i++) {
				#if defined (CUOZBLAS)
				OzDOT (&ha, th.dim_n_dev, dev_X, 1, dev_Y, 1, &hst_result_t); 
				#else
				hst_result_t = OzDOT (&ha, th.dim_n_dev, hst_X, 1, hst_Y, 1);
				#endif
			}
			t1 = gettime ();
			sec = (t1 - t0) / NLOOP;
			printf ("\t%1.3e\t%1.3e\t%1.3e\t%d", sec, (th.routine_flops / sec) * 1.0e-9, (th.routine_bytes / sec) * 1.0e-9, NLOOP);
		}
		if (th.mode == 'c') {
			#if defined (CUOZBLAS)
			OzDOT (&ha, th.dim_n_dev, dev_X, 1, dev_Y, 1, &hst_result_t); 
			#else
			hst_result_t = OzDOT (&ha, th.dim_n_dev, hst_X, 1, hst_Y, 1);
			#endif
		}
		// -------------------------------------------

		#if defined (CUOZBLAS)
//		if (th.mode == 'c') 
//			if (th.pmode) cublasGetVector (1, sizeof(FP_TYPE), ptr_result_t, 1, &hst_result_t, 1);
		cudaFree (dev_X);
		cudaFree (dev_Y);
		#endif

		if (th.mode == 'c') {
			mpreal *hst_X_r = new mpreal[th.dim_n_hst];
			mpreal *hst_Y_r = new mpreal[th.dim_n_hst];
			mublasConvMat (th.dim_n_hst*th.incx, 1, 0, hst_X, hst_X_r);
			mublasConvMat (th.dim_n_hst*th.incy, 1, 0, hst_Y, hst_Y_r);
			hst_result_r = Rdot (th.dim_n_dev,hst_X_r,1,hst_Y_r,1);
			mublasCheckMatrix (1, 1, &hst_result_t, 1, &hst_result_r, 1);
			delete[]hst_X_r;
			delete[]hst_Y_r;
		}

		#if defined (CUOZBLAS) 
		print_cuozblas_info1 (&th, &ha);
		#else
		print_ozblas_info1 (&th, &ha);
		#endif
		printf ("\n");

		dim_dev_increment (&th);
		if (th.dim_m_const && th.dim_n_const && th.dim_k_const) break;
	}
// --------------------------------------------

// shutdown -----------------------------------
	delete[]hst_X;
	delete[]hst_Y;
	/*
	#if defined (CUOZBLAS)
	if (th.pmode) cudaFree (ptr_result_r);
	if (th.pmode) cudaFree (ptr_result_t);
	#endif
	*/

	#if defined (CUOZBLAS)
	cuozblasDestroy (&ha);
	#else
	ozblasDestroy (&ha);
	#endif
// --------------------------------------------

	return 0;
}
