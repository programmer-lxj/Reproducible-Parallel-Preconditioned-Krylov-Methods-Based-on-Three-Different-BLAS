#define ROUTINE_FLOPS(m,n,k)	(2*m*n+3*m)
#define ROUTINE_BYTES(m,n,k,s)	((2*m+n+m*n)*s) 
#include "testing_common.h"
#include "testing_common.cpp"

int32_t
main (int32_t argc, char **argv)
{
	int32_t i;
	int32_t lda_hst;
	int32_t cda_dev, cda_hst;
	int32_t rda_dev, rda_hst;
	int32_t vlx_dev, vlx_hst;
	int32_t vly_dev, vly_hst;
	double t0, t1, sec;

    mpfr_set_default_prec(MPFR_PREC);
	mpreal::set_default_prec(MPFR_PREC);

// testing setup ------------------------------
	testingHandle_t th;
	testingCreate (argc, argv, &th);
	print_info1 (&th);
// --------------------------------------------

// library setup ------------------------------
	#if defined (CUOZBLAS)
	cuozblasHandle_t ha;
	cuozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode); 
	cuozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#else
	ozblasHandle_t ha;
	ozblasCreate (&ha, WORK_MEM_SIZE, th.numSplitArraysMax, th.fastmode, th.repromode, th.summode); 
	ozblasProfilingSetting (&ha, th.useGemmFlag, th.useMyGemmFlag, th.useBatchedGemmFlag);
	#endif
// --------------------------------------------

// memory setup -------------------------------
	dim_hst_setup (&th);
	rda_hst = th.dim_stop;
	cda_hst = th.dim_stop;
	vlx_hst = th.dim_stop;
	vly_hst = th.dim_stop;
	if (th.tranA == 'N' || th.tranA == 'n') {
		if (th.dim_n_const > 0) vlx_hst = th.dim_n_const;
		if (th.dim_m_const > 0) vly_hst = th.dim_m_const;
	} else {
		if (th.dim_m_const > 0) vlx_hst = th.dim_m_const;
		if (th.dim_n_const > 0) vly_hst = th.dim_n_const;
	}
	if (th.dim_m_const > 0) rda_hst = th.dim_m_const;
	if (th.dim_n_const > 0) cda_hst = th.dim_n_const;
	lda_hst = rda_hst;
	// malloc host memory
	FP_TYPE alpha, beta;
	FP_TYPE *hst_A = new FP_TYPE[lda_hst * cda_hst];
	FP_TYPE *hst_X = new FP_TYPE[vlx_hst * th.incx];
	FP_TYPE *hst_Y = new FP_TYPE[vly_hst * th.incy];
	FP_TYPE *hst_Y_t = new FP_TYPE[vly_hst * th.incy];
	// initialize (1:val, 2:phi, 3:erange)
	mublasInitMat (1, 1, 1, &alpha, 1., 1);
	mublasInitMat (1, 1, 1, &beta, 0., 1);
	mublasInitMat (lda_hst, cda_hst, lda_hst, hst_A, th.phi, 3);
	mublasInitMat (vlx_hst * th.incx, 1, 0, hst_X, th.phi, 3);
	mublasInitMat (vly_hst * th.incy, 1, 0, hst_Y, th.phi, 3);
// --------------------------------------------
	print_info2 (&th);

// evaluation ---------------------------------
	dim_dev_setup (&th);
	while (1) {
		if ((th.dim_m_const == 0 && th.dim_m_dev > th.dim_stop) ||
		    (th.dim_n_const == 0 && th.dim_n_dev > th.dim_stop)) break;
		// dim setup
		if (th.tranA == 'N' || th.tranA == 'n') {
			vlx_dev = th.dim_n_dev;
			vly_dev = th.dim_m_dev;
		} else {
			vlx_dev = th.dim_m_dev;
			vly_dev = th.dim_n_dev;
		}
		rda_dev = th.dim_m_dev;
		cda_dev = th.dim_n_dev;
		#if defined (CUOZBLAS)
		// malloc device memory
		FP_TYPE *dev_A, *dev_X, *dev_Y;
		size_t pitch;
		cudaMallocPitch ((void **) &dev_A, &pitch, sizeof(FP_TYPE) * rda_dev, cda_dev);
		int32_t lda_dev = pitch/sizeof(FP_TYPE);
		cudaMalloc ((void **) &dev_X, sizeof(FP_TYPE) * vlx_dev * th.incx);
		cudaMalloc ((void **) &dev_Y, sizeof(FP_TYPE) * vly_dev * th.incy);
		// memcpy from hst to device
		cublasSetMatrix (rda_dev, cda_dev, sizeof(FP_TYPE), hst_A, lda_hst, dev_A, lda_dev);
		cublasSetVector (vlx_dev * th.incx, sizeof(FP_TYPE), hst_X, 1, dev_X, 1);
		// ---------------------------------------------
		#endif

		printf ("%d\t%d\t--", th.dim_m_dev, th.dim_n_dev);
		get_routine_theoretial_performance (&th);

		// execution ---------------------------------
		if (th.mode == 'p') {
			// warm up
			for (i = 0; i < WLOOP; i++) {
				#if defined (CUOZBLAS)
				OzGEMV (&ha, cublas_trans_const_m(th.tranA), rda_dev, cda_dev, &alpha, dev_A, lda_dev, dev_X, 1, &beta, dev_Y, 1);
				#else
				OzGEMV (&ha, th.tranA, rda_dev, cda_dev, alpha, hst_A, lda_hst, hst_X, 1, beta, hst_Y, 1);
				#endif
			}
			t0 = gettime ();
			for (i = 0; i < NLOOP; i++) {
				#if defined (CUOZBLAS)
				OzGEMV (&ha, cublas_trans_const_m(th.tranA), rda_dev, cda_dev, &alpha, dev_A, lda_dev, dev_X, 1, &beta, dev_Y, 1);
				#else
				OzGEMV (&ha, th.tranA, rda_dev, cda_dev, alpha, hst_A, lda_hst, hst_X, 1, beta, hst_Y, 1);
				#endif
			}
			t1 = gettime ();
			sec = (t1 - t0) / NLOOP;
			printf ("\t%1.3e\t%1.3e\t%1.3e\t%d", sec, (th.routine_flops / sec) * 1.0e-9, (th.routine_bytes / sec) * 1.0e-9, NLOOP);
		}
		if (th.mode == 'c') {
			#if defined (CUOZBLAS)
			cublasSetVector (vly_dev * th.incy, sizeof(FP_TYPE), hst_Y, 1, dev_Y, 1);
			OzGEMV (&ha, cublas_trans_const_m(th.tranA), rda_dev, cda_dev, &alpha, dev_A, lda_dev, dev_X, 1, &beta, dev_Y, 1);
			#else
			mublasCopyMat (vly_dev * th.incy, 1, 0, hst_Y, hst_Y_t);
			OzGEMV (&ha, th.tranA, rda_dev, cda_dev, alpha, hst_A, lda_hst, hst_X, 1, beta, hst_Y_t, 1);
			#endif
		}
		// -------------------------------------------

		#if defined (CUOZBLAS)
		if (th.mode == 'c') cublasGetVector (vly_dev * th.incy, sizeof(FP_TYPE), dev_Y, 1, hst_Y_t, 1);
		cudaFree (dev_A);
		cudaFree (dev_X);
		cudaFree (dev_Y);
		#endif
		if (th.mode == 'c') {
			mpreal alpha_r = 0;
			mpreal beta_r = 0;
			mpreal *hst_A_r = new mpreal[lda_hst * cda_dev];
			mpreal *hst_X_r = new mpreal[vlx_dev * th.incx];
			mpreal *hst_Y_r = new mpreal[vly_dev * th.incy];
			mublasConvMat (1, 1, 0, &alpha, &alpha_r);
			mublasConvMat (1, 1, 0, &beta, &beta_r);
			mublasConvMat (rda_dev, cda_dev, lda_hst, hst_A, hst_A_r);
			mublasConvMat (vlx_dev * th.incx, 1, 0, hst_X, hst_X_r);
			mublasConvMat (vly_dev * th.incy, 1, 0, hst_Y, hst_Y_r);
			Rgemv (&th.tranA,rda_dev,cda_dev,alpha_r,hst_A_r,lda_hst,hst_X_r,1,beta_r,hst_Y_r,1);
			mublasCheckMatrix (vly_dev * th.incy, 1, hst_Y_t, vly_dev * th.incy, hst_Y_r, vly_dev * th.incy);
			delete[]hst_A_r;
			delete[]hst_X_r;
			delete[]hst_Y_r;
		}
		#if defined (CUOZBLAS)
		print_cuozblas_info1 (&th, &ha);
		#else
		print_ozblas_info1 (&th, &ha);
		#endif
		printf ("\n");

		dim_dev_increment (&th);
		if (th.dim_m_const && th.dim_n_const) break;
	}
// --------------------------------------------
	delete[]hst_A;
	delete[]hst_X;
	delete[]hst_Y;
	delete[]hst_Y_t;

	#if defined (CUOZBLAS)
	cuozblasDestroy (&ha);
	#else
	ozblasDestroy (&ha);
	#endif
// --------------------------------------------

	return 0;
}
