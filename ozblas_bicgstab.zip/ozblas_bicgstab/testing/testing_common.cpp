// ----- testing handler ---------------------------------------------------------------
struct testingHandle_t {
	// device parameter (single GPU only)
	#if defined (CUDA)
	cudaDeviceProp devprop;
	#endif
	uint32_t devno;
	int32_t cc;
	double device_bytes_per_sec;
	double device_flops_per_sec_sp;
	double device_flops_per_sec_dp;
	int32_t Cores;
	int32_t DPCores;

	// testing parameter
	char mode; // c=check, p=perf

	double routine_flops;
	double routine_bytes;

	int32_t driverVersion; 
	int32_t runtimeVersion;
	int32_t nodisp;
	uint32_t numSplitArraysMax;
	uint32_t fastmode;
	uint32_t repromode;
	uint32_t summode;
	uint32_t useGemmFlag;
	uint32_t useMyGemmFlag;
	uint32_t useBatchedGemmFlag;
	float sparseThreshold;
	uint32_t trueres;
	uint32_t verbose;

	// dim
	int32_t dim_start;
	int32_t dim_stop;
	int32_t dim_step;
	int32_t dim_m_const;
	int32_t dim_n_const;
	int32_t dim_k_const;
	int32_t dim_m_dev;
	int32_t dim_n_dev;
	int32_t dim_k_dev;
	int32_t dim_m_hst;
	int32_t dim_n_hst;
	int32_t dim_k_hst;
	int32_t incx;
	int32_t incy;
	int32_t lda_dev;
	int32_t ldb_dev;
	int32_t ldc_dev;
	uint32_t dim_step_mode;
	#if defined (CUDA)
	cublasPointerMode_t pmode;
//	cublasAtomicsMode_t amode;
	#endif

	// options
	char tranA; // N, T, C
	char tranB; // N, T, C
	char mtx_file[256];
	int32_t phi; // for input data
	uint32_t maxiter; // for iterative solvers
};

// ----- CUBLAS const value function ---------------------------------------------------------------
#if defined (CUDA)
inline cublasOperation_t cublas_trans_const_m (char tran) {
	if (tran == 'N' || tran == 'n') return CUBLAS_OP_N;
	if (tran == 'T' || tran == 't') return CUBLAS_OP_T;
	if (tran == 'C' || tran == 'c') return CUBLAS_OP_C;
	return CUBLAS_OP_N; //default
}
inline cusparseOperation_t cusparse_trans_const_m (char tran) {
	if (tran == 'N' || tran == 'n') return CUSPARSE_OPERATION_NON_TRANSPOSE;
	if (tran == 'T' || tran == 't') return CUSPARSE_OPERATION_TRANSPOSE;
	if (tran == 'C' || tran == 'c') return CUSPARSE_OPERATION_CONJUGATE_TRANSPOSE;
	return CUSPARSE_OPERATION_NON_TRANSPOSE; //default
}
#endif

#if !defined (CG)
void get_routine_theoretial_performance (testingHandle_t *th) {
	int32_t s = sizeof(FP_TYPE);
	int32_t n = th->dim_n_dev;
	int32_t m = th->dim_m_dev;
	int32_t k = th->dim_k_dev;
	th->routine_flops = (double) ROUTINE_FLOPS (m, n, k);
	th->routine_bytes = (double) ROUTINE_BYTES (m, n, k, s);
}
#endif

void dim_hst_setup (testingHandle_t *th) {
	th->dim_m_hst = th->dim_stop;
	th->dim_n_hst = th->dim_stop;
	th->dim_k_hst = th->dim_stop;
	if (th->dim_m_const > 0) th->dim_m_hst = th->dim_m_const;
	if (th->dim_n_const > 0) th->dim_n_hst = th->dim_n_const;
	if (th->dim_k_const > 0) th->dim_k_hst = th->dim_k_const;
}

void dim_dev_setup (testingHandle_t *th) {
	th->dim_m_dev = th->dim_start;
	th->dim_n_dev = th->dim_start;
	th->dim_k_dev = th->dim_start;
	if (th->dim_m_const > 0) th->dim_m_dev = th->dim_m_const;
	if (th->dim_n_const > 0) th->dim_n_dev = th->dim_n_const;
	if (th->dim_k_const > 0) th->dim_k_dev = th->dim_k_const;
}

void dim_dev_increment (testingHandle_t *th) {
	if (th->dim_m_const == 0) {
		switch (th->dim_step_mode) {
			case 1: th->dim_m_dev *= 10; break;
			case 2: th->dim_m_dev *= 2; break;
			default: th->dim_m_dev += th->dim_step; break;
		}
	}
	if (th->dim_n_const == 0) {
		switch (th->dim_step_mode) {
			case 1: th->dim_n_dev *= 10; break;
			case 2: th->dim_n_dev *= 2; break;
			default: th->dim_n_dev += th->dim_step; break;
		}
	}
	if (th->dim_k_const == 0) {
		switch (th->dim_step_mode) {
			case 1: th->dim_k_dev *= 10; break;
			case 2: th->dim_k_dev *= 2; break;
			default: th->dim_k_dev += th->dim_step; break;
		}
	}
}

__inline__ double gettime () {
	struct timeval tv;
	#if defined (CUDA)
	cudaDeviceSynchronize ();
	#endif
	gettimeofday (&tv, NULL);
	return tv.tv_sec + (double) tv.tv_usec * 1.0e-6;
}

int32_t get_num_sp_cores (int32_t cc) {
	switch (cc) {
		case 300: return 192;
		case 320: return 192;
		case 350: return 192;
		case 370: return 192;
		case 500: return 128;
		case 520: return 128;
		case 530: return 128;
		case 600: return 64;
		case 610: return 128;
		case 620: return 128;
		case 700: return 64;
		default: 
			printf ("error: unknown architecture\n");
			return 0;
	}
}

int32_t get_num_dp_cores (int32_t cc) {
	switch (cc) {
		case 300: return 64;
		case 320: return 64;
		case 350: return 64;
		case 370: return 64;
		case 500: return 0;
		case 520: return 4;
		case 530: return 0;
		case 600: return 32;
		case 610: return 4;
		case 620: return 4;
		case 700: return 32;
		default: 
			printf ("error: unknown architecture\n");
			return 0;
	}
}

void dev_setting (testingHandle_t *th) {
	int32_t driverVersion = 0;
	int32_t runtimeVersion = 0;
	int32_t devcnt;
#if defined (CUDA)
	cudaGetDeviceCount (&devcnt);
	cudaDeviceProp devprop;  
	cudaDriverGetVersion(&driverVersion);
	cudaRuntimeGetVersion(&runtimeVersion);
	th->driverVersion = driverVersion;
	th->runtimeVersion = runtimeVersion;
	cudaSetDevice (th->devno);
	cudaGetDeviceProperties (&devprop, th->devno);
	th->devprop = devprop;
	th->cc = devprop.major * 100 + devprop.minor * 10;
	th->Cores = get_num_sp_cores (th->cc);
	th->DPCores = get_num_dp_cores (th->cc);
	th->device_bytes_per_sec = (double)th->devprop.memoryClockRate * 2. * 1000. * (double)th->devprop.memoryBusWidth / 8.;
	th->device_flops_per_sec_sp = (double)th->devprop.clockRate * 1000. * 2. * (double)th->devprop.multiProcessorCount * th->Cores;
	th->device_flops_per_sec_dp = (double)th->devprop.clockRate * 1000. * 2. * (double)th->devprop.multiProcessorCount * th->DPCores;
#endif
}

void testingCreate (int32_t argc, char **argv, testingHandle_t *th) {
 	// default ---------------------------
	th->devno = 0;
	th->mode = 'c';
	// options
	th->tranA = 'N';
	th->tranB = 'N';

	th->nodisp = 0;
	th->numSplitArraysMax = 0;
	th->fastmode = 0;
	th->repromode = 1;
	th->summode = 1;
	th->useGemmFlag = 1;
	th->useMyGemmFlag = 1;
	th->useBatchedGemmFlag = 1;
	th->sparseThreshold = 0.;

	th->phi = 1;
	//th->maxiter = 100;
	th->maxiter = 10000;
	th->trueres = 0;
	th->verbose = 10;

	th->dim_start	= 128;
	th->dim_stop	= 1024;
	th->dim_step	= 128;
	th->dim_m_dev = 0;
	th->dim_n_dev = 0;
	th->dim_k_dev = 0;
	th->dim_m_hst = 0;
	th->dim_n_hst = 0;
	th->dim_k_hst = 0;
	th->dim_m_const = 0;
	th->dim_n_const = 0;
	th->dim_k_const = 0;
	th->incx = 1;
	th->incy = 1;
	th->lda_dev = 0;
	th->ldb_dev = 0;
	th->ldc_dev = 0;
	th->dim_step_mode = 0;

	strcpy (th->mtx_file, "");

	#if defined (CUDA)
	th->pmode = CUBLAS_POINTER_MODE_VALUE;
	#endif

 	// args ---------------------------
	int32_t opt, opt_index;
	optind = 1;
	struct option long_options[] = {
		{"transa", required_argument, 0, 'a'},
		{"transb", required_argument, 0, 'b'},
		{"usebatchedgemm", required_argument, NULL, 'c'},
		{"degree", required_argument, 0, 'd'},
		{"phi", required_argument, NULL, 'e'},
		{"mtx", required_argument, NULL, 'f'},
		{"devno", required_argument, NULL, 'g'},
		{"repromode", required_argument, NULL, 'h'},
		{"fastmode", required_argument, NULL, 'i'},
		{"mnk", required_argument, NULL, 'j'},
		{"k", required_argument, NULL, 'k'},
		{"trueres", required_argument, NULL, 'l'},
		{"m", required_argument, NULL, 'm'},
		{"n", required_argument, NULL, 'n'},
		{"mode", required_argument, NULL, 'o'},
		{"maxiter", required_argument, NULL, 'q'},
		{"range", required_argument, NULL, 'r'},
		{"sparsethreshold", required_argument, NULL, 's'},
		{"summode", required_argument, NULL, 't'},
		{"verbose", required_argument, NULL, 'u'},
		{"nodisp", required_argument, NULL, 'w'},
		{"usegemm", required_argument, NULL, 'x'},
		{"usemygemm", required_argument, NULL, 'y'},
		{0, 0, 0, 0}
	};
	while ((opt = getopt_long (argc, argv, "abcdefghijklmnoqrstuwxy", long_options, &opt_index)) != -1){
		switch (opt) {
			case 'a':{ // N, T, C
				if (optarg[0]) th->tranA= optarg[0];
				break;
			} case 'b':{ // N, T, C
				if (optarg[0]) th->tranB= optarg[0];
				break;
			} case 'c':{
				th->useBatchedGemmFlag = atoi(optarg);
				break;
			} case 'd':{
				th->numSplitArraysMax = atoi(optarg);
				break;
			} case 'e':{
				th->phi = atoi(optarg);
				break;
			} case 'f':{
				strcpy (th->mtx_file, optarg);
				break;
			} case 'g':{
				th->devno = atoi(optarg);
				break;
			} case 'h':{
				th->repromode = atoi(optarg);
				break;
			} case 'i':{
				th->fastmode = atoi(optarg);
				break;
			} case 'j':{
				th->dim_start = atoi (optarg);
				th->dim_stop = atoi (optarg);
				th->dim_step = 1;
				break;
			} case 'k':{
				th->dim_k_const = atoi(optarg);
				break;
			} case 'l':{
				th->trueres = atoi(optarg);
				break;
			} case 'm':{
				th->dim_m_const = atoi(optarg);
				break;
			} case 'n':{
				th->dim_n_const = atoi(optarg);
				break;
			} case 'o':{
				th->mode = optarg[0];
				break;
			} case 'q':{
				th->maxiter = atoi(optarg);
				break;
			} case 'r':{
				char *str, *c_start, *c_stop, *c_step;
				char par[] = ":";
				str = optarg;
				c_start = strtok (str, par);
				c_stop  = strtok (NULL, par);
				c_step	= strtok (NULL, par);

				th->dim_start	= atoi (c_start);
				th->dim_stop	= atoi (c_stop);

				if (strcmp (c_step, "pow") == 0)
					th->dim_step_mode	= 2;
				else 
					th->dim_step	= atoi (c_step);
				break;
			} case 's':{
				th->sparseThreshold = (float)atof(optarg);
				break;
			} case 't':{
				th->summode = atoi(optarg);
				break;
			} case 'u':{
				th->verbose = atoi(optarg);
				break;
			} case 'w':{
				th->nodisp = atoi(optarg);
				break;
			} case 'x':{
				th->useGemmFlag = atoi(optarg);
				break;
			} case 'y':{
				th->useMyGemmFlag = atoi(optarg);
				break;
			}
		}
	}
	dev_setting (th);
}

// =========================================
// Print floating-point value with bit representation
// =========================================
typedef union{
	double d;
	uint64_t i;
} d_and_i;

void printBitsB64 (double val) {
	d_and_i di;
	di.d = val;
	// sign
	printf ("%d", (int)((di.i >> 63) & 1));
	printf ("|");
	// exponent
	for (int i = 62; i >= 62-10; i--) 
		printf ("%d", (int)((di.i >> i) & 1));
	printf ("|");
	// fraction
	for (int i = 62-11; i >= 0; i--) 
		printf ("%d", (int)((di.i >> i) & 1));
	printf (" : ");
	printf ("%a, %+1.18e\n", val, val);
}

#if defined (PREC_Q)
typedef union{
	__float128 q;
	__int128 i;
} q_and_i;

void printBitsB128 (__float128 val) {
	q_and_i qi;
	qi.q = val;
	// sign
	printf ("%d", (int)((qi.i >> 127) & 1));
	printf ("|");
	// exponent
	for (int i = 126; i >= 126-14; i--) 
		printf ("%d", (int)((qi.i >> i) & 1));
	printf ("|");
	// fraction
	for (int i = 126-15; i >= 0; i--) 
		printf ("%d", (int)((qi.i >> i) & 1));
	printf (" : ");
	char buf[128];
	quadmath_snprintf(buf, sizeof(buf), "%.40Qf", val);
	puts(buf);
}
#endif

void mublasInitMat (int32_t m, int32_t n, int32_t ld, FP_TYPE *mat, double phi, int32_t mode) {
	int32_t i, j;
	double erange;
	FP_TYPE val, valf, r1, r2, x1;
	FP_TYPE mu = 0.0;
	FP_TYPE sigma = 1.0;
	FP_TYPE amax = 0., amin = 1.;
	if (ld < m) ld = m;

	switch (mode) {
		case 1:	// init with constant
			#pragma omp parallel for private (i)
			for (j = 0; j < n; j++) {
				for (i = 0; i < m; i++) {
					mat[j*ld+i] = val = phi;
					if (amax < fabs(val)) amax = fabs(val);
					if (amin > fabs(val)) amin = fabs(val);
				}
			}
			erange = log10(amax)-log10(amin);
			printf ("# input range: %.2f (max = %1.3e, min = %1.3e) (* initialized with const-mode)\n", (isnan(erange)) ? 0 : erange, amax, amin);
			break;
		case 2:	// phi-mode
			srand48(123);
			for (j = 0; j < n; j++) {
				for (i = 0; i < m; i++) {
					r1 = drand48();
					r2 = drand48();
					x1 = mu + (std::sqrt (-2. * log(r1)) * sin (2. * M_PI * r2)) * sigma;
					val = (r1 - 0.5) * exp (phi * x1);
					mat[j*ld+i] = (FP_TYPE)val;
					if (amax < fabs(val)) amax = fabs(val);
					if (amin > fabs(val)) amin = fabs(val);
				}
			}
			erange = log10(amax)-log10(amin);
			printf ("# input range: %.2f (max = %1.3e, min = %1.3e) (* initialized with phi-mode)\n", (isnan(erange)) ? 0 : erange, amax, amin);
			break;
		case 3: // erange-mode : initialize with +-1e(phi/2)
			FP_TYPE pi_;
			#if defined (PREC_Q)
			pi_ = M_PIq;
			#elif defined (PREC_DD)
			pi_ = dd_real::_pi;
			#elif defined (PREC_MPFR)
			mpfr_const_pi (pi_, MPFR_RNDN);
			#else
			pi_ = M_PI;
			#endif
			for (j = 0; j < n; j++) {
				for (i = 0; i < m; i++) {
//					double d = drand48()*9.+1.; // d=rand[1:10)
//					int e = rand() % phi; // [0:phi-1]
//					val = d * pow(10., e);
					val = (drand48()*9+1) * pow(10,rand()%(int32_t)phi);
					#if defined (PREC_DD)
					valf = dd_real(val,0.);
					#else
					valf = val;
					#endif
					int32_t s = (rand() % 2) ? 1:-1;
					valf = s * valf * (pi_/(double)M_PI);
					mat[j*ld+i] = valf;
					// min, max
					#if defined (PREC_DD)
					val = valf.x[0];
					#else
					val = (double)valf;
					#endif
					if (amax < fabs(val)) amax = fabs(val);
					if (amin > fabs(val)) amin = fabs(val);
					/*
					printf ("%d: ",j*n+i);
					#if defined (PREC_DD)
					printBitsB64 (valf.x[0]);
					printBitsB64 (valf.x[1]);
					#elif defined (PREC_Q)
					printBitsB128 (valf);
					#else
					printBitsB64 (valf);
					#endif
					*/
				}
			}
			erange = log10(amax)-log10(amin);
			printf ("# input range: %.2f (max = %1.3e, min = %1.3e) (* initialized with erange-mode)\n", (isnan(erange)) ? 0 : erange, amax, amin);
			break;
	}
}

void mublasConvMat (int32_t rd, int32_t cd, int32_t ld, FP_TYPE *src, mpreal *dst) {
	int32_t i, j;
	if (ld == 0) ld = rd;
	#pragma omp parallel for private (i)
	for (j = 0; j < cd; j++) {
		for (i = 0; i < rd; i++) 
			mpfr_set_d (dst[j*ld+i], src[j*ld+i], MPFR_RNDN);
	}
}

void mublasCopyMat (int32_t rd, int32_t cd, int32_t ld, FP_TYPE *src, FP_TYPE *dst) {
	int32_t i, j;
	if (ld == 0) ld = rd;
	#pragma omp parallel for private (i)
	for (j = 0; j < cd; j++) {
		for (i = 0; i < rd; i++) 
			dst[j*ld+i] = src[j*ld+i];
	}
}

// check routine (|trg-ref|/|ref|) -------------------------------------------------
void mublasCheckMatrix (int32_t m, int32_t n, FP_TYPE *ftarget, int32_t ldt, mpreal *mpref, int32_t ldr) {
	FP_TYPE target, ref, dif, rdif;
    FP_TYPE max = 0., rmax = 0.;
	size_t errcnt = 0;
	size_t rerrcnt = 0;
    for(int32_t j = 0; j < n; j++) {
    	for(int32_t i = 0; i < m; i++) {
			target = ftarget[j*ldt+i];
			ref = mpfr_get_d (mpref[j*ldr+i], MPFR_RNDN);
			dif = fabs (target - ref);
			if (isinf(dif) || isnan(dif)) {
				printf("\terr: target or reference includes inf or nan\n");
				exit(1);
			}
			rdif = (dif == 0 || ref == 0) ? 0. : dif / ref;
//			printf(" -- [%d,%d] trg=%1.3e ref=%1.3e diff=%1.3e (%1.3e)\n", j, i, target, ref, dif, rdif);
			if (max < dif) max = dif;
			if (rmax < rdif) rmax = rdif;
			if (dif != 0) errcnt++;
			if (rdif != 0) rerrcnt++;
		}
    }
	printf("\t%1.6e\t%zd\t%1.6e\t%zd\t", max, errcnt, rmax, rerrcnt);
	printf("## max(|t-r|)\terrcnt\tmax(|t-r|/r)\terrcnt");
}

// print routine -------------------------------------------------
void print_routine_name () {
	#if defined (PREC_S)
	printf ("S");
	#elif defined (PREC_SD)
	printf ("SD");
	#elif defined (PREC_D)
	printf ("D");
	#else
	printf ("unknown-precision,");
	#endif
	#if defined (DOT)
	printf ("DOT\n");
	#elif defined (GEMV)
	printf ("GEMV\n");
	#elif defined (CSRMV)
	printf ("CSRMV\n");
	#elif defined (GEMM)
	printf ("GEMM\n");
	#elif defined (CG)
	printf ("CG\n");
	#else
	printf ("unknown-routine\n");
	#endif
}

void print_library_name () {
	#if defined (CUOZBLAS)
	printf ("CUOZBLAS (using cuBLAS)\n");
	#elif defined (OZBLAS)
	printf ("OZBLAS");
	#if defined (MKL)
	printf (" (using MKL");
	#elif defined (OpenBLAS)
	printf (" (using OpenBLAS");
	#endif
	#if defined (NVBLAS)
	printf (" with NVBLAS)\n");
	#else
	printf (")\n");
	#endif
	#else
	printf ("unknown-library\n");
	#endif
}

#include <sys/utsname.h>
void print_info1 (testingHandle_t *th) {
	if (!th->nodisp) {
		system("echo -n '# Testing info -----------------------------\n'");
		system("echo -n '# \tDate:\t'; date");
		system("echo -n '# \tCPU:'; cat /proc/cpuinfo | grep 'model name' | head -n 1");
		system("echo '# \t - OMP_NUM_THREADS = ' $OMP_NUM_THREADS");
		system("echo '# \t - MKL_NUM_THREADS = ' $MKL_NUM_THREADS");
		system("echo -n '# \tOS:\t'; uname -a");
		system("echo -n '# \tHost:\t'; hostname");
#if defined (CUDA) && defined (CUOZBLAS) || defined (NVBLAS)
		printf("# \tDevice[%d]\t%s\n", th->devno, th->devprop.name);
		printf("# \t- Theoretical Peak Memory Bandwidth:\t%3.1f [GB/s]\n", th->device_bytes_per_sec * 1.e-9);
		printf("# \t- Theoretical Peak Performance (SP):\t%4.1f [GFlops]\n", th->device_flops_per_sec_sp * 1.e-9);
		printf("# \t- Theoretical Peak Performance (DP):\t%4.1f [GFlops]\n", th->device_flops_per_sec_dp * 1.e-9);
		printf("# \t- Total Gmem:\t%4.1f [GB]\n", th->devprop.totalGlobalMem * 1e-9);
		printf("# \t- CC:\t%d.%d\n", th->devprop.major, th->devprop.minor);
		printf("# \t- ECC Enabled:\t%d\n", th->devprop.ECCEnabled);
		printf("# \t- MultiProcessorCount:\t%d\n", th->devprop.multiProcessorCount);
		printf("# \tDriver / Runtime:\t%d, %d\n", th->driverVersion, th->runtimeVersion);
#endif
		printf ("#\tRoutine:\t");
		print_routine_name ();
		printf ("#\tLibrary:\t");
		print_library_name ();
		#if !defined (CG)
		if (th->mode == 'c') {
			printf ("#\tmode: checking with ");
			printf ("MBLASMPFR with %zd-bit\n", mpfr_get_default_prec());
		} else {
			printf ("#\tmode: performance evaluation\n");
		}
		printf ("#\tNLOOP/WLOOP:\t%d/%d\n", NLOOP, WLOOP);
		#endif
		printf ("# ------------------------------------------\n");
#if defined (CUOZBLAS) || defined (OZBLAS)
		printf ("# OzBLAS -----------------------------------\n");
		printf ("#\tWork-mem size = %1.1e (bytes)\n", WORK_MEM_SIZE);
		printf ("#\tDegree = %d\n", th->numSplitArraysMax);
		printf ("#\tFastMode = %d\n", th->fastmode);
		printf ("#\tReproMode = %d\n", th->repromode);
		printf ("#\tSumMode = %d\n", th->summode);
		printf ("#\tUseGemmFlag = %d\n", th->useGemmFlag);
		printf ("#\tUseMyGemmFlag = %d\n", th->useMyGemmFlag);
		printf ("#\tUseBatchedGemmFlag = %d\n", th->useBatchedGemmFlag);
		printf ("#\tSparseThreshold (GEMM) = %f\n", th->sparseThreshold);
		printf ("# ------------------------------------------\n");
#endif
		printf ("# BLAS parameter ---------------------------\n");
		printf ("#\ttranA:\t%c\n", th->tranA);
		printf ("#\ttranB:\t%c\n", th->tranB);
		printf ("# Problem setting --------------------------\n");
		printf ("#\tExpRange = [1e0:1e%d)\n", th->phi);
#if !defined (CSRMV)
		printf ("#\tdim_start:\t%d\n", th->dim_start);
		printf ("#\tdim_stop:\t%d\n", th->dim_stop);
		printf ("#\tdim_step:\t%d\n", th->dim_step);
		if (th->dim_m_const == 0) printf ("#\tM:\trange\n");
		else printf ("#\tM:\t%d\n", th->dim_m_const);
		if (th->dim_n_const == 0) printf ("#\tN:\trange\n");
		else printf ("#\tN:\t%d\n", th->dim_n_const);
		if (th->dim_k_const == 0) printf ("#\tK:\trange\n");
		else printf ("#\tK:\t%d\n", th->dim_k_const);
#endif
		#if defined (CUDA)
		if (th->pmode)	printf ("#\tcublaspointer:\tDEVICE\n");
		else		 	printf ("#\tcublaspointer:\tHOST\n");
		#endif
		printf ("# ------------------------------------------\n");
	}
}

void print_info2 (testingHandle_t *th) {
	if (!th->nodisp) {
		printf ("# Evaluation result ------------------------\n");
		if (th->mode == 'p') printf ("(* shows the value at the last execution, ** shows the value of the last block at the last execution)\n");
		printf ("# M\tN\tK");
		if (th->mode == 'p') printf ("\tTime[sec]\tPerf[GFlops]\tPerf[GB/s]\titr\t*t_SpltA\t*t_SpltB\t*t_Comp \t*t_Sum  \t*t_Other\t*t_Total\t**#SpltA\t**#SpltB\t**Mem[MB]");
		else printf ("\tERROR\t#ofERROR");
		printf ("\n");
	}
}

#if defined (CUOZBLAS) 
void print_cuozblas_info1 (testingHandle_t *th, cuozblasHandle_t *ha) {
	if (th->mode == 'p') {
		double t_other = ha->t_total - ha->t_SplitA - ha->t_SplitB - ha->t_comp - ha->t_sum;
		printf ("\t%1.3e\t%1.3e\t%1.3e\t%1.3e\t%1.3e\t%1.3e", ha->t_SplitA, ha->t_SplitB, ha->t_comp, ha->t_sum, t_other, ha->t_total);
		printf ("\t%d\t%d\t%1.3e", ha->numSplitArraysA, ha->numSplitArraysB, ha->memAddr*1.e-6);
	}
}
#elif defined (OZBLAS)
void print_ozblas_info1 (testingHandle_t *th, ozblasHandle_t *ha) {
	if (th->mode == 'p') {
		double t_other = ha->t_total - ha->t_SplitA - ha->t_SplitB - ha->t_comp - ha->t_sum;
		printf ("\t%1.3e\t%1.3e\t%1.3e\t%1.3e\t%1.3e\t%1.3e", ha->t_SplitA, ha->t_SplitB, ha->t_comp, ha->t_sum, t_other, ha->t_total);
		printf ("\t%d\t%d\t%1.3e", ha->numSplitArraysA, ha->numSplitArraysB, ha->memAddr*1.e-6);
	}
}
#endif

